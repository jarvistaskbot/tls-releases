// v1.5.327 — MAIN-world bridge for reCAPTCHA Enterprise token generation.
// Loaded via manifest content_scripts with "world": "MAIN" — runs in the
// page's JS context where window.grecaptcha is accessible. The isolated-world
// content script can't see grecaptcha; it talks to this bridge via
// window.postMessage with a unique requestId per call.
//
// Why this exists: chrome.scripting.executeScript({world:'MAIN'}) returned
// result:undefined on TLS pages — likely page CSP or Chrome serialization
// quirk. This bridge sidesteps both: it's a normal page script that
// communicates via postMessage (not subject to either issue).
(function () {
  var HARDCODED_SITE_KEY = '6LevDoQeAAAAAEVrXcQsTo2zjgSO5oQs-PGf6ZW7';

  function detectSiteKey() {
    try {
      var scripts = document.querySelectorAll('script');
      // 1) script[src*=recaptcha]?render=...
      for (var i = 0; i < scripts.length; i++) {
        var s = scripts[i].src || '';
        if (s.indexOf('recaptcha') !== -1) {
          var m = s.match(/render=([a-zA-Z0-9_-]+)/);
          if (m) return m[1];
        }
      }
      // 2) Inline-script scan
      for (var j = 0; j < scripts.length; j++) {
        var body = scripts[j].textContent || '';
        var m2 = body.match(/['"]sitekey['"]\s*:\s*['"]([a-zA-Z0-9_-]{30,})['"]/);
        if (!m2) m2 = body.match(/grecaptcha\.enterprise\.execute\(['"]([a-zA-Z0-9_-]{30,})['"]/);
        if (m2) return m2[1];
      }
      // 3) recaptcha iframe src
      var badge = document.querySelector('iframe[src*="recaptcha"]');
      if (badge && badge.src) {
        var m3 = badge.src.match(/render=([a-zA-Z0-9_-]+)/) || badge.src.match(/k=([a-zA-Z0-9_-]+)/);
        if (m3) return m3[1];
      }
    } catch (_) {}
    return HARDCODED_SITE_KEY;
  }

  function reply(requestId, payload) {
    try {
      window.postMessage({
        type: '__tls_recaptcha_response__',
        requestId: requestId,
        payload: payload
      }, '*');
    } catch (_) {}
  }

  // Resolve to a usable grecaptcha API object: prefer enterprise, fall back to
  // regular v3. TLS pages were observed with grecaptcha.execute but no
  // grecaptcha.enterprise on the booking calendar — the enterprise variant
  // may be lazy-loaded on the actual Book button click.
  function waitForGrecaptcha(timeoutMs) {
    return new Promise(function (resolve) {
      var start = Date.now();
      function check() {
        var g = window.grecaptcha;
        if (g) {
          if (g.enterprise && typeof g.enterprise.execute === 'function') {
            resolve({ ready: true, variant: 'enterprise', api: g.enterprise });
            return;
          }
          if (typeof g.execute === 'function') {
            resolve({ ready: true, variant: 'v3', api: g });
            return;
          }
        }
        if (Date.now() - start >= timeoutMs) {
          resolve({ ready: false, variant: null, api: null });
          return;
        }
        setTimeout(check, 100);
      }
      check();
    });
  }

  function handle(requestId, action, explicitSiteKey) {
    var siteKey = explicitSiteKey || detectSiteKey();
    var diag = {
      siteKeyHead: siteKey ? siteKey.slice(0, 12) : null,
      hasGrecaptcha: !!window.grecaptcha,
      hasEnterprise: !!(window.grecaptcha && window.grecaptcha.enterprise),
      hasRegularExecute: !!(window.grecaptcha && typeof window.grecaptcha.execute === 'function'),
    };
    if (!siteKey) { reply(requestId, { ok: false, error: 'no_site_key', diag: diag }); return; }

    waitForGrecaptcha(8000).then(function (res) {
      diag.hasGrecaptcha = !!window.grecaptcha;
      diag.hasEnterprise = !!(window.grecaptcha && window.grecaptcha.enterprise);
      diag.hasRegularExecute = !!(window.grecaptcha && typeof window.grecaptcha.execute === 'function');
      diag.variant = res.variant;
      if (!res.ready) { reply(requestId, { ok: false, error: 'grecaptcha_not_loaded', diag: diag }); return; }
      try {
        res.api.ready(function () {
          try {
            res.api.execute(siteKey, { action: action }).then(function (token) {
              reply(requestId, { ok: true, token: token, siteKey: siteKey, diag: diag });
            }, function (e) {
              reply(requestId, {
                ok: false, error: 'execute_failed',
                message: (e && e.message) ? String(e.message) : String(e),
                diag: diag
              });
            });
          } catch (e1) {
            reply(requestId, {
              ok: false, error: 'execute_threw',
              message: (e1 && e1.message) ? String(e1.message) : String(e1),
              diag: diag
            });
          }
        });
      } catch (e2) {
        reply(requestId, {
          ok: false, error: 'ready_threw',
          message: (e2 && e2.message) ? String(e2.message) : String(e2),
          diag: diag
        });
      }
    });
  }

  window.addEventListener('message', function (ev) {
    if (ev.source !== window) return;
    var d = ev.data;
    if (!d || d.type !== '__tls_recaptcha_request__') return;
    if (!d.requestId) return;
    try {
      handle(d.requestId, d.action || 'book', d.siteKey || null);
    } catch (e) {
      reply(d.requestId, { ok: false, error: 'handler_threw', message: String(e && e.message ? e.message : e) });
    }
  });

  // Signal readiness once — useful for the content script to know the
  // bridge is alive (vs. injected too late on a slow page).
  try {
    window.postMessage({ type: '__tls_recaptcha_bridge_ready__' }, '*');
  } catch (_) {}
})();

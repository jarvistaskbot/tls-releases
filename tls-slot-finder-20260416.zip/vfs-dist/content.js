// ─── Injection guard — prevent double-injection crash ────────────────────────
if (window.__tlsSlotFinderInjected) {
  console.log('[TLS] Content script already injected — skipping duplicate');
} else {
window.__tlsSlotFinderInjected = true;

// Per-hostname key for namespacing storage (prevents Italy/Germany state collision)
const _host = window.location.hostname;

// Guard against "Extension context invalidated" after auto-update reloads the extension
function isExtensionAlive() {
  try { return !!chrome.runtime?.id; } catch { return false; }
}

/**
 * Visa Slot Finder — Content Script
 *
 * Runs inside the real TLScontact browser tab (same-origin context).
 * Service worker sends "poll" messages; we do the RSC fetch and return results.
 * Running in page context = CF-invisible (identical to a regular page JS fetch).
 */

const BOOKING_PATH_RE = /\/[a-z]{2}-[a-z]{2,4}\/(\d+)\/workflow\/appointment-booking/;

// ─── Country / host helpers ──────────────────────────────────────
// Centralised country table — replaces the `-it.`/`-de.`/`-cy.` chain
// that was repeated throughout this file for labels and VAC paths.
const TLS_COUNTRIES = [
  { code: 'it', label: '🇮🇹 Italy',   labelShort: '🇮🇹', vacPath: '/en-us/country/am/vac/amEVN2it' },
  { code: 'de', label: '🇩🇪 Germany', labelShort: '🇩🇪', vacPath: '/en-us/country/am/vac/amEVN2de' },
  { code: 'cy', label: '🇨🇾 Cyprus',  labelShort: '🇨🇾', vacPath: '/en-us/country/am/vac/amEVN2cy' },
];
const FALLBACK_VAC_PATH = '/en-us/login';
const FALLBACK_COUNTRY_LABEL = '🌍';

function _matchCountry(hostOrUrl) {
  if (!hostOrUrl) return null;
  return TLS_COUNTRIES.find(c => hostOrUrl.includes(`-${c.code}.`)) || null;
}
function countryLabelFor(hostOrUrl) {
  return (_matchCountry(hostOrUrl) || {}).label || FALLBACK_COUNTRY_LABEL;
}
function countryShortFor(hostOrUrl) {
  return (_matchCountry(hostOrUrl) || {}).labelShort || FALLBACK_COUNTRY_LABEL;
}
function vacPathFor(hostOrUrl) {
  return (_matchCountry(hostOrUrl) || {}).vacPath || FALLBACK_VAC_PATH;
}

// ─── Post-booking verification ───────────────────────────────────
// Signals that the booking attempt succeeded — checked in three places
// (direct-click, time-first flow, date-first flow) after clicking Book/Confirm.
// Keeping the list in one constant prevents them drifting out of sync.
const BOOKING_SUCCESS_URL_PARTS = [
  'order-summary', 'payment', 'checkout', 'confirmation', 'success', 'booking-confirmed'
];
const BOOKING_SUCCESS_TEXT_PARTS = [
  'Order summary', 'Shopping cart', 'TLScontact fees', 'Pay TLS Fee',
  'Your appointment', 'has been booked', 'Reservation confirmed',
  'Reference number', 'booking reference', 'minutes to pay',
  'Félicitations', 'Congratulations'
];
function _anyMatch(haystack, needles) {
  if (!haystack) return false;
  for (const n of needles) if (haystack.includes(n)) return true;
  return false;
}
function isBookingSuccessPage(url, text) {
  return _anyMatch(url, BOOKING_SUCCESS_URL_PARTS) || _anyMatch(text, BOOKING_SUCCESS_TEXT_PARTS);
}
// "We reached a post-booking page" signal used to break out of the 15×1s wait loop.
// Subset of BOOKING_SUCCESS_* — only the cheap, high-signal markers.
function isPostBookingLandmark(url, text) {
  return (url && (url.includes('order-summary') || url.includes('payment'))) ||
         (text && (text.includes('Order summary') || text.includes('Shopping cart')));
}

function getBookingPath() {
  const m = window.location.pathname.match(BOOKING_PATH_RE);
  if (!m) return null;
  // Germany requires query params (?location=amEVN2de&month=04-2026) in RSC fetch.
  // Italy/Cyprus break with query params (500 error) — use pathname only.
  if ((_matchCountry(window.location.hostname) || {}).code === 'de') {
    return window.location.pathname + (window.location.search || '');
  }
  return window.location.pathname;
}

function isOnBookingPage() {
  return !!getBookingPath();
}

function getPageStep() {
  const path = window.location.pathname;
  const url = window.location.href;
  if (getBookingPath()) return 'booking page ✅';
  if (url.includes('/cdn-cgi/')) return 'CF challenge page 🚫';
  if (path.includes('/login') || url.includes('auth.visas')) return 'login page 🔑';
  if (path.includes('travel-groups') || path.includes('redirect-group')) return 'application manager 📁';
  if (path.includes('service-level') || path.includes('/services') || path.includes('/book/offices')) return 'services page ⚙️';
  if (path.includes('/place/') || path.includes('/vac/')) return 'VAC centre page 📍';
  if (path.match(/\/country\/[a-z]+\/?$/)) return 'country selection 🌍';
  if (path.includes('/payment') || path.includes('order-summary')) return 'payment page 💳';
  return `unknown (${path.slice(0, 40)})`;
}

async function doRscFetch(bookingPath) {
  try {
    const resp = await fetch(bookingPath, {
      headers: {
        "RSC": "1",
        "Next-Url": bookingPath,
        "Next-Router-State-Tree": "%5B%22%22%2C%7B%7D%2Cnull%2Cnull%2Ctrue%5D"
      },
      credentials: "same-origin"
    });

    if (!resp.ok) {
      const raw = await resp.text().catch(() => "");
      console.log(`[TLS] RSC non-OK: ${resp.status} url=${resp.url} body=${raw.slice(0,300)}`);
      // 5xx = TLS server error — temporary, retry next cycle, don't treat as auth error
      if (resp.status >= 500) {
        return { status: "server_error", code: resp.status, raw: raw.slice(0, 200) };
      }
      // 401/403 = auth error
      if (resp.status === 401 || resp.status === 403) {
        return { status: "auth_error", code: resp.status, raw: raw.slice(0, 200) };
      }
      // CF rate limit
      if (resp.status === 429) {
        return { status: "error", code: 429, raw: raw.slice(0, 200) };
      }
      return { status: "error", code: resp.status, raw: raw.slice(0, 200) };
    }

    // Log final URL after redirects — detects silent redirect to login page
    if (resp.url && !resp.url.includes('appointment-booking')) {
      console.log(`[TLS] RSC redirected to: ${resp.url}`);
    }

    const text = await resp.text();
    return parseRscPayload(text);
  } catch (e) {
    return { status: "error", message: String(e), raw: "" };
  }
}

/**
 * Extract a balanced JSON array value for a given key from an RSC payload.
 * Simple regex fails on nested arrays (e.g. timeSlots inside availableAppointments).
 * This walks character-by-character to find the matching closing bracket.
 */
function extractBalancedArray(body, key) {
  const keyIdx = body.indexOf(`"${key}"`);
  if (keyIdx === -1) return null;
  const start = body.indexOf("[", keyIdx);
  if (start === -1) return null;

  let depth = 0;
  for (let i = start; i < body.length; i++) {
    if (body[i] === "[") depth++;
    else if (body[i] === "]") {
      depth--;
      if (depth === 0) return body.slice(start, i + 1);
    }
  }
  return null; // unbalanced
}

function parseRscPayload(body) {
  const currentDateMatch = body.match(/"currentDate"\s*:\s*"([^"]+)"/);
  const maxDateMatch = body.match(/"maxDate"\s*:.*?"(\d{4}-\d{2}-\d{2})/);

  const currentDate = currentDateMatch ? currentDateMatch[1] : "";
  const maxDate = maxDateMatch ? maxDateMatch[1] : "";

  // Check for auth errors — multiple signals:
  // 1. Explicit HTTP error codes in RSC payload
  if (body.includes("HTTP_401") || body.includes("HTTP_403")) {
    return { status: "auth_error", currentDate, maxDate, slots: [], raw: body.slice(0, 300) };
  }
  // 2. Short body without expected RSC content (redirect to login)
  if (body.length < 500 && !body.includes("availableAppointments")) {
    return { status: "auth_error", currentDate, maxDate, slots: [], raw: body.slice(0, 300) };
  }
  // 3. HTML login page returned (session expired → 302 → login page returned as 200)
  //    RSC responses are never HTML — if we get HTML it's a login/CF redirect
  const _loginUrlMarkers = TLS_COUNTRIES.map(c => `visas-${c.code}.tlscontact.com/en-us/login`);
  if (body.includes("<!DOCTYPE html") || body.includes("<html") ||
      body.includes("kc-login") || body.includes("login-pf-body") ||
      _loginUrlMarkers.some(m => body.includes(m))) {
    return { status: "auth_error", currentDate, maxDate, slots: [], raw: body.slice(0, 300) };
  }
  // 4. No RSC marker — response is not a valid RSC payload at all
  if (!body.includes("availableAppointments") && !body.includes("currentDate")) {
    console.log(`[TLS] RSC no-marker auth_error — body preview: ${body.slice(0, 300)}`);
    return { status: "auth_error", currentDate, maxDate, slots: [], raw: body.slice(0, 300) };
  }

  // Extract availableAppointments using bracket-balanced parser
  const rawArray = extractBalancedArray(body, "availableAppointments");
  if (!rawArray) {
    return { status: "no_slots", currentDate, maxDate, slots: [] };
  }

  let slots = [];
  try {
    slots = JSON.parse(rawArray);
  } catch (_) {
    slots = [];
  }

  // Log raw slot structure to understand field names
  if (slots.length > 0) {
    console.log('[TLS] Raw slot[0] keys:', Object.keys(slots[0]));
    console.log('[TLS] Raw slot[0]:', JSON.stringify(slots[0]));
  }

  // Normalize slot fields — RSC may use different key names across countries
  // Do NOT filter by date — unknown field names should still attempt booking
  slots = slots.map(s => {
    const rawTimes = s.timeSlots || s.times || s.availableTimes || s.slots || [];
    // timeSlots may be array of objects like {time:"09:00"} or {startTime:"09:00"}
    const normalizedTimes = rawTimes.map(t =>
      typeof t === 'string' ? t : (t.time || t.startTime || t.timeSlot || t.value || Object.values(t)[0] || '')
    ).filter(Boolean);
    return {
      date: s.date || s.appointmentDate || s.slotDate || s.day || null,
      timeSlots: normalizedTimes,
      _raw: s  // Keep raw for debugging
    };
  });

  if (slots.length > 0) {
    return { status: "available", slots, currentDate, maxDate };
  }
  return { status: "no_slots", slots: [], currentDate, maxDate };
}

// ─── Booking ─────────────────────────────────────────────────────

// ─── Action Diagnostics ──────────────────────────────────────────────────────
// Sends every meaningful action to Telegram via CONTENT_DIAG so we can audit
// exactly what the extension did, when, and why — especially around CF blocks.
function diagAction(action, detail) {
  const host = window.location.hostname;
  const country = countryShortFor(host);
  const path = window.location.pathname.slice(0, 50);
  const msg = `${country} [${action}] ${detail || ''} | page: ${path}`;
  console.log('[TLS DIAG]', msg);
  try { chrome.runtime.sendMessage({ type: "CONTENT_DIAG", text: msg }); } catch(_) {}
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getDomDump() {
  return Array.from(document.querySelectorAll('button')).map((b, i) =>
    `[${i}] disabled=${b.disabled} text="${b.textContent.trim().slice(0, 30)}" class="${b.className.slice(0, 60)}"`
  ).join('\n');
}

/**
 * MutationObserver-based element waiter.
 * Checks immediately, then watches DOM mutations until element appears or timeout.
 */
function waitForElement(finder, timeoutMs = 8000) {
  return new Promise((resolve) => {
    // Check immediately first
    const immediate = finder();
    if (immediate) { resolve(immediate); return; }

    let resolved = false;
    const timer = setTimeout(() => {
      if (!resolved) { resolved = true; observer.disconnect(); resolve(null); }
    }, timeoutMs);

    const observer = new MutationObserver(() => {
      if (resolved) return;
      const el = finder();
      if (el) {
        resolved = true;
        clearTimeout(timer);
        observer.disconnect();
        resolve(el);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true, attributes: true });
  });
}

/**
 * Check if the DOM has any available date elements (used by selfPoll for DOM-based detection).
 * Uses multiple selector strategies matching the MutationObserver booking approach.
 */
function hasAvailableDates() {
  // Strategy A: partial class match
  const flexi = document.querySelectorAll('[class*="AppointmentFlexi"]:not([disabled])');
  if (flexi.length > 0) return true;

  // Strategy B: any non-disabled button with day number text (1-31)
  const btns = Array.from(document.querySelectorAll('button:not([disabled])')).filter(b => {
    const t = b.textContent.trim();
    return /^\d{1,2}$/.test(t) && parseInt(t) >= 1 && parseInt(t) <= 31;
  });
  if (btns.length > 0) return true;

  // Strategy C: role=button with day number
  const clickable = Array.from(document.querySelectorAll('[role="button"]:not([aria-disabled="true"])')).filter(el => {
    const t = el.textContent.trim();
    return /^\d{1,2}$/.test(t) && parseInt(t) >= 1 && parseInt(t) <= 31;
  });
  if (clickable.length > 0) return true;

  return false;
}

/**
 * Dump full DOM diagnostics to console — called when a slot is first detected.
 * This lets us see exactly what CSS classes TLS uses when the calendar IS rendered.
 */
function logDomDiagnostics(slots) {
  console.group('[TLS] 🔍 DOM DIAGNOSTICS — slot detected');
  console.log('Slots from RSC:', JSON.stringify(slots, null, 2));
  console.log('URL:', window.location.href);
  console.log('Page title:', document.title);

  // All buttons on page
  const allBtns = Array.from(document.querySelectorAll('button'));
  console.log(`Total buttons on page: ${allBtns.length}`);
  allBtns.forEach((b, i) => {
    console.log(`  btn[${i}] disabled=${b.disabled} text="${b.textContent.trim().slice(0,30)}" class="${b.className.slice(0,100)}"`);
  });

  // All divs/elements with click-related classes
  const clickable = Array.from(document.querySelectorAll('[class*="cursor-pointer"], [role="button"], [onclick]'));
  console.log(`Clickable non-button elements: ${clickable.length}`);
  clickable.slice(0, 20).forEach((el, i) => {
    console.log(`  clickable[${i}] tag=${el.tagName} text="${el.textContent.trim().slice(0,30)}" class="${el.className.slice(0,100)}"`);
  });

  // AppointmentFlexiButton check (partial class match — hash changes between deploys)
  const flexi = document.querySelectorAll('[class*="AppointmentFlexi"]');
  console.log(`AppointmentFlexiButton elements: ${flexi.length}`);

  // AppointmentHour check
  const hours = document.querySelectorAll('[class*="AppointmentHour"]');
  console.log(`AppointmentHour elements: ${hours.length}`);
  hours.forEach((el, i) => {
    console.log(`  hour[${i}] class="${el.className}" text="${el.textContent.trim().slice(0,20)}"`);
  });

  // MonthSelector check
  const months = document.querySelectorAll('[class*="MonthSelector"]');
  console.log(`MonthSelector elements: ${months.length}`);
  months.forEach((el, i) => {
    console.log(`  month[${i}] class="${el.className}" text="${el.textContent.trim().slice(0,20)}"`);
  });

  // Any element containing day numbers
  const dayNumEls = Array.from(document.querySelectorAll('*')).filter(el => {
    const t = el.textContent.trim();
    return /^\d{1,2}$/.test(t) && parseInt(t) >= 1 && parseInt(t) <= 31 && el.children.length === 0;
  });
  console.log(`Elements with day numbers (1-31): ${dayNumEls.length}`);
  dayNumEls.slice(0, 15).forEach((el, i) => {
    console.log(`  day[${i}] tag=${el.tagName} text="${el.textContent.trim()}" class="${el.className.slice(0,100)}" parentClass="${el.parentElement?.className?.slice(0,100)}"`);
  });

  console.groupEnd();
}

/**
 * Try to navigate the calendar to the target date's month by clicking
 * the built-in next/prev month navigation buttons.
 * Returns true if the date becomes visible, false if nav buttons not found.
 * Uses in-page React clicks — no page reload, no CF risk.
 */
async function tryCalendarMonthNav(targetDate) {
  const [tYear, tMonth, tDay] = targetDate.split('-');
  const monthParam = `month=${tMonth}-${tYear}`; // e.g. month=04-2026

  // Already on the target month — nothing to do
  if (window.location.href.includes(monthParam)) return true;

  // TLS uses month-selector <a> tabs (not DayPicker buttons).
  // The DOM has: <a data-testid="btn-next-month-available" href="...?month=04-2026">April 2026</a>
  // Clicking it triggers React client-side navigation (pushState) — no full page reload, no CF risk.

  // Strategy 1: find the tab whose href contains the exact month param
  const allLinks = Array.from(document.querySelectorAll('a[data-testid]'));
  let monthTab = allLinks.find(a => a.href && a.href.includes(monthParam));

  // Strategy 2: fallback — find any "next month" available tab
  if (!monthTab) {
    monthTab = document.querySelector(
      'a[data-testid="btn-next-month-available"], a[data-testid="btn-next-month-unavailable"]'
    );
  }

  if (!monthTab) {
    // Log for diagnostics — dump all <a data-testid> links on the page
    const linkDump = allLinks.slice(0, 10).map((a, i) =>
      `[${i}] testid="${a.getAttribute('data-testid') || ''}" href="${(a.href || '').slice(-40)}"`
    ).join(' | ');
    const btnDump = Array.from(document.querySelectorAll('button')).slice(0, 10).map((b, i) =>
      `[${i}] aria="${b.getAttribute('aria-label') || ''}" class="${b.className.slice(0, 50)}"`
    ).join(' | ');
    console.log('[TLS] tryCalendarMonthNav: no month tab found. Links:', linkDump, 'Buttons:', btnDump);
    diagAction('NO_NAV_BTN', (linkDump + ' || ' + btnDump).slice(0, 500));
    return false;
  }

  console.log(`[TLS] tryCalendarMonthNav: clicking month tab "${monthTab.textContent.trim()}" → ${monthTab.href}`);
  diagAction('MONTH_TAB_CLICK', `tab="${monthTab.textContent.trim()}" href="${monthTab.href.slice(-40)}"`);
  monthTab.click();

  // Wait for React to re-render the calendar with the new month's data
  await sleep(2500);
  return true; // navigation happened — continue with booking
}

/**
 * Full booking attempt — MutationObserver-based.
 * Uses waitForElement() instead of sleep/retry loops for each UI step.
 */
async function attemptBooking(slots) {
  try {
    chrome.storage.local.set({ _bookingInProgress: true });
    const firstSlot = slots[0];
    const targetDate = firstSlot ? firstSlot.date : null;
    const knownTimes = firstSlot ? firstSlot.timeSlots : [];

    console.log('[TLS] ⚡ BOOKING START', targetDate, Date.now());
    diagAction('BOOKING_START', `date=${targetDate} times=${knownTimes.slice(0,3).join(',')}`);

    // Pre-step: Ensure we're on the correct month before booking.
    // TLS booking URL supports ?month=MM-YYYY — navigate directly instead of clicking UI buttons.
    // Only redirect if the target date is NOT already visible in the DOM — avoids unnecessary
    // page navigations that can trigger CF rate limiting when the calendar already shows the date.
    if (targetDate) {
      const [tYear, tMonth, tDay] = targetDate.split('-');
      const expectedParam = `month=${tMonth}-${tYear}`; // e.g. month=04-2026
      if (!window.location.href.includes(expectedParam)) {
        const dayNum = String(parseInt(tDay, 10)); // e.g. "20" not "020"
        const dateAlreadyVisible =
          document.querySelector(`[data-date="${targetDate}"], [data-day="${targetDate}"], [data-day="${dayNum}"]`) ||
          Array.from(document.querySelectorAll('button:not([disabled]), td:not([aria-disabled="true"])')).some(el => {
            const t = el.textContent.trim();
            return t === dayNum || t === tDay;
          });
        if (!dateAlreadyVisible) {
          // Strategy A: Click the calendar's built-in next-month button.
          // In-page React click — no page reload, no CF rate-limit risk.
          diagAction('MONTH_NAV_TRY_BTN', `targetDate=${targetDate}`);
          const btnNavWorked = await tryCalendarMonthNav(targetDate);
          if (btnNavWorked) {
            console.log(`[TLS] Calendar nav buttons advanced to show ${targetDate} — continuing booking`);
            diagAction('MONTH_NAV_BTN_OK', `targetDate=${targetDate}`);
            // Fall through to booking steps below — date is now visible
          } else {
            // Strategy B: URL redirect fallback (causes page reload — CF risk, but necessary)
            const baseUrl = window.location.href.split('?')[0];
            const newUrl = `${baseUrl}?${expectedParam}`;
            console.log(`[TLS] Date ${targetDate} not in DOM, no nav btn — navigating to ${newUrl}`);
            diagAction('MONTH_NAV', `targetDate=${targetDate} navigating=${newUrl}`);
            // Store settle timestamp so selfPoll waits 10s before first RSC fetch on reload
            chrome.storage.local.set({ _bookingInProgress: false, [`_month_nav_ts_${_host}`]: Date.now() });
            window.location.href = newUrl;
            return { booked: false, error: 'month_nav_redirect', targetDate };
          }
        }
        console.log(`[TLS] Date ${targetDate} already in DOM — skipping month nav redirect`);
      }
    }

    // Step 0: Full booking flow — select time slot → click Book → accept confirmation
    console.log('[TLS] Step 0: scanning for available time slots and booking button...');
    const { slot_preference: slotPref = "any" } = await chrome.storage.local.get(["slot_preference"]);
    
    // Log all buttons for debugging
    const allBtnsSnapshot = Array.from(document.querySelectorAll('button'));
    console.log(`[TLS] Step 0: ${allBtnsSnapshot.length} buttons on page:`);
    allBtnsSnapshot.forEach((b, i) => {
      const txt = b.textContent.trim();
      const cl = b.className.slice(0, 60);
      if (txt.match(/^\d{1,2}:\d{2}$/) || txt.toLowerCase().includes('book') || txt.toLowerCase().includes('accept') || txt.toLowerCase().includes('confirm'))
        console.log(`  [${i}] disabled=${b.disabled} text="${txt}" class="${cl}"`);
    });

    // Step 0a: Click a time slot (HH:MM pattern — pill buttons in the date/time grid)
    // Italy uses day-column view with time slots that may be div/span/a elements, not <button>
    console.log('[TLS] Step 0a: looking for time slot elements (all tag types)...');
    // Returns true if el matches the slot preference based on data-testid.
    // data-testid="btn-available-slot-premium" → premium; "btn-available-slot" → standard.
    // Falls back to "any" match when data-testid is absent (non-Germany pages).
    const matchesSlotPref = (el) => {
      if (slotPref === "any") return true;
      const testid = el.dataset?.testid || el.getAttribute("data-testid") || "";
      if (!testid) return true; // no testid → unknown type, don't filter out
      const isPremium = testid === "btn-available-slot-premium";
      if (slotPref === "standard_only") return !isPremium;
      if (slotPref === "premium_only") return isPremium;
      return true;
    };

    const timeSlotBtn = await waitForElement(() => {
      // Strategy 1: Any element with exact HH:MM text — check ALL tag types
      // Italy renders time slots as pill-shaped elements (could be div, span, button, a, td, li)
      const allCandidates = document.querySelectorAll('button, div, span, a, td, li, [role="button"]');
      const timePattern = /^\d{1,2}:\d{2}$/;
      let fallbackMatch = null;

      for (const el of allCandidates) {
        const txt = el.textContent.trim();
        if (!timePattern.test(txt)) continue;
        // Must be visible and not disabled
        if (el.offsetParent === null) continue;
        if (el.disabled || el.closest('[disabled]') || el.getAttribute('aria-disabled') === 'true') continue;
        // Must be a leaf-ish element (no deeply nested children with different text)
        if (el.children.length > 2) continue;
        // Apply slot type preference filter
        if (!matchesSlotPref(el)) continue;

        // Prefer elements that look clickable
        const style = window.getComputedStyle(el);
        if (el.tagName === 'BUTTON' || el.getAttribute('role') === 'button' ||
            style.cursor === 'pointer' || el.onclick || el.tabIndex >= 0) {
          console.log(`[TLS] Step 0a: found clickable time slot: tag=${el.tagName} text="${txt}" class="${el.className?.toString().slice(0,80)}"`);
          return el;
        }
        // Save as fallback — visible element with HH:MM text even if not obviously clickable
        if (!fallbackMatch) fallbackMatch = el;
      }

      // Strategy 2: class-based time slot selectors
      const timeEls = document.querySelectorAll(
        '[class*="time-slot"]:not([disabled]), [class*="TimeSlot"]:not([disabled]), ' +
        '[class*="slot"]:not([disabled]), [class*="AppointmentHour"]:not([disabled]), ' +
        '[class*="appointment-time"]:not([disabled]), [class*="hour"]:not([disabled])');
      for (const el of timeEls) {
        const txt = el.textContent.trim();
        if (timePattern.test(txt) && el.offsetParent !== null && matchesSlotPref(el)) {
          console.log(`[TLS] Step 0a: found class-based time slot: tag=${el.tagName} text="${txt}" class="${el.className?.toString().slice(0,80)}"`);
          return el;
        }
      }

      // Strategy 3: knownTimes from RSC against any visible element
      if (knownTimes && knownTimes.length > 0) {
        const allEls = document.querySelectorAll('button:not([disabled]), [role="button"]:not([aria-disabled="true"]), [tabindex="0"], div, span, a');
        for (const el of allEls) {
          const txt = el.textContent.trim();
          if (knownTimes.includes(txt) && el.offsetParent !== null && el.children.length <= 2 && matchesSlotPref(el)) return el;
        }
      }

      // Strategy 4: return fallback (visible HH:MM element even without pointer cursor)
      if (fallbackMatch) {
        console.log(`[TLS] Step 0a: using fallback time slot: tag=${fallbackMatch.tagName} text="${fallbackMatch.textContent.trim()}" class="${fallbackMatch.className?.toString().slice(0,80)}"`);
        return fallbackMatch;
      }

      return null;
    }, 8000);

    let timeClicked = null;
    if (timeSlotBtn) {
      timeClicked = timeSlotBtn.textContent.trim();
      console.log('[TLS] ✅ Time slot clicked:', timeClicked, Date.now());
      timeSlotBtn.click();
      await sleep(1000); // Wait for Book button to enable
    } else {
      if (slotPref !== "any") {
        // Check if there are ANY available slots on the page that were filtered out
        const anySlots = document.querySelectorAll('[data-testid="btn-available-slot"], [data-testid="btn-available-slot-premium"]');
        if (anySlots.length > 0) {
          const msg = slotPref === "standard_only"
            ? `⚠️ Only premium slots available — skipping (slot preference: standard only)`
            : `⚠️ Only standard slots available — skipping (slot preference: premium only)`;
          console.log('[TLS]', msg);
          diagAction('SLOT_PREF_SKIP', msg);
        }
      }
      console.log('[TLS] ⚠️ No time slot found — falling through to date-first flow (Step 1)');
    }

    // Step 0b: Click "Book your appointment" button ONLY if a time slot was selected
    if (timeClicked) {
    // Italy shows a navy banner with white "Book your appointment" button — may be button, a, or div
    console.log('[TLS] Step 0b: looking for Book button...');
    const bookBtn = await waitForElement(() => {
      // Check all clickable-ish elements, not just <button>
      const candidates = document.querySelectorAll('button:not([disabled]), a:not([disabled]), [role="button"]:not([aria-disabled="true"]), div, span');
      for (const el of candidates) {
        const txt = el.textContent.trim();
        const txtLower = txt.toLowerCase();
        // Primary match: exact "Book your appointment" text (Italy)
        if (txtLower === 'book your appointment' && el.offsetParent !== null) return el;
      }
      // Secondary: partial matches on button-like elements
      const btns = document.querySelectorAll('button:not([disabled]), a:not([disabled]), [role="button"]:not([aria-disabled="true"])');
      for (const btn of btns) {
        const txt = btn.textContent.trim().toLowerCase();
        if (txt.includes('book your appointment') || txt.includes('book appointment') ||
            txt.includes('confirm appointment') ||
            (txt.includes('book') && (btn.className.includes('filled') || btn.className.includes('tertiary') || btn.className.includes('TlsButton')))) {
          return btn;
        }
      }
      return null;
    }, 10000);

    if (bookBtn) {
      const btnText = bookBtn.textContent.trim();
      console.log('[TLS] ✅ Book button clicked:', btnText, Date.now());
      bookBtn.click();
      
      // Step 0c: Wait for navigation after Book button click and verify
      // Italy navigates to an order-summary page — verify we actually got there.
      await sleep(8000);
      // Wait up to 15s for Germany order-summary navigation
      let postBookUrl = window.location.href;
      let postBookText = document.body?.textContent || '';
      for (let i = 0; i < 15; i++) {
        await sleep(1000);
        postBookUrl = window.location.href;
        postBookText = document.body?.textContent || '';
        if (isPostBookingLandmark(postBookUrl, postBookText)) break;
      }
      const bookVerified = isBookingSuccessPage(postBookUrl, postBookText);
      console.log('[TLS] Step 0c: post-book URL:', postBookUrl, 'verified:', bookVerified);
      diagAction('POST_BOOK', `url=${postBookUrl.split('/').slice(-2).join('/')} verified=${bookVerified}`);
      
      console.log('[TLS] ✅ Booking complete!', Date.now());
      chrome.storage.local.set({ _bookingInProgress: false });
      diagAction('BOOKING_SUCCESS', `time=${timeClicked} confirm=${btnText} verified=${bookVerified}`);
      return { booked: true, dateClicked: "time-grid", timeClicked, confirmClicked: btnText, verified: bookVerified };
    }
    
    // If we clicked a time slot but Book button didn't appear — report failure, don't fall to Step 1
      console.log('[TLS] ❌ Time slot clicked but Book button not found — stopping');
      chrome.storage.local.set({ _bookingInProgress: false });
      return { booked: false, error: "no_book_button_after_time", timeClicked };
    } // end if (timeClicked) for Step 0b

    console.log('[TLS] Step 0: no time slots visible — trying date-first flow (Step 1)');

    console.log('[TLS] Step 1: waiting for date buttons via MutationObserver...');
    const dateBtn = await waitForElement(() => {
      // Try multiple selector strategies
      // Strategy A: partial class match (works if hash hasn't changed)
      const flexi = document.querySelectorAll('[class*="AppointmentFlexi"]:not([disabled])');
      if (flexi.length > 0) return flexi[0];

      // Strategy B: any non-disabled button with day number text (1-31)
      const btns = Array.from(document.querySelectorAll('button:not([disabled])')).filter(b => {
        const t = b.textContent.trim();
        return /^\d{1,2}$/.test(t) && parseInt(t) >= 1 && parseInt(t) <= 31;
      });
      if (btns.length > 0) {
        // If we have a target date, try to match it
        if (targetDate) {
          const dayNum = parseInt(targetDate.split('-').pop());
          const match = btns.find(b => parseInt(b.textContent.trim()) === dayNum);
          if (match) return match;
        }
        return btns[0]; // First available date
      }

      // Strategy C: role=button with day number
      const clickable = Array.from(document.querySelectorAll('[role="button"]:not([aria-disabled="true"])')).filter(el => {
        const t = el.textContent.trim();
        return /^\d{1,2}$/.test(t) && parseInt(t) >= 1 && parseInt(t) <= 31;
      });
      if (clickable.length > 0) return clickable[0];

      // Strategy D: DayPicker aria-label selectors (React DayPicker renders dates with aria-label like "Wednesday, April 23, 2026")
      if (targetDate) {
        const dayNum = parseInt(targetDate.split('-').pop());
        const monthNum = parseInt(targetDate.split('-')[1]);
        const monthNames = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
        const monthName = monthNames[monthNum] || '';

        // D1: aria-label containing the day number and month name (e.g., "April 23")
        const ariaSelectors = [
          `button[aria-label*="${monthName} ${dayNum}"]`,
          `td[aria-label*="${monthName} ${dayNum}"]`,
          `[role="gridcell"][aria-label*="${monthName} ${dayNum}"]`,
          `button[aria-label*="${targetDate}"]`,
          `td[aria-label*="${targetDate}"]`,
          `[role="gridcell"][aria-label*="${targetDate}"]`,
        ];
        for (const sel of ariaSelectors) {
          try {
            const el = document.querySelector(sel + ':not([disabled]):not([aria-disabled="true"])');
            if (el) {
              console.log('[TLS] Found date via aria-label selector:', sel, el.getAttribute('aria-label'));
              return el;
            }
          } catch(_) {}
        }

        // D2: data-day or data-date attributes
        const dataSelectors = [
          `[data-day="${targetDate}"]`,
          `[data-date="${targetDate}"]`,
          `[data-day*="${dayNum}"]`,
          `td[data-day="${dayNum}"]`,
        ];
        for (const sel of dataSelectors) {
          try {
            const el = document.querySelector(sel + ':not([disabled]):not([aria-disabled="true"])');
            if (el) {
              console.log('[TLS] Found date via data-attribute selector:', sel);
              return el;
            }
          } catch(_) {}
        }

        // D3: role=gridcell containing the day number anywhere in text
        const gridcells = document.querySelectorAll('[role="gridcell"]:not([aria-disabled="true"])');
        for (const cell of gridcells) {
          const t = cell.textContent.trim();
          if (t.includes(String(dayNum))) {
            console.log('[TLS] Found date via gridcell text:', t);
            return cell;
          }
        }

        // D4: td elements with class containing "day" or "date" (not disabled/outside)
        const dateCells = document.querySelectorAll('td[class*="day"]:not([class*="disabled"]):not([class*="outside"]), td[class*="date"]:not([class*="disabled"]):not([class*="outside"])');
        for (const cell of dateCells) {
          const t = cell.textContent.trim();
          if (t.includes(String(dayNum))) {
            console.log('[TLS] Found date via td class day/date:', t, cell.className.slice(0, 60));
            return cell;
          }
        }

        // D5: Any non-disabled button/td whose text content contains the day number (loose match)
        const allCandidates = document.querySelectorAll('button:not([disabled]), td:not([aria-disabled="true"])');
        for (const el of allCandidates) {
          const t = el.textContent.trim();
          // Match if text contains the day number but isn't too long (avoid matching nav text)
          if (t.length <= 5 && t.includes(String(dayNum))) {
            console.log('[TLS] Found date via loose text match:', t, el.tagName, el.className.slice(0, 40));
            return el;
          }
        }
      }

      return null;
    }, 8000); // 8 second timeout

    if (!dateBtn) {
      const allBtns = Array.from(document.querySelectorAll('button'));
      console.log('[TLS] ❌ Date button not found. All buttons:');
      allBtns.forEach((b, i) => console.log(`  [${i}] disabled=${b.disabled} text="${b.textContent.trim().slice(0,25)}" class="${b.className.slice(0,80)}"`));

      // DOM dump: collect interactive elements for debugging
      const dumpEls = Array.from(document.querySelectorAll('button, td, th, [role="gridcell"], [role="columnheader"], [role="button"], [class*="day"], [class*="date"], [class*="Day"], [class*="Date"]'));
      const dumpLines = dumpEls.slice(0, 35).map((el, i) => {
        const tag = el.tagName.toLowerCase();
        const txt = el.textContent.trim().slice(0, 30);
        const cls = el.className ? String(el.className).slice(0, 50) : '';
        const aria = el.getAttribute('aria-label') || '';
        const role = el.getAttribute('role') || '';
        const dis = el.disabled || el.getAttribute('aria-disabled') === 'true' ? ' DIS' : '';
        return `[${i}]<${tag}${dis}> txt="${txt}" cls="${cls}" aria="${aria}" role="${role}"`;
      });
      const dumpText = `DOM dump (${dumpEls.length} els):\n${dumpLines.join('\n')}`;
      console.log('[TLS]', dumpText);
      diagAction('DOM_DUMP', dumpText);

      chrome.storage.local.set({ _bookingInProgress: false });
      diagAction('BOOKING_FAIL', `no_date_button targetDate=${targetDate}`);
      return { booked: false, error: "no_date_button", targetDate };
    }

    const dateText = dateBtn.textContent.trim();
    dateBtn.click();
    console.log('[TLS] ✅ Date clicked:', dateText, Date.now());

    // Step 2: Wait for time buttons to appear via MutationObserver
    console.log('[TLS] Step 2: waiting for time buttons via MutationObserver...');
    const timeBtn = await waitForElement(() => {
      // Try known times first
      if (knownTimes && knownTimes.length > 0) {
        const allBtns = document.querySelectorAll('button:not([disabled])');
        for (const btn of allBtns) {
          if (knownTimes.includes(btn.textContent.trim()) && matchesSlotPref(btn)) return btn;
        }
      }

      // Strategy A: partial class match
      const hourBtns = document.querySelectorAll('[class*="AppointmentHour"]:not([disabled])');
      for (const btn of hourBtns) {
        if (matchesSlotPref(btn)) return btn;
      }

      // Strategy B: class contains "time" or "slot" or "hour"
      const timeSels = ['button[class*="time"]:not([disabled])', 'button[class*="slot"]:not([disabled])', 'button[class*="hour"]:not([disabled])'];
      for (const sel of timeSels) {
        const el = document.querySelector(sel);
        if (el && matchesSlotPref(el)) return el;
      }

      // Strategy C: HH:MM text pattern
      const allEls = document.querySelectorAll('button:not([disabled]), [role="button"]:not([aria-disabled="true"])');
      for (const el of allEls) {
        if (/^\d{1,2}:\d{2}$/.test(el.textContent.trim()) && matchesSlotPref(el)) return el;
      }

      return null;
    }, 5000); // 5 second timeout

    let timeText = null;
    if (timeBtn) {
      timeText = timeBtn.textContent.trim();
      timeBtn.click();
      console.log('[TLS] ✅ Time clicked:', timeText, Date.now());
    } else {
      console.log('[TLS] ⚠️ No time button found, trying confirm directly...');
    }

    // Step 3: Wait for confirm button via MutationObserver
    console.log('[TLS] Step 3: waiting for confirm button via MutationObserver...');
    const confirmBtn = await waitForElement(() => {
      // Strategy A: data attribute (legacy TLS)
      const dataConfirm = document.querySelector('button[data-tls-value="confirm"]');
      if (dataConfirm) return dataConfirm;

      // Strategy B: text-based matching
      const keywords = ['confirm', 'submit', 'book', 'save', 'reserve', 'apply', 'validate', 'подтвердить'];
      const allBtns = document.querySelectorAll('button:not([disabled])');
      for (const btn of allBtns) {
        const txt = btn.textContent.trim().toLowerCase();
        if (keywords.some(kw => txt.includes(kw))) return btn;
      }

      return null;
    }, 5000);

    if (!confirmBtn) {
      console.log('[TLS] ❌ Confirm button not found. All enabled buttons:');
      Array.from(document.querySelectorAll('button:not([disabled])')).forEach((b, i) => {
        console.log(`  confirm-search[${i}] text="${b.textContent.trim().slice(0,30)}" class="${b.className.slice(0,80)}"`);
      });
      chrome.storage.local.set({ _bookingInProgress: false });
      return { booked: false, error: "no_confirm_button", dateClicked: dateText, timeClicked: timeText };
    }

    confirmBtn.click();
    const confirmText = confirmBtn.textContent.trim();
    console.log('[TLS] ✅ Confirm clicked:', confirmText, Date.now());

    // Verify booking success — wait up to 15s for Germany order-summary navigation
    let confirmPostUrl = window.location.href;
    let confirmPageText = document.body?.textContent || '';
    for (let i = 0; i < 15; i++) {
      await sleep(1000);
      confirmPostUrl = window.location.href;
      confirmPageText = document.body?.textContent || '';
      if (isPostBookingLandmark(confirmPostUrl, confirmPageText)) break;
    }
    const confirmVerified = isBookingSuccessPage(confirmPostUrl, confirmPageText);
    console.log('[TLS] Post-confirm URL:', confirmPostUrl, 'verified:', confirmVerified);
    diagAction('POST_CONFIRM', `url=${confirmPostUrl.split('/').slice(-2).join('/')} verified=${confirmVerified}`);

    chrome.storage.local.set({ _bookingInProgress: false });
    return { booked: true, dateClicked: dateText, timeClicked: timeText, confirmClicked: confirmText, verified: confirmVerified };
  } catch (err) {
    console.error('[TLS] ❌ Booking error:', err.message);
    chrome.storage.local.set({ _bookingInProgress: false });
    return { booked: false, error: err.message };
  }
}

// ─── Message handler ─────────────────────────────────────────────

// Listen for messages from the service worker
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "POLL_NOW") {
    // Wake up selfPoll — used when start polling is clicked from popup
    // Only start polling if we're on a booking page
    if (!getBookingPath()) {
      console.log('[TLS] POLL_NOW received but not on booking page — ignoring');
      sendResponse({ ok: false, reason: 'not_on_booking_page' });
      return true;
    }
    if (_pollTimer) clearTimeout(_pollTimer);
    _pollTimer = setTimeout(selfPoll, 500);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "STOP_POLLING") {
    // Stop selfPoll loop — called by background when user clicks Stop Polling
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    console.log('[TLS] Polling stopped by background message');
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "POLL_RSC") {
    const bookingPath = getBookingPath();
    if (!bookingPath) {
      sendResponse({ status: "not_on_booking_page", url: window.location.href });
      return true;
    }
    doRscFetch(bookingPath).then(result => {
      sendResponse(result);
    });
    return true; // Keep channel open for async response
  }

  if (msg.type === "BOOK_SLOT") {
    attemptBooking(msg.slots).then(result => {
      sendResponse(result);
    });
    return true;
  }

  if (msg.type === "PING") {
    sendResponse({ type: "PONG", ts: Date.now(), url: window.location.href });
    return true;
  }

  if (msg.type === "GET_STATUS") {
    sendResponse({
      onBookingPage: isOnBookingPage(),
      url: window.location.href,
      title: document.title
    });
    return true;
  }
});

// Let the service worker know the content script is ready
chrome.runtime.sendMessage({ type: "CONTENT_READY", url: window.location.href });

// ─── Polling engine ───────────────────────────────────────────────────────────
//
// PRIMARY: RSC fetch every 60-80s (fast, efficient, proven v1.0.x approach)
// BURST:   Slot detected → RSC fetch every 200ms for up to 10s → book on every cycle
// Session cycling handled by background.js (closes tab every 60-90 min for Italy/Germany)
//
let _pollLock = false;
let _lastBookAttempt = 0;
const BOOK_COOLDOWN_MS = 3000;

let _lastAuthAlert = 0;
let _authRecoveryAttempts = 0;
const AUTH_ALERT_COOLDOWN_MS = 5 * 60 * 1000;
const AUTH_RECOVERY_MAX = 2;

// Restore auth recovery attempts from storage to survive page reloads
chrome.storage.local.get(['_authRecoveryAttempts'], (data) => {
  if (data._authRecoveryAttempts) _authRecoveryAttempts = data._authRecoveryAttempts;
});

let _cfBlockCount = 0;
let _cfBackoffUntil = 0;        // Germany only: silent wait after CF block
let _authRetryCount = 0;        // retries before treating auth_error as fatal

// Per-domain idle interval with jitter + dead-zone blackout (2AM-6AM = no polling)
// Italy/Germany: 80-100s business hours | 5 min 11PM-2AM | full stop 2AM-6AM
// Cyprus: 60-120s business hours | 2x slower 11PM-2AM
function _idleIntervalMs() {
  const hour = new Date().getHours();
  // Complete blackout 2AM–6AM: return delay until 6AM so next poll lands after blackout
  if (hour >= 2 && hour < 6) {
    const now = new Date();
    const wakeAt = new Date(now);
    wakeAt.setHours(6, 0, 0, 0);
    return wakeAt - now + Math.floor(Math.random() * 120000); // wake at 6:00-6:02 AM
  }
  const isOffPeak = hour >= 23 || hour < 2; // 11PM–2AM: slow down but still poll
  const r = Math.random();
  const _hostCountryCode = (_matchCountry(_host) || {}).code;
  if (_hostCountryCode === 'it' || _hostCountryCode === 'de') {
    if (isOffPeak) return 300000 + Math.floor(Math.random() * 60000); // ~5 min during 23-2AM
    let base;
    if (r < 0.80) base = 80000 + Math.floor(Math.random() * 20000);       // 80-100s
    else if (r < 0.95) base = 120000 + Math.floor(Math.random() * 60000); // 2-3 min
    else base = 300000 + Math.floor(Math.random() * 300000);
    return base;
  }
  let base;
  if (r < 0.80) base = 60000 + Math.floor(Math.random() * 60000);
  else if (r < 0.95) base = 120000 + Math.floor(Math.random() * 60000);
  else base = 180000 + Math.floor(Math.random() * 180000);
  return isOffPeak ? base * 2 : base;
}

const BURST_INTERVAL_MS = 2000;  // 2s in burst — fast but CF-safe (7-8 fetches vs 50)
const BURST_DURATION_MS = 15000; // burst for up to 15s after slot detected
let _burstUntil = 0;
let _pollTimer = null;

function _nextPollDelay() {
  if (Date.now() < _burstUntil) return BURST_INTERVAL_MS;
  return _idleIntervalMs();
}

// After SPA navigation (click Select/Continue), wait for booking page then restart polling
function _waitAndRestartPolling() {
  let checks = 0;
  const maxChecks = 30; // 30 × 2s = 60s max wait
  const interval = setInterval(() => {
    checks++;
    if (getBookingPath()) {
      clearInterval(interval);
      console.log('[TLS] ✅ Booking page detected after SPA nav — restarting polling');
      if (_pollTimer) clearTimeout(_pollTimer);
      _pollTimer = setTimeout(selfPoll, 2000);
    } else if (checks >= maxChecks) {
      clearInterval(interval);
      console.log('[TLS] ⚠️ Booking page not reached after SPA nav — running smartRecover');
      // Don't blindly poll — run recovery to handle whatever page we're on
      smartRecover();
    }
  }, 2000);
}

function _schedulePoll() {
  // Guard: only schedule polling on booking pages
  if (!getBookingPath()) {
    console.log('[TLS] _schedulePoll: not on booking page — skipping');
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    return;
  }
  if (_pollTimer) clearTimeout(_pollTimer);
  _pollTimer = setTimeout(async () => {
    await selfPoll();
    // Only reschedule if selfPoll didn't clear _pollTimer (i.e. we're still on booking page)
    if (_pollTimer !== null) {
      _schedulePoll();
    }
  }, _nextPollDelay());
}

let _contentPollCount = 0;

async function selfPoll() {
  if (_pollLock) return;
  // Skip RSC fetch entirely while booking is in progress — DOM clicks don't need server calls
  const bookState = await chrome.storage.local.get(['_bookingInProgress']);
  if (bookState._bookingInProgress) {
    console.log('[TLS] selfPoll: booking in progress — skipping RSC fetch');
    return;
  }
  // Stop gracefully if extension was reloaded (auto-update)
  if (!isExtensionAlive()) {
    console.log('[TLS] Extension context invalidated — stopping poll');
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    return;
  }
  // Re-check polling_enabled on every cycle — catches stopPolling() from background
  const pollState = await chrome.storage.local.get(['polling_enabled']);
  if (pollState.polling_enabled === false) {
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    return;
  }

  // Quiet hours 02:00–06:00 Yerevan (UTC+4) — Germany and Italy only, Cyprus exempt
  const _selfPollCode = (_matchCountry(_host) || {}).code;
  if (_selfPollCode === 'de' || _selfPollCode === 'it') {
    const yerevanHour = (new Date().getUTCHours() + 4) % 24;
    if (yerevanHour >= 2 && yerevanHour < 6) {
      const now = new Date();
      // 06:00 Yerevan = 02:00 UTC
      let msUntilWake = ((2 - now.getUTCHours() + 24) % 24) * 3600000
                       - now.getUTCMinutes() * 60000
                       - now.getUTCSeconds() * 1000
                       - now.getUTCMilliseconds();
      if (msUntilWake <= 0) msUntilWake += 24 * 3600000;
      const country = (_matchCountry(_host) || { label: _host }).label;
      console.log(`[TLS] 🌙 ${country} quiet hours (${yerevanHour}:xx Yerevan) — pausing until 06:00`);
      if (_pollTimer) clearTimeout(_pollTimer);
      _pollTimer = setTimeout(selfPoll, msUntilWake);
      return;
    }
  }

  const bookingPath = getBookingPath();
  if (!bookingPath) {
    // Not on booking page — stop polling entirely. Navigation handlers will restart
    // polling via _waitAndRestartPolling() when we land on booking page.
    console.log('[TLS] ⚠️ Not on booking page — stopping poll. Nav handlers will restart.');
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    return;
  }

  // Next.js "Application error: a client-side exception" — transient rendering crash.
  // URL is still the booking URL so getBookingPath() passes, but the calendar UI is gone.
  // Refresh up to 5 times; page self-heals after 1-3 refreshes in practice.
  const _appErrKey = `_app_error_count_${_host}`;
  const _pageBodyText = document.body?.textContent || '';
  if (_pageBodyText.includes('Application error: a client-side exception has occurred')) {
    const errState = await chrome.storage.local.get([_appErrKey]);
    const errCount = (errState[_appErrKey] || 0) + 1;
    if (errCount <= 15) {
      console.log(`[TLS] Next.js app error (attempt ${errCount}/15) — refreshing`);
      diagAction('APP_ERROR_REFRESH', `attempt=${errCount}`);
      await chrome.storage.local.set({ [_appErrKey]: errCount });
      await sleep(1000 + Math.floor(Math.random() * 1000));
      location.reload();
      return;
    }
    console.log('[TLS] Next.js app error — max retries reached, alerting Arto');
    diagAction('APP_ERROR_STUCK', 'max retries reached');
    await chrome.storage.local.remove([_appErrKey]);
    chrome.runtime.sendMessage({ type: "CF_RATE_LIMITED", url: window.location.href, page_step: 'app_error_stuck' });
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    return;
  }
  // Clear app error counter once we're past a healthy page check
  chrome.storage.local.remove([_appErrKey]);

  // Post-month-nav-redirect settle time: wait 10s after URL redirect for month navigation.
  // Prevents 429 from an immediate RSC fetch right after the page reload.
  const _mnNavKey = `_month_nav_ts_${_host}`;
  const mnNavState = await chrome.storage.local.get([_mnNavKey]);
  if (mnNavState[_mnNavKey]) {
    const elapsed = Date.now() - mnNavState[_mnNavKey];
    const settleMs = 10000; // 10 seconds settle after month-nav redirect
    if (elapsed < settleMs) {
      const remaining = Math.round((settleMs - elapsed) / 1000);
      console.log(`[TLS] Month-nav settle — waiting ${remaining}s before RSC fetch`);
      _pollTimer = setTimeout(selfPoll, settleMs - elapsed);
      _pollLock = false;
      return;
    }
    await chrome.storage.local.remove([_mnNavKey]);
  }

  // Post-CF-recovery settle time: wait 90s after fresh tab recovery before first RSC fetch
  // Prevents immediate re-block when arriving at booking page after CF recovery
  const _cfRecKey = `_cf_recovery_ts_${_host}`;
  const recState = await chrome.storage.local.get([_cfRecKey]);
  if (recState[_cfRecKey]) {
    const elapsed = Date.now() - recState[_cfRecKey];
    const settleMs = 90000; // 90 seconds settle time
    if (elapsed < settleMs) {
      const remaining = Math.round((settleMs - elapsed) / 1000);
      diagAction('RECOVERY_SETTLE', `waiting ${remaining}s before first poll`);
      _pollTimer = setTimeout(selfPoll, settleMs - elapsed);
      return;
    }
    // Settle time passed — clear the flag
    await chrome.storage.local.remove([_cfRecKey]);
  }

  _pollLock = true;
  try {
    // CF backoff active — wait and reschedule
    if (Date.now() < _cfBackoffUntil) {
      const remaining = Math.round((_cfBackoffUntil - Date.now()) / 1000);
      chrome.storage.local.set({ last_poll: Date.now(), last_status: `cf_backoff_${remaining}s` });
      _pollTimer = setTimeout(selfPoll, 10000);
      _pollLock = false;
      return;
    }

    // ─── RSC fetch — primary polling method ───────────────────────────────
    const inBurst = Date.now() < _burstUntil;
    if (inBurst) {
      console.log('[TLS] ⚡ Burst mode — RSC fetch at 200ms');
    }
    const result = await doRscFetch(bookingPath);

    // Check for Turnstile challenge on the page
    const hasTurnstile = document.querySelector('iframe[src*="challenges.cloudflare"]') ||
                         document.querySelector('.cf-turnstile') ||
                         document.querySelector('[data-sitekey]');
    if (hasTurnstile) {
      console.log('[TLS] 🔓 Turnstile challenge detected — requesting solver');
      chrome.runtime.sendMessage({ type: "CF_CHALLENGE_DETECTED", url: window.location.href });
    }

    // CF rate-limit detection
    // Fix B: On 1015/rate-limit, do NOT reload — just set backoff and wait silently.
    // Reloading triggers smartRecover chain (5-15 additional requests) during the exact
    // window CF is watching, making the block worse.
    const _isHardBlock = result?.raw && result.raw.includes("1015");
    if (_isHardBlock || result?.code === 429 || result?.code === 403) {
      _cfBlockCount++;
      _burstUntil = 0;
      chrome.storage.local.set({ [`pending_booking_url_${_host}`]: window.location.href });
      if (_cfBlockCount === 1) {
        diagAction('CF_BLOCKED', `block#${_cfBlockCount} poll#${_contentPollCount} hard=${_isHardBlock}`);
        // Hard block (1015) = IP-level ban — rotate proxy. Soft block (403) = backoff only.
        const msgType = _isHardBlock ? "CF_HARD_BLOCK" : "CF_RATE_LIMITED";
        chrome.runtime.sendMessage({ type: msgType, url: window.location.href, page_step: getPageStep() });
      }

      // Silent backoff — NO reload, NO navigation. Just wait.
      // Escalating schedule: 5 → 15 → 30 → 60 → 120 → 240 min
      const BACKOFF_STEPS_MS = [5, 15, 30, 60, 120, 240].map(m => m * 60 * 1000);
      const backoffMs = BACKOFF_STEPS_MS[Math.min(_cfBlockCount - 1, BACKOFF_STEPS_MS.length - 1)];
      _cfBackoffUntil = Date.now() + backoffMs;
      // Persist to chrome.storage so background.js and fresh tabs can see it
      const _cfBkStorageKey = `_cf_backoff_until_${_host}`;
      chrome.storage.local.set({ [_cfBkStorageKey]: _cfBackoffUntil });
      console.log(`[TLS] ⚠️ CF block (${_host}) — silent backoff ${Math.round(backoffMs / 60000)}min (NO reload)`);
      // Schedule next poll check after backoff expires
      if (_pollTimer) clearTimeout(_pollTimer);
      _pollTimer = setTimeout(selfPoll, backoffMs + 5000);
      return;
    }

    // Update popup + save booking URL
    const pollData = {
      last_poll: Date.now(),
      last_status: result?.status || "error",
      last_slots: result?.slots || []
    };
    if (isOnBookingPage()) pollData[`pending_booking_url_${_host}`] = window.location.href;
    chrome.storage.local.set(pollData);

    // DIAG logging
    _contentPollCount++;
    const isNormal = result?.status === "no_slots";
    if (_contentPollCount === 1 || !isNormal || _contentPollCount % 20 === 0) {
      const country = countryLabelFor(window.location.hostname);
      chrome.runtime.sendMessage({
        type: "CONTENT_DIAG",
        text: `[${country}] ${result?.status || "unknown"} | slots: ${result?.slots?.length || 0}`
      });
    }

    if (result?.status === "auth_error") {
      const country = countryLabelFor(_host);
      _authRetryCount++;
      if (_authRetryCount <= 3) {
        // Retry up to 3× before stopping — handles transient server errors
        console.log(`[TLS] 🔑 Auth error (${country}) — retry ${_authRetryCount}/3 in 30s`);
        _pollTimer = setTimeout(selfPoll, 30000);
        return;
      }
      // 3 retries exhausted — session truly expired
      _authRetryCount = 0;
      if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
      console.log(`[TLS] 🔑 Auth error (${country}) — 3 retries failed, alerting Arto`);
      chrome.runtime.sendMessage({ type: "SESSION_EXPIRED", url: window.location.href, country });
      return;
    }

    // TLS server error (500)
    if (result?.status === "server_error") {
      console.log(`[TLS] ⚠️ TLS server error ${result.code} — retrying next cycle`);
      chrome.storage.local.set({ [`pending_booking_url_${_host}`]: window.location.href });
      return;
    }

    if (result?.status === "no_slots" || result?.status === "available") {
      if (_authRecoveryAttempts > 0) {
        _authRecoveryAttempts = 0;
        chrome.storage.local.set({ _authRecoveryAttempts: 0 });
      }
      _cfBlockCount = 0;
      _cfBackoffUntil = 0;
      _authRetryCount = 0;
    }

    if (result?.status === "available" && result.slots?.length > 0) {
      if (Date.now() >= _burstUntil) {
        _burstUntil = Date.now() + BURST_DURATION_MS;
        console.log('[TLS] 🎯 SLOT DETECTED — entering burst mode (200ms RSC fetch)');
      }

      const now = Date.now();
      if (now - _lastBookAttempt < BOOK_COOLDOWN_MS) return;
      _lastBookAttempt = now;

      logDomDiagnostics(result.slots);

      // Check if "Book your appointment" button is already enabled
      const bookBtn = Array.from(document.querySelectorAll('button:not([disabled])')).find(b => {
        const txt = b.textContent.trim().toLowerCase();
        return txt.includes('book your appointment') || txt.includes('book appointment');
      });

      if (bookBtn) {
        console.log('[TLS] ✅ Book button enabled on current page — clicking!');
        chrome.storage.local.set({ _bookingInProgress: true });
        bookBtn.click();
        // Wait for navigation — Germany goes to order-summary, wait up to 15s.
        // Break early once we see any post-booking URL or text landmark.
        let postUrl = window.location.href;
        let postUrlText = document.body?.textContent || '';
        for (let i = 0; i < 15; i++) {
          await sleep(1000);
          postUrl = window.location.href;
          postUrlText = document.body?.textContent || '';
          if (_anyMatch(postUrl, BOOKING_SUCCESS_URL_PARTS) ||
              isPostBookingLandmark(postUrl, postUrlText)) break;
        }
        const verified = isBookingSuccessPage(postUrl, postUrlText);
        diagAction('POST_CONFIRM_ALT', `url=${postUrl.split('/').slice(-2).join('/')} verified=${verified}`);
        chrome.storage.local.set({ _bookingInProgress: false });
        chrome.runtime.sendMessage({
          type: "BOOKING_ATTEMPTED", domDump: getDomDump(),
          bookResult: { booked: true, dateClicked: "direct-click", timeClicked: null, confirmClicked: bookBtn.textContent.trim(), verified },
          slots: result.slots,
          url: postUrl
        });
        _burstUntil = 0;
        if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
        console.log('[TLS] 🛑 POLLING STOPPED — booking successful');
        return;
      }

      // No Book button visible yet — try attemptBooking first (uses MutationObserver
      // to wait for DOM elements). Only reload as last resort to avoid 3-5s latency.
      const bookResult = await attemptBooking(result.slots);

      // If booking failed because no DOM elements appeared, reload page as fallback
      if (!bookResult?.booked && !window._bookReloadDone &&
          (bookResult?.error === 'no_date_button' || bookResult?.error === 'no_book_button_after_time' || bookResult?.error === 'no_time_button')) {
        window._bookReloadDone = true;
        console.log('[TLS] 🔄 attemptBooking failed (' + bookResult.error + ') — reloading page as fallback');
        chrome.storage.local.set({ _pendingBookSlots: JSON.stringify(result.slots) });
        window.location.reload();
        return;
      }
      window._bookReloadDone = false;
      console.log('[TLS] Booking result:', bookResult);

      chrome.runtime.sendMessage({
        type: "BOOKING_ATTEMPTED", domDump: getDomDump(),
        bookResult,
        slots: result.slots,
        url: window.location.href
      });

      if (bookResult?.booked) {
        _burstUntil = 0;
        if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
        console.log('[TLS] 🛑 POLLING STOPPED — booking successful, no more requests');
        return;
      }
    }
  } catch (e) {
    // Silent — never crash the loop
  } finally {
    _pollLock = false;
  }
}

// Start RSC polling only if polling is enabled AND we're on a booking page
(async () => {
  const state = await chrome.storage.local.get(['polling_enabled']);
  if (state.polling_enabled === false) {
    console.log('[TLS] Polling disabled — waiting for Start Polling click');
    return;
  }
  if (!getBookingPath()) {
    console.log('[TLS] Not on booking page — polling will start when we navigate there');
    return;
  }
  // If we reloaded due to a Next.js app error, run selfPoll immediately
  // (don't wait for the normal 60-180s delay — the error needs fast retry)
  const _appErrState = await chrome.storage.local.get([`_app_error_count_${_host}`]);
  if (_appErrState[`_app_error_count_${_host}`] > 0) {
    // Before retrying, wait for any active CF challenge to auto-resolve (Chrome handles these automatically)
    for (let i = 0; i < 15; i++) {
      const isChallenge = document.title.toLowerCase().includes('just a moment') ||
                          (document.body?.textContent || '').includes('Verify you are human') ||
                          !!document.querySelector('iframe[src*="challenges.cloudflare"]');
      if (!isChallenge) break;
      console.log(`[TLS] App error retry — CF challenge active, waiting 2s (${i + 1}/15)`);
      await new Promise(r => setTimeout(r, 2000));
    }
    console.log('[TLS] App error retry reload — running selfPoll immediately');
    await selfPoll();
    if (_pollTimer !== null) _schedulePoll();
  } else {
    _schedulePoll();
  }
  console.log('[TLS] RSC polling started — idle 60-150s / burst 2s on slot detect');
})();

// ─── Check for pending booking after page reload ─────────────────────
(async function checkPendingBook() {
  if (!isOnBookingPage()) return;
  const stored = await chrome.storage.local.get(['_pendingBookSlots']);
  if (!stored._pendingBookSlots) return;
  
  const slots = JSON.parse(stored._pendingBookSlots);
  await chrome.storage.local.remove('_pendingBookSlots');
  console.log('[TLS] 📌 Pending booking found after reload — attempting booking with', slots.length, 'slots');
  
  // Wait for page to fully render (React hydration + server state)
  await new Promise(r => setTimeout(r, 3000));
  
  const bookResult = await attemptBooking(slots);
  console.log('[TLS] Booking result after reload:', bookResult);
  
  chrome.runtime.sendMessage({
    type: "BOOKING_ATTEMPTED", domDump: getDomDump(),
    bookResult,
    slots,
    url: window.location.href
  });
})();

// Save current booking URL proactively — used for recovery after session expiry, CF block, crash
if (isOnBookingPage()) {
  const fullBookingUrl = window.location.href; // includes all query params
  chrome.storage.local.set({ [`pending_booking_url_${_host}`]: fullBookingUrl });
  console.log('[TLS] 📌 Booking URL saved for recovery:', fullBookingUrl);
}

// ─── Service worker keepalive ────────────────────────────────────────────────
// MV3 service workers die after 30s inactivity. Persistent port keeps SW alive.
// Port auto-reconnects after page reload (content script re-injects, re-connects).
(function keepSWAlive() {
  let port = null;
  function connect() {
    try {
      port = chrome.runtime.connect({ name: 'keepalive' });
      port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 1000); });
    } catch(e) {}
  }
  connect();
  setInterval(() => { if (port) port.postMessage('ping'); else connect(); }, 25000);
})();

// ─── Session keepalive (every 8 min) ─────────────────────────────────────────
// Two strategies depending on what the portal supports:
//
// 1. Keycloak (Italy/Cyprus): call window.keycloak.updateToken() — silent POST
//    to auth subdomain, CF-invisible, keeps session alive indefinitely.
//
// 2. Non-Keycloak (Germany): fetch a lightweight page endpoint with same-origin
//    credentials. Germany uses httpOnly cookies (invisible to JS), so we can't
//    read the session but the browser sends it automatically on any fetch.
//    Fetching the VAC landing page (tiny, cached) refreshes the session server-side.
//    Runs during CF backoff too — keepalive is separate from RSC polling.
//
// 8 min interval: safe for any session timeout >= 10 min.
setInterval(async () => {
  if (typeof window.keycloak !== "undefined" && window.keycloak.updateToken) {
    // Keycloak portal — silent token refresh
    window.keycloak.updateToken(1800)
      .then(refreshed => {
        if (refreshed) console.log('[TLS] 🔑 Keycloak token refreshed');
      })
      .catch(() => {
        console.log('[TLS] ⚠️ Keycloak token refresh failed — session may be expired');
      });
  } else {
    // Non-Keycloak portal: RSC polling already keeps session alive.
    // HEAD pings were causing extra CF requests → rate limiting.
    // Disabled — polling every 60-80s is sufficient for session keepalive.
    console.log('[TLS] 🔑 Keepalive skipped — RSC polling handles session');
  }
}, 8 * 60 * 1000); // every 8 minutes

// ─── Auto re-login on login page ─────────────────────────────────────────────
// If the page is a TLS login page, automatically fill credentials and submit.
// Credentials are stored per-country in Chrome extension storage (Options page).
// Runs once on page load — detects login form presence.
// ─── Turnstile detection on page load ─────────────────────────────────
// CF may redirect the entire page to a challenge. Detect and solve on load.
let _turnstileSent = false;
(function detectTurnstileOnLoad() {
  function check() {
    if (_turnstileSent) return; // Only send once per page load
    // Only detect Turnstile on CF challenge pages or booking pages — NOT on landing/country pages
    // Landing page has [data-sitekey] for country selection widget, not a real CF block
    const path = window.location.pathname;
    const isLandingOrCountry = path === '/en-us' || path === '/en-us/' ||
                               path.match(/^\/[a-z]{2}-[a-z]{2,4}\/?$/) ||
                               path.includes('/country/');
    if (isLandingOrCountry) return; // Skip Turnstile detection on landing/country pages

    const hasTurnstile = document.querySelector('iframe[src*="challenges.cloudflare"]') ||
                         document.querySelector('.cf-turnstile') ||
                         document.title.toLowerCase().includes('just a moment') ||
                         document.body?.textContent?.includes('Verify you are human');
    if (hasTurnstile) {
      _turnstileSent = true;
      console.log('[TLS] 🔓 Turnstile challenge detected on page load — requesting solver');
      chrome.runtime.sendMessage({ type: "CF_CHALLENGE_DETECTED", url: window.location.href });
    }
  }
  check();
  setTimeout(check, 2000);
  setTimeout(check, 5000);
})();

// ─── Smart Recovery (runs on every page load) ─────────────────────────
// Simplified: no auto-navigation. On non-booking pages, alert Arto and stop.
// Human recovers — bot resumes automatically when booking page is open again.
async function smartRecover() {
  const host = window.location.hostname;
  if (!host.includes('tlscontact.com')) return;

  // Don't auto-navigate when monitoring is stopped
  const { polling_enabled } = await chrome.storage.local.get(['polling_enabled']);
  if (polling_enabled === false) return;

  // On booking page — nothing to do
  if (getBookingPath()) return;

  const country = countryLabelFor(host);
  const pageText = document.body?.textContent || '';

  // CF "Just a moment" — managed challenge that auto-resolves in 5-10s if left alone.
  // DO NOT navigate away — that interrupts the challenge and causes an infinite loop.
  // Wait up to 25s for CF to auto-solve, then alert Arto if still stuck.
  const isJustAMoment = document.title.toLowerCase().includes('just a moment') ||
                        pageText.includes('Verify you are human') ||
                        pageText.includes('I\'m not a robot');
  if (isJustAMoment) {
    console.log('[TLS] CF "Just a moment" — waiting up to 25s for auto-resolve (not navigating)');
    diagAction('CF_JUST_A_MOMENT', `url=${window.location.href}`);
    for (let i = 0; i < 12; i++) {
      await new Promise(r => setTimeout(r, 2200));
      if (!document.title.toLowerCase().includes('just a moment') &&
          !document.body?.textContent?.includes('Verify you are human') &&
          !document.body?.textContent?.includes('I\'m not a robot')) {
        console.log('[TLS] CF "Just a moment" resolved after ~' + ((i + 1) * 2) + 's');
        return;
      }
    }
    console.log('[TLS] CF "Just a moment" stuck after 25s — alerting Arto');
    chrome.runtime.sendMessage({ type: "CF_RATE_LIMITED", url: window.location.href, page_step: 'just_a_moment_stuck' });
    return;
  }

  // CF hard block page detection — "Attention Required" / "Sorry, you have been blocked"
  const isCfBlockPage = document.title.includes('Attention Required') ||
                        document.title.includes('Sorry') ||
                        pageText.includes('Sorry, you have been blocked');
  if (isCfBlockPage) {
    // Guard: if already on VAC landing and still blocked, stop — avoid infinite loop
    const currentPath = window.location.pathname;
    if (currentPath.includes('/vac/') || currentPath === '/en-us/login') {
      console.log('[TLS] CF hard block on VAC landing — cannot auto-recover, alerting Arto');
      chrome.runtime.sendMessage({ type: "CF_RATE_LIMITED", url: window.location.href, page_step: 'vac_hard_block' });
      return;
    }
    console.log('[TLS] CF hard block — navigating to VAC landing to clear it');
    await new Promise(r => setTimeout(r, 2000));
    window.location.href = `https://${host}${vacPathFor(host)}`;
    return;
  }

  // Order summary / payment page — slot reserved, stop polling
  const path = window.location.pathname;
  if (path.includes('/order-summary') || path.includes('/checkout') || path.includes('/payment') ||
      path.includes('/application-summary') || path.includes('/confirmation')) {
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    chrome.storage.local.set({ polling_enabled: false });
    return;
  }

  // Keycloak "We are sorry / Invalid Request" — stale OAuth state.
  // Must check BEFORE the auth./login bail-out because error can appear on auth subdomain.
  // Navigate to VAC landing (not /en-us/login) to avoid looping back into the same error.
  if (pageText.includes('We are sorry') || pageText.includes('Invalid Request') ||
      pageText.includes('invalid_request') || pageText.includes('activation email')) {
    console.log('[TLS] Keycloak error page — navigating to VAC landing for fresh OAuth flow');
    await new Promise(r => setTimeout(r, 2000));
    // If on auth subdomain, build URL for the main TLS host
    const mainHost = host.startsWith('auth.') ? host.replace(/^auth\./, '') : host;
    window.location.href = `https://${mainHost}${vacPathFor(mainHost)}`;
    return;
  }

  // On login or auth pages — tab-based reauth in progress, don't fire SESSION_EXPIRED loop
  if (path.includes('/login') || window.location.hostname.startsWith('auth.')) {
    console.log(`[TLS] On login/auth page — tab reauth in progress, waiting`);
    return;
  }

  // Landing page (/en-us) — navigate to VAC page directly
  if (path === '/en-us' || path === '/en-us/' || path === '/') {
    console.log('[TLS] Landing page — navigating to VAC page');
    await new Promise(r => setTimeout(r, 3000 + Math.random() * 2000));
    window.location.href = window.location.origin + vacPathFor(host);
    return;
  }

  // VAC/country page — click LOGIN button
  if (path.includes('/place/') || path.includes('/vac/') || path.match(/\/en-us\/country\/[a-z]+\/?$/)) {
    console.log('[TLS] VAC/country page — clicking LOGIN');
    await new Promise(r => setTimeout(r, 4000 + Math.random() * 2000));
    const loginBtn = Array.from(document.querySelectorAll('a, button')).find(b =>
      b.textContent.trim().toUpperCase() === 'LOGIN');
    if (loginBtn) { loginBtn.click(); return; }
    window.location.href = window.location.origin + '/en-us/login';
    return;
  }

  // Application manager / travel-groups — click Select to proceed to booking
  if (path.includes('travel-groups') || path.includes('redirect-group') || path.includes('applications')) {
    console.log(`[TLS] Application manager — clicking Select`);
    await new Promise(r => setTimeout(r, 3500 + Math.random() * 2000));
    const selectBtn = Array.from(document.querySelectorAll('button')).find(b =>
      b.textContent.trim().toLowerCase() === 'select');
    if (selectBtn) { selectBtn.click(); _waitAndRestartPolling(); return; }
    // Select button not found yet — wait and retry on next page load
    return;
  }

  // Services page — click Continue to skip optional services
  if (path.includes('service-level') || path.includes('/services') || path.includes('/book/offices')) {
    console.log(`[TLS] Services page — clicking Continue`);
    await new Promise(r => setTimeout(r, 3500 + Math.random() * 2000));
    const continueBtn = Array.from(document.querySelectorAll('button, a')).find(b => {
      const t = b.textContent.trim().toLowerCase();
      return t === 'continue' || t === 'next' || t === 'skip';
    });
    if (continueBtn) { continueBtn.click(); _waitAndRestartPolling(); return; }
    return;
  }

  // Any other non-booking page: session ended or CF blocked — alert Arto, stop
  if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
  console.log(`[TLS] Not on booking page (${path}) — alerting Arto`);
  chrome.runtime.sendMessage({ type: "SESSION_EXPIRED", url: window.location.href, country, path });
}

// Run smartRecover on page load to handle non-booking TLS pages
(async () => { await smartRecover(); })();

// ─── Login auto-fill: TLS main domain + Keycloak auth subdomain ─────────────
// Handles two scenarios:
//   1. TLS main domain login page: visas-*.tlscontact.com/en-us/login
//      (React SPA with email field — may or may not have password on same step)
//   2. Keycloak OAuth page: auth.visas-*.tlscontact.com
//      (Keycloak form with #username + #password)
(async function keycloakAutoFill() {
  const _kcHost = window.location.hostname;
  const _kcPath = window.location.pathname;

  const isKeycloak = _kcHost.startsWith('auth.') && _kcHost.includes('tlscontact.com');
  const isTlsLogin = _kcHost.includes('tlscontact.com') && !_kcHost.startsWith('auth.') && _kcPath.includes('/login');

  if (!isKeycloak && !isTlsLogin) return;

  // Wait for login form fields to render
  let _kcAttempts = 0;
  const waitForForm = () => new Promise(resolve => {
    const check = () => {
      let u, p;
      if (isKeycloak) {
        u = document.querySelector('#username') || document.querySelector('input[name="username"]');
        p = document.querySelector('#password') || document.querySelector('input[name="password"]');
      } else {
        // TLS main domain — try email-type selectors first, fall back to username
        u = document.querySelector('input[type="email"]') ||
            document.querySelector('#email') ||
            document.querySelector('input[name="email"]') ||
            document.querySelector('#email-input-field') ||
            document.querySelector('#username') ||
            document.querySelector('input[name="username"]');
        p = document.querySelector('input[type="password"]') ||
            document.querySelector('#password') ||
            document.querySelector('input[name="password"]');
      }
      if (u && p) { resolve({ u, p }); return; }
      // TLS main domain may use a multi-step flow: email first, then password on next step.
      // If we have the email field but no password after 3s, fill email and submit to proceed.
      if (isTlsLogin && u && !p && _kcAttempts > 6) { resolve({ u, p: null }); return; }
      if (++_kcAttempts > 20) { resolve(null); return; }
      setTimeout(check, 500);
    };
    check();
  });

  const fields = await waitForForm();
  if (!fields) {
    console.log('[TLS] 🔑 Login form not found after 10s — skipping auto-fill');
    return;
  }

  const cfg = await chrome.storage.local.get(['tls_email', 'tls_password']);
  if (!cfg.tls_email) {
    console.log('[TLS] 🔑 No credentials in storage — cannot auto-fill login form');
    return;
  }

  // Fill via native setter to trigger React/Keycloak change detection
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  nativeSetter.call(fields.u, cfg.tls_email);
  fields.u.dispatchEvent(new Event('input', { bubbles: true }));
  fields.u.dispatchEvent(new Event('change', { bubbles: true }));

  // Human-like pause between email and password (v1.1.x timing: 800-1400ms)
  await new Promise(r => setTimeout(r, 800 + Math.random() * 600));

  if (fields.p && cfg.tls_password) {
    nativeSetter.call(fields.p, cfg.tls_password);
    fields.p.dispatchEvent(new Event('input', { bubbles: true }));
    fields.p.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Human-like pause before clicking submit (v1.1.x timing: 1500-2500ms)
  await new Promise(r => setTimeout(r, 1500 + Math.random() * 1000));

  // Find submit button — try specific IDs, then type, then button text
  const submitBtn = document.querySelector('#btn-login') ||
                    document.querySelector('#kc-login') ||
                    document.querySelector('button[type="submit"]') ||
                    document.querySelector('input[type="submit"]') ||
                    Array.from(document.querySelectorAll('button')).find(b =>
                      ['login', 'sign in', 'se connecter', 'connexion', 'next', 'continue'].includes(
                        b.textContent.trim().toLowerCase()
                      )
                    );

  if (submitBtn) {
    console.log(`[TLS] 🔑 Login auto-fill complete (${isKeycloak ? 'Keycloak' : 'TLS main'}) — submitting`);
    submitBtn.click();
  } else {
    console.log('[TLS] 🔑 Submit button not found — auto-fill incomplete');
  }
})();

// Handle bfcache restore — Chrome may restore page from cache, killing message channel
// pageshow with persisted=true = restored from bfcache → restart polling
window.addEventListener('pageshow', (event) => {
  if (event.persisted && getBookingPath()) {
    console.log('[TLS] 📦 Page restored from bfcache on booking page — restarting poll');
    if (_pollTimer) clearTimeout(_pollTimer);
    _pollTimer = setTimeout(selfPoll, 1000);
  }
});

// ─── Polling watchdog — catches ALL cases where polling silently dies ─────────
// Runs every 30s. If we're on booking page, polling is enabled, and last poll
// was >4 min ago, force-restart polling. This is the safety net for SPA nav,
// CF recovery, error page redirects, and any other case we missed.
let _lastPollTs = Date.now();
const _origSelfPoll = selfPoll;
selfPoll = async function() {
  // Only update poll timestamps when actually on booking page
  if (getBookingPath()) {
    _lastPollTs = Date.now();
    chrome.storage.local.set({ last_poll: Date.now() });
  }
  return _origSelfPoll();
};

// ─── Inline Web Worker watchdog — NOT throttled by Chrome tab suspension ─────
// Regular setInterval is throttled to 1/min in background tabs and can freeze entirely.
// Web Workers run on a separate thread and are NOT subject to tab throttling.
try {
  const workerBlob = new Blob([`
    setInterval(() => { postMessage('check'); }, 15000);
  `], { type: 'application/javascript' });
  const watchdogWorker = new Worker(URL.createObjectURL(workerBlob));
  watchdogWorker.onmessage = async () => {
    const staleSec = (Date.now() - _lastPollTs) / 1000;
    if (staleSec > 180 && !!getBookingPath()) {
      const pollState = await chrome.storage.local.get(['polling_enabled']);
      if (pollState.polling_enabled !== false) {
        console.log('[TLS] 🔧 Worker watchdog: polling stale (' + Math.round(staleSec) + 's) — restarting');
        if (_pollTimer) clearTimeout(_pollTimer);
        _pollTimer = setTimeout(selfPoll, 1000);
      }
    }
  };
  console.log('[TLS] 🔧 Worker watchdog started — checks every 15s');
} catch (e) {
  // Fallback to setInterval if Web Worker not available
  console.log('[TLS] ⚠️ Worker watchdog failed, using setInterval fallback:', e.message);
  setInterval(async () => {
    const onBooking = !!getBookingPath();
    const pollState = await chrome.storage.local.get(['polling_enabled']);
    const enabled = pollState.polling_enabled !== false;
    const staleSec = (Date.now() - _lastPollTs) / 1000;
    if (onBooking && enabled && staleSec > 180) {
      console.log('[TLS] 🔧 Watchdog: polling stale (' + Math.round(staleSec) + 's) — restarting');
      if (_pollTimer) clearTimeout(_pollTimer);
      _pollTimer = setTimeout(selfPoll, 1000);
    }
  }, 30000);
}

} // end injection guard

// ═══════════════════════════════════════════════════════════════════════════════
// VFS GLOBAL — Slot Monitoring + Hands-Free Booking Content Script
// Runs only on visa.vfsglobal.com pages. Completely separate from TLS logic.
//
// Hands-free state machine:
//   vfs_login → vfs_dashboard → vfs_step1 → vfs_step2_details →
//   vfs_step2_upload → vfs_otp → vfs_step3_calendar → vfs_step3_timeslot →
//   vfs_review → vfs_booked
// ═══════════════════════════════════════════════════════════════════════════════

if (window.location.hostname === 'visa.vfsglobal.com') {

// VFS injection guard — prevent double-injection
if (!window.__vfsSlotFinderInjected) {
window.__vfsSlotFinderInjected = true;

// ─── VFS Country Configuration ────────────────────────────────────────────────

const VFS_COUNTRIES = [
  {
    code: 'ltu',
    label: '🇱🇹 Lithuania',
    baseUrl: 'https://visa.vfsglobal.com/arm/en/ltu/',
    loginUrl: 'https://visa.vfsglobal.com/arm/en/ltu/login',
  },
  {
    code: 'hun',
    label: '🇭🇺 Hungary',
    baseUrl: 'https://visa.vfsglobal.com/arm/en/hun/',
    loginUrl: 'https://visa.vfsglobal.com/arm/en/hun/login',
  },
];

// Subcategories are read dynamically from the VFS dropdown — no hardcoded list needed.

// Conservative polling: 3–5 min between Step 1 checks.
// VFS rate-limits at account level (429201), not IP. Each cycle hits their booking API.
const VFS_POLL_MIN_MS = 3 * 60 * 1000;
const VFS_POLL_MAX_MS = 5 * 60 * 1000;
const VFS_STEP_DELAY_MS = 1500;   // between dropdown interactions
const VFS_DOM_SETTLE_MS = 2000;   // after a dropdown change, wait for Angular update
const VFS_FAST_POLL_MS = 4000;    // fast re-poll when we're mid-flow (not between dashboards)

// OTP server (local Python helper — see /Users/openclaw/vfs_otp_server.py)
const VFS_OTP_ENDPOINT = 'http://localhost:8095/otp';
const VFS_OTP_RESET_ENDPOINT = 'http://localhost:8095/reset';
const VFS_OTP_POLL_INTERVAL_MS = 3000;
const VFS_OTP_MAX_WAIT_MS = 60 * 1000;

// Session-scoped flags so we don't spam alerts or loop forever
const _vfsFlags = {
  otpWaitStartedAt: 0,
  alertedManualNeeded: false,
  bookingConfirmed: false,
};

function vfsIsBlackout() {
  const yerevanHour = (new Date().getUTCHours() + 4) % 24;
  return yerevanHour >= 2 && yerevanHour < 6;
}

function vfsPollIntervalMs() {
  const base = VFS_POLL_MIN_MS + Math.random() * (VFS_POLL_MAX_MS - VFS_POLL_MIN_MS);
  const jitter = base * (0.10 + Math.random() * 0.10); // 10–20% jitter
  return base + jitter;
}

function vfsSleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function vfsCurrentCountry() {
  const path = window.location.pathname;
  return VFS_COUNTRIES.find(c => path.includes(`/arm/en/${c.code}/`)) || null;
}

// ─── Angular-safe form field setters ─────────────────────────────────────────
// VFS is an Angular app — it reads values off the element's property descriptor
// set by its custom value-accessor. Assigning `.value` directly is ignored. We
// have to call the native setter and then dispatch `input` + `change`.

function vfsSetInputValue(el, val) {
  if (!el) return false;
  const proto = el.tagName === 'TEXTAREA'
    ? window.HTMLTextAreaElement.prototype
    : (el.tagName === 'SELECT'
        ? window.HTMLSelectElement.prototype
        : window.HTMLInputElement.prototype);
  const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
  setter.call(el, val == null ? '' : String(val));
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  el.dispatchEvent(new Event('blur', { bubbles: true }));
  return true;
}

function vfsSetCheckbox(el, checked) {
  if (!el) return false;
  const setter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype, 'checked'
  ).set;
  setter.call(el, !!checked);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  el.dispatchEvent(new Event('click', { bubbles: true }));
  return true;
}

/**
 * Inject a File into an <input type="file"> via DataTransfer so Angular sees
 * the change and runs its validators. Returns true on success.
 */
function vfsInjectFile(inputEl, file) {
  if (!inputEl || !file) return false;
  try {
    const dt = new DataTransfer();
    dt.items.add(file);
    inputEl.files = dt.files;
    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  } catch (e) {
    console.log('[VFS] File injection failed:', e.message);
    return false;
  }
}

// Convert a stored data-URI (from chrome.storage) back into a File object.
function vfsDataUriToFile(dataUri, filename) {
  if (!dataUri || !dataUri.startsWith('data:')) return null;
  const [header, b64] = dataUri.split(',');
  const mimeMatch = header.match(/data:([^;]+)/);
  const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
  const bin = atob(b64);
  const buf = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  const ext = mime.includes('png') ? 'png'
            : mime.includes('jpeg') || mime.includes('jpg') ? 'jpg'
            : mime.includes('pdf') ? 'pdf'
            : 'bin';
  return new File([buf], filename || `passport.${ext}`, { type: mime });
}

// ─── DOM Helpers ─────────────────────────────────────────────────────────────

function vfsWaitForElement(finder, timeoutMs = 8000) {
  return new Promise(resolve => {
    const immediate = finder();
    if (immediate) { resolve(immediate); return; }

    let done = false;
    const timer = setTimeout(() => {
      if (!done) { done = true; observer.disconnect(); resolve(null); }
    }, timeoutMs);

    const observer = new MutationObserver(() => {
      if (done) return;
      const el = finder();
      if (el) { done = true; clearTimeout(timer); observer.disconnect(); resolve(el); }
    });
    observer.observe(document.body, {
      childList: true, subtree: true, attributes: true, characterData: true
    });
  });
}

function vfsFindByText(text, tagNames = ['button', 'a', 'span', 'div']) {
  const lower = text.toLowerCase();
  for (const tag of tagNames) {
    const els = Array.from(document.querySelectorAll(tag));
    const match = els.find(el => el.textContent.trim().toLowerCase().includes(lower));
    if (match) return match;
  }
  return null;
}

/**
 * Find a clickable element (button or anchor) whose text matches.
 * Returns the BUTTON/A element, not an inner span — clicks dispatch to the
 * actual interactive element so Angular handlers fire reliably.
 */
function vfsFindClickableByText(text) {
  const lower = text.toLowerCase();
  const candidates = Array.from(document.querySelectorAll(
    'button, a, [role="button"], input[type="submit"], input[type="button"]'
  ));
  // Prefer exact match first, then includes
  const exact = candidates.find(el => {
    const t = (el.textContent || '').trim().toLowerCase();
    const v = (el.value || '').trim().toLowerCase();
    const aria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
    return t === lower || v === lower || aria === lower;
  });
  if (exact) return exact;
  const partial = candidates.find(el => {
    const t = (el.textContent || '').trim().toLowerCase();
    const v = (el.value || '').trim().toLowerCase();
    const aria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
    return t.includes(lower) || v.includes(lower) || aria.includes(lower);
  });
  return partial || null;
}

/**
 * Force-click an element even if Angular keeps it "disabled".
 * Removes disabled attr/prop, dispatches a real MouseEvent so Angular
 * (click) handlers fire. Walks up to the closest button/anchor first.
 */
function vfsForceClick(el) {
  if (!el) return false;
  // Climb to the nearest clickable parent (in case el is an inner span)
  const target = el.closest('button, a, [role="button"], input[type="submit"], input[type="button"]') || el;
  try {
    target.removeAttribute('disabled');
    target.removeAttribute('aria-disabled');
    if ('disabled' in target) target.disabled = false;
  } catch (_) {}
  try {
    target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    target.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true, cancelable: true, view: window }));
    target.dispatchEvent(new MouseEvent('click',     { bubbles: true, cancelable: true, view: window }));
  } catch (_) {
    try { target.click(); } catch (_) {}
  }
  return true;
}

/**
 * Select a value in a mat-select (Angular Material) or native <select>.
 * VFS uses Angular Material dropdowns — must click to open, then click option.
 */
async function vfsSelectOption(labelText, optionText) {
  let selector = null;

  // Try mat-select (Angular Material)
  const matSelects = Array.from(document.querySelectorAll('mat-select'));
  for (const ms of matSelects) {
    const ariaLabel = ms.getAttribute('aria-label') || ms.getAttribute('placeholder') || '';
    const fieldLabel = ms.closest('mat-form-field')?.querySelector('mat-label, label')?.textContent?.trim() || '';
    if (ariaLabel.toLowerCase().includes(labelText.toLowerCase()) ||
        fieldLabel.toLowerCase().includes(labelText.toLowerCase())) {
      selector = ms;
      break;
    }
  }

  // Fallback: native <select>
  if (!selector) {
    const selects = Array.from(document.querySelectorAll('select'));
    for (const s of selects) {
      const labelEl = document.querySelector(`label[for="${s.id}"]`);
      const ariaLabel = s.getAttribute('aria-label') || '';
      const fieldLabel = s.closest('.form-group, .field, .mat-form-field')
                          ?.querySelector('label')?.textContent?.trim() || '';
      if ((labelEl && labelEl.textContent.toLowerCase().includes(labelText.toLowerCase())) ||
          ariaLabel.toLowerCase().includes(labelText.toLowerCase()) ||
          fieldLabel.toLowerCase().includes(labelText.toLowerCase())) {
        selector = s;
        break;
      }
    }
  }

  if (!selector) {
    console.log(`[VFS] Dropdown not found for label: "${labelText}"`);
    return false;
  }

  // Native <select>
  if (selector.tagName === 'SELECT') {
    const opt = Array.from(selector.options)
      .find(o => o.text.toLowerCase().includes(optionText.toLowerCase()));
    if (!opt) { console.log(`[VFS] Option "${optionText}" not in select`); return false; }
    const prevVal = selector.value;
    selector.value = opt.value;
    selector.dispatchEvent(new Event('change', { bubbles: true }));
    selector.dispatchEvent(new Event('input', { bubbles: true }));
    // Wait for Angular to react (value change reflected in the DOM)
    await vfsWaitForElement(() => selector.value !== prevVal ? selector : null, 3000);
    return true;
  }

  // mat-select: click trigger to open panel, then native-click the target option.
  // Native element.click() produces isTrusted=true events — required by Angular Material
  // CDK which ignores untrusted synthetic events in some code paths.
  const trigger = selector.querySelector('.mat-mdc-select-trigger, .mat-select-trigger') || selector;

  // Open panel with native click (trusted)
  trigger.click();

  // Wait for target option to appear in the open panel.
  // VFS MDC panels are appended to document.body (not inside .cdk-overlay-container) — query ALL.
  const target = await vfsWaitForElement(() => {
    const allOptions = Array.from(document.querySelectorAll('mat-option, .mat-mdc-option'));
    return allOptions.find(o =>
      o.textContent.trim().toLowerCase().includes(optionText.toLowerCase())
    ) || null;
  }, 6000);

  if (!target) {
    console.log(`[VFS] Option "${optionText}" not found in open panel for: "${labelText}"`);
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    return false;
  }

  console.log(`[VFS] Clicking option: "${target.textContent.trim()}" for: "${labelText}"`);

  // --- Primary: native .click() — isTrusted=true, processed by Angular CDK ---
  target.click();

  // Wait for panel to close — confirms selection was registered
  const closed = await vfsWaitForElement(
    () => !document.querySelector('.mdc-menu-surface--open') ? true : null,
    3000
  );
  if (closed) {
    console.log(`[VFS] Option selected (panel closed)`);
    return true;
  }

  // --- Fallback: click the inner span (text node) Angular may have bound the listener to ---
  console.log(`[VFS] Panel still open — trying inner span click`);
  const inner = target.querySelector('.mdc-list-item__primary-text, .mat-option-text') || target;
  inner.click();

  const closedByInner = await vfsWaitForElement(
    () => !document.querySelector('.mdc-menu-surface--open') ? true : null,
    2000
  );
  if (closedByInner) {
    console.log(`[VFS] Option selected via inner span click`);
    return true;
  }

  console.log(`[VFS] Both click attempts failed — panel still open`);
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  return false;
}

// ─── State Detection ─────────────────────────────────────────────────────────

function vfsDetectState() {
  // Don't process until Angular has finished bootstrapping
  if (document.readyState === 'loading') return 'vfs_loading';

  const path = window.location.pathname.toLowerCase();
  const bodyText = (document.body?.textContent || '').toLowerCase();
  console.log('[VFS] detectState path:', path, '| bodySnippet:', bodyText.slice(0, 200));

  // 429201 user-level rate limit — "Cooldown Period". This is per-account, not per-IP.
  // Must wait the full 2 hours before retrying. Separate from generic error pages.
  if (bodyText.includes('429201') ||
      bodyText.includes('cooldown period') ||
      bodyText.includes('multiple requests')) {
    return 'vfs_rate_limited';
  }

  // VFS error pages (403102 permission issue, page-not-found, etc.) — detected
  // before everything else so we back off and retry rather than acting on a broken page
  if (bodyText.includes('permission issue') ||
      bodyText.includes('403102') ||
      bodyText.includes('page not found') ||
      bodyText.includes('page-not-found') ||
      path.includes('/page-not-found') ||
      path.includes('/error') ||
      bodyText.includes('go back to home')) {
    return 'vfs_error_page';
  }

  // Pre-login landing pages (must be checked BEFORE generic appointment-path
  // matching, since /book-an-appointment contains the substring "appointment")
  const _isVfsPreLogin = VFS_COUNTRIES.some(c =>
    path === `/arm/en/${c.code}/` ||
    path === `/arm/en/${c.code}` ||
    path === `/arm/en/${c.code}/book-an-appointment` ||
    path === `/arm/en/${c.code}/book-an-appointment/`
  );

  // Booking confirmed / success page
  if (bodyText.includes('appointment confirmed') ||
      bodyText.includes('booking reference') ||
      bodyText.includes('your appointment is booked') ||
      bodyText.includes('appointment has been booked') ||
      path.includes('/appointment-confirmation') ||
      path.includes('/booking-success') ||
      path.includes('/confirmation')) {
    return 'vfs_booked';
  }

  // OTP / verification page — VFS shows a 6-digit code entry after step 2 submit
  const otpInput = document.querySelector(
    'input[name*="otp" i], input[id*="otp" i], input[formcontrolname*="otp" i], ' +
    'input[placeholder*="otp" i], input[aria-label*="otp" i], ' +
    'input[placeholder*="one time" i], input[placeholder*="verification code" i], ' +
    'input[placeholder*="verification" i]'
  );
  if (otpInput ||
      bodyText.includes('one time password') ||
      bodyText.includes('otp has been sent') ||
      bodyText.includes('enter the otp') ||
      bodyText.includes('enter otp') ||
      bodyText.includes('verification code has been sent') ||
      bodyText.includes('we have sent you a code')) {
    return 'vfs_otp';
  }

  // Login page — explicit /login URL OR a visible login form. Skip if pre-login
  // landing page (those may show a login link/form preview but aren't the form).
  const hasLoginForm = !_isVfsPreLogin &&
                       !!document.querySelector('input[type="password"]') &&
                       !!(document.querySelector('input[type="email"]') ||
                          document.querySelector('input[name="email"]') ||
                          document.querySelector('input[placeholder*="email" i]'));
  if (path.endsWith('/login') || path.includes('/login/') || hasLoginForm) return 'vfs_login';

  // Review / confirm page — terms checkbox + confirm button + booking summary
  const termsCheckbox = document.querySelector(
    'input[type="checkbox"][formcontrolname*="terms" i], ' +
    'input[type="checkbox"][id*="terms" i], ' +
    'input[type="checkbox"][name*="terms" i], ' +
    'input[type="checkbox"][aria-label*="terms" i], ' +
    'input[type="checkbox"][id*="agree" i], ' +
    'input[type="checkbox"][formcontrolname*="agree" i]'
  );
  if ((bodyText.includes('review your appointment') ||
       bodyText.includes('confirm your appointment') ||
       bodyText.includes('terms and conditions') ||
       bodyText.includes('appointment summary') ||
       bodyText.includes('booking summary') ||
       path.includes('/review') || path.includes('/confirm')) &&
      (termsCheckbox || vfsFindClickableByText('Confirm'))) {
    return 'vfs_review';
  }

  // Step 3 timeslot — after date is chosen, a list of time buttons appears
  if (document.querySelector('.slots-container, .timeslot, button.time-slot, ' +
                             '[class*="time-slot"], [class*="timeSlot"], ' +
                             '[class*="time_slot"], [class*="appointment-time"]') ||
      bodyText.includes('select time slot') ||
      bodyText.includes('select a time slot') ||
      bodyText.includes('available time slots') ||
      bodyText.includes('select your time')) {
    // Only treat as timeslot state if there are selectable time buttons right now
    const timeButtons = vfsFindTimeButtons();
    if (timeButtons.length > 0) return 'vfs_step3_timeslot';
  }

  // Step 3 calendar — mat-calendar or date-picker visible
  const calendar = document.querySelector(
    'mat-calendar, .mat-calendar, .calendar, [class*="datepicker"], ' +
    '[class*="date-picker"], [class*="calendar"]'
  );
  if (calendar ||
      bodyText.includes('select appointment date') ||
      bodyText.includes('select a date') ||
      bodyText.includes('select date') ||
      bodyText.includes('please select a date') ||
      bodyText.includes('choose appointment date')) {
    return 'vfs_step3_calendar';
  }

  // Step 2 upload — file inputs visible (file inputs are the strongest signal)
  const fileInputs = document.querySelectorAll('input[type="file"]');
  if (fileInputs.length > 0 ||
      bodyText.includes('upload document') ||
      bodyText.includes('upload your passport') ||
      bodyText.includes('upload passport') ||
      bodyText.includes('document upload')) {
    return 'vfs_step2_upload';
  }

  // Step 2 details — applicant name / passport number / DOB text inputs
  if (bodyText.includes('applicant details') ||
      bodyText.includes('personal details') ||
      bodyText.includes('passport number') ||
      bodyText.includes('applicant information') ||
      bodyText.includes('first name')) {
    return 'vfs_step2_details';
  }

  // Pre-login pages take precedence over the dashboard heuristic — otherwise
  // /book-an-appointment leaks into vfs_dashboard via the /appointment substring.
  if (_isVfsPreLogin) return 'vfs_home';

  // Dashboard — post-login landing page with a clear booking action button.
  // URL-based detection first (most reliable — VFS uses /dashboard or /account
  // after login). The /appointment substring intentionally requires the booking
  // path NOT match (otherwise step1/step2 booking flow gets misclassified).
  const isBookingFlow = path.includes('/booking') || path.includes('/schedule') ||
                        path.includes('/visa-application') || path.includes('/application-detail') ||
                        path.includes('/upload') || path.includes('/review') ||
                        path.includes('/payment');
  if (!isBookingFlow && (path.includes('/dashboard') || path.includes('/account') ||
                         path.endsWith('/home') || path.includes('/home/'))) {
    return 'vfs_dashboard';
  }
  // Look for an explicit "start new booking" button — only when NOT in a booking flow.
  // Must guard with !isBookingFlow because booking step nav contains "Book Appointment"
  // as a step indicator which would falsely match on /application-detail etc.
  if (!isBookingFlow && (
      vfsFindClickableByText('Start New Booking') ||
      vfsFindClickableByText('Book Appointment') ||
      vfsFindClickableByText('New Appointment') ||
      vfsFindClickableByText('Schedule Appointment') ||
      vfsFindClickableByText('Book an appointment'))) {
    return 'vfs_dashboard';
  }

  // Step 1 — appointment details page with dropdowns
  if (bodyText.includes('appointment details') ||
      bodyText.includes('visa category') ||
      bodyText.includes('visa sub category') ||
      bodyText.includes('application centre') ||
      bodyText.includes('select category') ||
      document.querySelector('mat-select') !== null) {
    return 'vfs_step1';
  }

  // Page still loading
  return 'vfs_loading';
}

function vfsFindTimeButtons() {
  // Time slots typically rendered as <button> with text like "09:00", "10:30",
  // "09:00 AM", "09:00 - 10:00", or "09:00 Available". Accept any button whose
  // text starts with HH:MM and isn't disabled.
  const candidates = Array.from(document.querySelectorAll(
    'button, [role="button"], .slot, .time-slot, [class*="time-slot"], ' +
    '[class*="timeSlot"], [class*="time_slot"], [class*="appointment-time"]'
  ));
  return candidates.filter(el => {
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
    if (el.classList.contains('disabled') || el.classList.contains('unavailable')) return false;
    const t = (el.textContent || '').trim();
    // Must START with HH:MM time pattern; tolerates trailing AM/PM and any suffix
    return /^\d{1,2}:\d{2}\b/.test(t);
  });
}

// ─── Login Auto-Fill ─────────────────────────────────────────────────────────

async function vfsAutoLogin() {
  console.log('[VFS] Login page — waiting for form...');
  const cfg = await chrome.storage.local.get(['vfs_email', 'vfs_password']);
  if (!cfg.vfs_email || !cfg.vfs_password) {
    console.log('[VFS] No VFS credentials stored — cannot auto-login');
    return false;
  }

  const emailField = await vfsWaitForElement(
    () => document.querySelector('input[type="email"]') ||
          document.querySelector('input[name="email"]') ||
          document.querySelector('input[formcontrolname*="email" i]') ||
          document.querySelector('input[placeholder*="email" i]'),
    10000
  );
  if (!emailField) { console.log('[VFS] Email field not found'); return false; }

  const passField = document.querySelector('input[type="password"]') ||
                    document.querySelector('input[formcontrolname*="password" i]');
  if (!passField) { console.log('[VFS] Password field not found'); return false; }

  // Focus → set → blur sequence so Angular's value accessor runs validators
  emailField.focus();
  vfsSetInputValue(emailField, cfg.vfs_email);
  emailField.blur();
  await vfsSleep(600 + Math.random() * 400);

  passField.focus();
  vfsSetInputValue(passField, cfg.vfs_password);
  passField.blur();
  await vfsSleep(800 + Math.random() * 600);

  // Helper: find Sign In button (returns the button element, not inner span).
  // Skip "Sign In" links in the header that aren't the form submit button.
  const _findSignInBtn = () => {
    const submit = document.querySelector('form button[type="submit"]') ||
                   document.querySelector('button[type="submit"]');
    if (submit) return submit;
    return vfsFindClickableByText('Sign In') ||
           vfsFindClickableByText('Log In') ||
           vfsFindClickableByText('Login');
  };

  // Detect Cloudflare Turnstile widget
  const hasTurnstile = !!(
    document.querySelector('iframe[src*="challenges.cloudflare"]') ||
    document.querySelector('.cf-turnstile') ||
    document.querySelector('[data-sitekey]')
  );

  if (hasTurnstile) {
    console.log('[VFS] Turnstile detected — sending to CapSolver');
    let solved = false;
    try {
      solved = await chrome.runtime.sendMessage({
        type: 'VFS_SOLVE_TURNSTILE',
        url: window.location.href
      });
    } catch (e) {
      console.log('[VFS] sendMessage to background failed:', e.message);
      solved = false;
    }
    console.log('[VFS] CapSolver result:', solved);

    // Wait briefly for any auto-navigation triggered by token injection
    await vfsSleep(2000);
    if (!window.location.href.includes('/login')) {
      console.log('[VFS] Already navigated — login succeeded');
      return true;
    }

    if (solved) {
      // Token injected — force-click Sign In even if Angular still shows disabled.
      // Wait briefly for Angular to react to the cf-turnstile-response field.
      await vfsSleep(800);
      const btn = _findSignInBtn();
      if (btn) {
        console.log('[VFS] CapSolver solved — force-clicking Sign In');
        vfsForceClick(btn);
        await vfsSleep(2500);
        if (!window.location.href.includes('/login')) {
          console.log('[VFS] Login submitted, navigating away');
          return true;
        }
        // Try once more in case Angular needed a tick
        const btn2 = _findSignInBtn();
        if (btn2) {
          console.log('[VFS] Retrying force-click on Sign In');
          vfsForceClick(btn2);
          return true;
        }
      }
    }
    // CapSolver failed or click didn't navigate — wait up to 15s for the human
    // Turnstile interaction to enable the button naturally.
    console.log('[VFS] CapSolver failed/incomplete — waiting 15s for auto-solve');
    const autoBtn = await vfsWaitForElement(
      () => { const b = _findSignInBtn(); return (b && !b.disabled) ? b : null; },
      15000
    );
    if (autoBtn) {
      console.log('[VFS] Turnstile auto-solved — clicking Sign In');
      vfsForceClick(autoBtn);
      return true;
    }
    vfsSendManualNeededAlert(vfsCurrentCountry(), 'Turnstile CAPTCHA not solved — click "Verify you are human" manually');
    return false;
  }

  // No Turnstile — find and force-click Sign In directly
  const submitBtn = await vfsWaitForElement(_findSignInBtn, 5000);
  if (submitBtn) {
    console.log('[VFS] No CAPTCHA — force-clicking Sign In');
    vfsForceClick(submitBtn);
    return true;
  }

  console.log('[VFS] Sign In button not found');
  vfsSendManualNeededAlert(vfsCurrentCountry(), 'Sign In button not found on VFS login page');
  return false;
}

// ─── Dashboard — click Start New Booking ────────────────────────────────────

async function vfsClickStartNewBooking() {
  // Look for the actual booking-start button. We deliberately do NOT match
  // "My Appointments" or "Manage Appointments" — those go to a list page,
  // not into the new-booking flow.
  const btn = await vfsWaitForElement(() =>
    vfsFindClickableByText('Start New Booking') ||
    vfsFindClickableByText('Start new booking') ||
    vfsFindClickableByText('Book Appointment') ||
    vfsFindClickableByText('Book an appointment') ||
    vfsFindClickableByText('New Appointment') ||
    vfsFindClickableByText('Schedule Appointment') ||
    vfsFindClickableByText('Schedule appointment'),
  10000);
  if (!btn) { console.log('[VFS] Dashboard booking button not found after 10s'); return false; }
  const label = (btn.textContent || '').trim();
  console.log('[VFS] Found dashboard button:', label, '| disabled:', btn.disabled, btn.getAttribute('disabled'));
  vfsForceClick(btn);
  console.log('[VFS] Dispatched click on dashboard button:', label);
  // Wait for SPA to navigate into the booking flow (URL gains 'application-detail' or body changes)
  await vfsWaitForElement(() => {
    const p = window.location.pathname.toLowerCase();
    return (p.includes('application-detail') || p.includes('book-appointment') ||
            document.querySelector('mat-select[aria-label*="category" i], mat-select[aria-label*="Category" i]'))
      ? true : null;
  }, 5000);
  return true;
}

// ─── Step 1 — check one sub-category ─────────────────────────────────────────
// Returns { available, earliestDate, continueClicked }
// If hands-free mode is enabled and the Continue button is live, we click it
// to advance into Step 2 rather than going back.

/**
 * Opens the sub-category dropdown and reads all available option texts.
 * Returns an array of option label strings. Falls back to empty array on failure.
 */
async function vfsReadSubcategories() {
  // First select "Schengen Visa" so the sub-category dropdown populates
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await vfsSleep(200);
  await vfsSelectOption('appointment category', 'Schengen Visa') ||
    await vfsSelectOption('Category', 'Schengen Visa') ||
    await vfsSelectOption('Visa type', 'Schengen Visa');
  await vfsSleep(VFS_STEP_DELAY_MS);

  // Find the sub-category mat-select
  const matSelects = Array.from(document.querySelectorAll('mat-select'));
  let subSelect = null;
  for (const ms of matSelects) {
    const ariaLabel = ms.getAttribute('aria-label') || ms.getAttribute('placeholder') || '';
    const fieldLabel = ms.closest('mat-form-field')?.querySelector('mat-label, label')?.textContent?.trim() || '';
    if (ariaLabel.toLowerCase().includes('sub') || fieldLabel.toLowerCase().includes('sub')) {
      subSelect = ms;
      break;
    }
  }
  if (!subSelect) {
    console.log('[VFS] Sub-category dropdown not found — using fallback list');
    return ['Business/Cultural/Sports', 'Family/Friends visit', 'Tourism'];
  }

  // Open the dropdown to read options
  vfsForceClick(subSelect);
  await vfsSleep(600);
  const options = Array.from(document.querySelectorAll('mat-option, .mat-option'))
    .map(o => o.textContent.trim())
    .filter(t => t.length > 0);
  // Close dropdown
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await vfsSleep(300);

  if (options.length === 0) {
    console.log('[VFS] No options found in sub-category dropdown — using fallback list');
    return ['Business/Cultural/Sports', 'Family/Friends visit', 'Tourism'];
  }
  return options;
}

async function vfsCheckSubcategory(subcategory, { advanceOnFound = false } = {}) {
  console.log(`[VFS] Checking sub-category: "${subcategory}"`);

  // Make sure no stale dropdown panel is open from a previous iteration
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));

  // Wait for the appointment category mat-select to be present and enabled
  // Angular SPA continues bootstrapping after document.readyState === 'complete'
  console.log('[VFS] Waiting for appointment category dropdown to be ready...');
  const catReady = await vfsWaitForElement(() => {
    const matSelects = Array.from(document.querySelectorAll('mat-select'));
    for (const ms of matSelects) {
      const ariaLabel = ms.getAttribute('aria-label') || ms.getAttribute('placeholder') || '';
      const fieldLabel = ms.closest('mat-form-field')?.querySelector('mat-label, label')?.textContent?.trim() || '';
      const combined = (ariaLabel + ' ' + fieldLabel).toLowerCase();
      if ((combined.includes('appointment') || combined.includes('category') ||
           combined.includes('visa type') || combined.includes('visa category')) &&
          !combined.includes('sub') &&
          !ms.hasAttribute('disabled') &&
          ms.getAttribute('aria-disabled') !== 'true') {
        return ms;
      }
    }
    return null;
  }, 15000);
  if (!catReady) {
    console.log('[VFS] Appointment category dropdown not ready after 15s — retrying on next poll');
    return { available: false, earliestDate: null };
  }
  console.log('[VFS] Appointment category dropdown is ready');

  // Select Schengen Visa in Visa Category (try multiple label variants — VFS uses "appointment category")
  const catOk = await vfsSelectOption('appointment category', 'Schengen Visa') ||
                await vfsSelectOption('Visa Category', 'Schengen Visa') ||
                await vfsSelectOption('Category', 'Schengen Visa') ||
                await vfsSelectOption('Visa type', 'Schengen Visa') ||
                await vfsSelectOption('appointment type', 'Schengen Visa');
  if (!catOk) {
    console.log('[VFS] Could not select "Schengen Visa" in Visa Category');
    // Try anyway — some flows pre-select category and only require sub-category
  }

  // After category selection Angular needs to re-render the sub-category dropdown.
  // Wait up to 5s for the sub-category mat-select to have at least one option loaded.
  console.log('[VFS] Waiting for sub-category dropdown to populate...');
  const subcatReady = await vfsWaitForElement(() => {
    // The sub-category mat-select is considered ready when:
    // 1. A mat-select whose label includes 'sub' is in the DOM, AND
    // 2. Clicking it would open a panel — proxy: it is not disabled
    const matSelects = Array.from(document.querySelectorAll('mat-select'));
    for (const ms of matSelects) {
      const ariaLabel = ms.getAttribute('aria-label') || ms.getAttribute('placeholder') || '';
      const fieldLabel = ms.closest('mat-form-field')?.querySelector('mat-label, label')?.textContent?.trim() || '';
      const combined = (ariaLabel + ' ' + fieldLabel).toLowerCase();
      if (combined.includes('sub') &&
          !ms.hasAttribute('disabled') &&
          ms.getAttribute('aria-disabled') !== 'true') {
        return ms;
      }
    }
    return null;
  }, 5000);
  if (!subcatReady) {
    console.log('[VFS] Sub-category dropdown not ready after 5s — retrying on next poll');
    return { available: false, earliestDate: null };
  }

  // Select sub-category (try multiple label variants — VFS uses "sub-category")
  const subOk = await vfsSelectOption('sub-category', subcategory) ||
                await vfsSelectOption('Sub category', subcategory) ||
                await vfsSelectOption('Visa Sub Category', subcategory) ||
                await vfsSelectOption('Sub Category', subcategory) ||
                await vfsSelectOption('Subcategory', subcategory) ||
                await vfsSelectOption('Purpose', subcategory);
  if (!subOk) {
    console.log(`[VFS] Could not select sub-category "${subcategory}"`);
    return { available: false, earliestDate: null };
  }

  // Wait for VFS to render the slot availability response after subcategory selection
  await vfsWaitForElement(() => {
    const t = (document.body?.textContent || '').toLowerCase();
    return (t.includes('no appointment slots') ||
            t.includes('we are sorry') ||
            t.includes('no slot available') ||
            t.includes('earliest available') ||
            t.includes('next available') ||
            document.querySelector('button:not([disabled])[class*="continu" i]'))
      ? true : null;
  }, 8000);

  const bodyText = document.body?.textContent || '';
  const lower = bodyText.toLowerCase();

  // "No slots" indicators
  const noSlots = lower.includes('no appointment slots are currently available') ||
                  lower.includes('no slots are currently available') ||
                  lower.includes('no available slots') ||
                  lower.includes('no appointments available') ||
                  lower.includes('we are sorry') ||
                  lower.includes('no slot available');

  if (noSlots) {
    console.log(`[VFS] No slots for "${subcategory}"`);
    return { available: false, earliestDate: null };
  }

  // "Slots available" indicators — accept several date formats: dd-mm-yyyy,
  // dd/mm/yyyy, yyyy-mm-dd, "12 May 2026"
  const earliestMatch =
    bodyText.match(/Earliest\s+available\s+slot[^:]*:\s*([0-9A-Za-z\-\/ ,]{6,30})/i) ||
    bodyText.match(/Next\s+available\s+slot[^:]*:\s*([0-9A-Za-z\-\/ ,]{6,30})/i);
  const continueBtn = vfsFindClickableByText('Continue');
  const hasSlot = !!earliestMatch || (continueBtn && !continueBtn.disabled);

  if (hasSlot) {
    const earliestDate = earliestMatch ? earliestMatch[1].trim() : null;
    console.log(`[VFS] SLOT AVAILABLE for "${subcategory}"! Earliest: ${earliestDate || 'unknown'}`);
    if (advanceOnFound && continueBtn) {
      console.log('[VFS] Hands-free: force-clicking Continue to advance to Step 2');
      vfsForceClick(continueBtn);
      await vfsSleep(VFS_DOM_SETTLE_MS);
      return { available: true, earliestDate, continueClicked: true };
    }
    return { available: true, earliestDate, continueClicked: false };
  }

  // Ambiguous — no clear signal either way; treat conservatively as no slots
  console.log(`[VFS] Ambiguous result for "${subcategory}" — assuming no slots`);
  return { available: false, earliestDate: null };
}

// ─── Navigate back to dashboard ──────────────────────────────────────────────

async function vfsGoBackToDashboard(country) {
  const backBtn = vfsFindClickableByText('Go Back') ||
                  vfsFindClickableByText('Back to dashboard') ||
                  vfsFindClickableByText('Back') ||
                  vfsFindClickableByText('Cancel');
  if (backBtn) {
    vfsForceClick(backBtn);
    await vfsSleep(1500);
  } else {
    window.location.href = country.baseUrl;
  }
}

// ─── Alerts ─────────────────────────────────────────────────────────────────

function vfsSendSlotAlert(country, subcategory, earliestDate) {
  chrome.runtime.sendMessage({
    type: 'VFS_SLOT_FOUND',
    country: country.code,
    countryLabel: country.label,
    subcategory,
    earliestDate,
    loginUrl: country.loginUrl,
  }).catch(() => {});
}

function vfsSendManualNeededAlert(country, reason) {
  if (_vfsFlags.alertedManualNeeded) return;
  _vfsFlags.alertedManualNeeded = true;
  chrome.runtime.sendMessage({
    type: 'VFS_MANUAL_NEEDED',
    country: country ? country.code : '',
    countryLabel: country ? country.label : '',
    url: window.location.href,
    reason,
  }).catch(() => {});
}

function vfsSendBookedAlert(country, details) {
  chrome.runtime.sendMessage({
    type: 'VFS_SLOT_BOOKED',
    country: country ? country.code : '',
    countryLabel: country ? country.label : '',
    ...details,
  }).catch(() => {});
}

// ─── Step 2 handlers ─────────────────────────────────────────────────────────

/**
// Applicant detail auto-fill removed: VFS OCR extracts all details from the passport image.

/**
 * Upload passport front/back images from chrome.storage into visible file inputs.
 * Returns { frontUploaded, backUploaded, fileInputsFound }.
 */
async function vfsUploadPassportImages() {
  const stored = await chrome.storage.local.get([
    'vfs_passport_front_b64', 'vfs_passport_back_b64',
    'vfs_passport_front_name', 'vfs_passport_back_name',
  ]);
  const frontFile = vfsDataUriToFile(stored.vfs_passport_front_b64,
                                     stored.vfs_passport_front_name || 'passport-front.jpg');
  const backFile  = vfsDataUriToFile(stored.vfs_passport_back_b64,
                                     stored.vfs_passport_back_name  || 'passport-back.jpg');

  const fileInputs = Array.from(document.querySelectorAll('input[type="file"]'))
                       .filter(i => !i.disabled);
  if (fileInputs.length === 0) return { frontUploaded: false, backUploaded: false, fileInputsFound: 0 };

  // Classify each input by the text surrounding it (front/back heuristics)
  const classify = (el) => {
    const haystack = [
      el.getAttribute('aria-label') || '',
      el.getAttribute('placeholder') || '',
      el.getAttribute('formcontrolname') || '',
      el.id || '',
      el.name || '',
      (el.closest('.form-group, .field, mat-form-field, .upload-box, label')
          ?.textContent || ''),
    ].join(' ').toLowerCase();
    if (haystack.includes('back') || haystack.includes('reverse')) return 'back';
    if (haystack.includes('front') || haystack.includes('bio') || haystack.includes('main')) return 'front';
    return 'unknown';
  };

  let frontUploaded = false;
  let backUploaded  = false;

  // Pass 1: explicit front/back matches
  for (const input of fileInputs) {
    const kind = classify(input);
    if (kind === 'front' && frontFile && !frontUploaded) {
      if (vfsInjectFile(input, frontFile)) { frontUploaded = true; await vfsSleep(500); }
    } else if (kind === 'back' && backFile && !backUploaded) {
      if (vfsInjectFile(input, backFile))  { backUploaded  = true; await vfsSleep(500); }
    }
  }

  // Pass 2: fill the rest in order (front first, then back)
  for (const input of fileInputs) {
    if (input.files && input.files.length > 0) continue;
    if (frontFile && !frontUploaded) {
      if (vfsInjectFile(input, frontFile)) { frontUploaded = true; await vfsSleep(500); continue; }
    }
    if (backFile && !backUploaded) {
      if (vfsInjectFile(input, backFile))  { backUploaded  = true; await vfsSleep(500); }
    }
  }

  console.log(`[VFS] Upload result: front=${frontUploaded} back=${backUploaded} inputs=${fileInputs.length}`);
  return { frontUploaded, backUploaded, fileInputsFound: fileInputs.length };
}

async function vfsHandleStep2(country) {
  console.log('[VFS] Step 2 (details/upload) — uploading passport image (VFS OCR fills details)');
  await vfsSleep(800);

  // Some VFS flows combine details + upload on one page
  const uploaded = await vfsUploadPassportImages();

  const fileInputs = Array.from(document.querySelectorAll('input[type="file"]'));

  // Only block on missing uploads if the page actually has file inputs and
  // none of them have files. If there are no file inputs at all, this might
  // be a pure-details step where VFS auto-fills via OCR after the previous
  // upload step — proceed to Continue.
  if (fileInputs.length > 0) {
    const populated = fileInputs.filter(i => i.files && i.files.length > 0);
    if (populated.length === 0) {
      console.log('[VFS] No file inputs were populated — alerting user');
      vfsSendManualNeededAlert(country, 'missing_passport_images');
      return false;
    }
    const requiredMissing = fileInputs.filter(i =>
      (i.required || i.hasAttribute('required')) &&
      (!i.files || i.files.length === 0)
    );
    if (requiredMissing.length > 0) {
      console.log(`[VFS] ${requiredMissing.length} required file input(s) still empty — alerting user`);
      vfsSendManualNeededAlert(country, 'missing_passport_images');
      return false;
    }
  }

  // Wait for Angular OCR / validators to finish (the Continue button is gated
  // on async upload completion). Poll up to 10s for it to enable.
  const continueBtn = await vfsWaitForElement(() => {
    const b = vfsFindClickableByText('Continue') ||
              vfsFindClickableByText('Next') ||
              vfsFindClickableByText('Submit') ||
              document.querySelector('form button[type="submit"]');
    return b || null;
  }, 10000);

  if (!continueBtn) {
    console.log('[VFS] Step 2 Continue button not found at all');
    return false;
  }

  console.log('[VFS] Force-clicking Continue on Step 2');
  _vfsFlags.otpWaitStartedAt = 0; // reset so the next OTP wait has a fresh budget
  vfsForceClick(continueBtn);
  await vfsSleep(1500);
  return true;
}

// ─── OTP handler ─────────────────────────────────────────────────────────────

async function vfsFetchOtpFromServer() {
  try {
    const r = await fetch(VFS_OTP_ENDPOINT, { cache: 'no-store' });
    if (!r.ok) return null;
    const j = await r.json();
    if (j && j.found && typeof j.otp === 'string' && /^\d{4,8}$/.test(j.otp)) return j.otp;
    return null;
  } catch (e) {
    console.log('[VFS] OTP server unreachable:', e.message);
    return null;
  }
}

async function vfsResetOtpServer() {
  try { await fetch(VFS_OTP_RESET_ENDPOINT, { method: 'POST' }); } catch (e) {}
}

async function vfsHandleOtp(country) {
  const otpInput = await vfsWaitForElement(
    () => document.querySelector(
      'input[name*="otp" i], input[id*="otp" i], input[formcontrolname*="otp" i], ' +
      'input[placeholder*="otp" i], input[aria-label*="otp" i], ' +
      'input[placeholder*="one time" i], input[placeholder*="verification code" i], ' +
      'input[placeholder*="verification" i]'
    ),
    8000
  );
  if (!otpInput) {
    console.log('[VFS] OTP input not found after waiting');
    return false;
  }

  // Start or resume the OTP wait budget
  if (!_vfsFlags.otpWaitStartedAt) {
    _vfsFlags.otpWaitStartedAt = Date.now();
    console.log('[VFS] Starting OTP wait (60s budget)');
    // Reset the OTP server cache at the START of this wait so we never read a
    // stale code from a previous attempt.
    await vfsResetOtpServer();
  }

  const elapsed = Date.now() - _vfsFlags.otpWaitStartedAt;
  if (elapsed > VFS_OTP_MAX_WAIT_MS) {
    console.log('[VFS] OTP wait budget exhausted — alerting user');
    vfsSendManualNeededAlert(country, 'otp_timeout');
    return false;
  }

  const otp = await vfsFetchOtpFromServer();
  if (!otp) {
    console.log('[VFS] OTP not yet available — will retry');
    return 'retry';
  }

  console.log(`[VFS] Got OTP ${otp} from server — filling and verifying`);
  otpInput.focus();
  vfsSetInputValue(otpInput, otp);
  otpInput.blur();
  await vfsSleep(700);

  // Reset the OTP server so the old code isn't reused if the page refreshes
  await vfsResetOtpServer();

  // Find verify button — wait briefly in case Angular needs a tick to enable it
  const verifyBtn = await vfsWaitForElement(() =>
    vfsFindClickableByText('Verify') ||
    vfsFindClickableByText('Submit') ||
    vfsFindClickableByText('Continue') ||
    vfsFindClickableByText('Confirm') ||
    document.querySelector('form button[type="submit"]') ||
    document.querySelector('button[type="submit"]'),
  5000);

  if (!verifyBtn) {
    console.log('[VFS] OTP verify button not found');
    return false;
  }
  console.log('[VFS] Force-clicking OTP verify');
  vfsForceClick(verifyBtn);
  _vfsFlags.otpWaitStartedAt = 0;
  await vfsSleep(1500);
  return true;
}

// ─── Step 3 handlers ─────────────────────────────────────────────────────────

async function vfsHandleStep3Calendar(country) {
  console.log('[VFS] Step 3 — selecting earliest available date');
  // mat-calendar cells not disabled. Filter to cells that actually represent
  // bookable dates (mat-calendar marks past/disabled cells with the disabled
  // class; we also drop cells that are explicitly aria-disabled).
  const available = Array.from(document.querySelectorAll(
    'mat-calendar-body .mat-calendar-body-cell:not(.mat-calendar-body-disabled), ' +
    '.mat-calendar-body-cell:not(.mat-calendar-body-disabled), ' +
    'td.available, button.available-date, .available-slot, ' +
    'button:not([disabled])[aria-label*="available" i], ' +
    '[class*="available"]:not([class*="not-available"]):not([disabled])'
  )).filter(el => {
    if (el.disabled) return false;
    if (el.getAttribute('aria-disabled') === 'true') return false;
    if (el.classList.contains('mat-calendar-body-disabled')) return false;
    if (el.classList.contains('disabled')) return false;
    // Skip empty placeholder cells (mat-calendar pads weeks with empty cells)
    const t = (el.textContent || '').trim();
    if (!t) return false;
    return true;
  });
  if (available.length === 0) {
    console.log('[VFS] No selectable calendar dates yet — waiting');
    return 'retry';
  }
  // Pick first (earliest) in DOM order
  const first = available[0];
  console.log(`[VFS] Force-clicking date: ${first.getAttribute('aria-label') || first.textContent?.trim()}`);
  vfsForceClick(first);
  await vfsSleep(1800);
  return true;
}

async function vfsHandleStep3Timeslot(country) {
  console.log('[VFS] Step 3 — selecting first available time slot');
  const timeButtons = vfsFindTimeButtons();
  if (timeButtons.length === 0) {
    console.log('[VFS] No time buttons found yet — waiting');
    return 'retry';
  }
  const first = timeButtons[0];
  console.log(`[VFS] Force-clicking time: ${first.textContent?.trim()}`);
  vfsForceClick(first);
  await vfsSleep(1500);

  // After picking time, a Continue button usually appears. Wait briefly for it
  // to enable.
  const continueBtn = await vfsWaitForElement(() =>
    vfsFindClickableByText('Continue') ||
    vfsFindClickableByText('Next') ||
    vfsFindClickableByText('Confirm') ||
    vfsFindClickableByText('Proceed'),
  5000);
  if (continueBtn) {
    console.log('[VFS] Force-clicking Continue after timeslot');
    vfsForceClick(continueBtn);
    await vfsSleep(1500);
    return true;
  }
  return 'retry';
}

// ─── Review + Confirm handler ───────────────────────────────────────────────

async function vfsHandleReview(country) {
  console.log('[VFS] Review page — checking terms and confirming');

  // Accept terms — only check checkboxes that look like terms/agree boxes,
  // not unrelated ones (e.g. newsletter opt-in).
  const allChecks = Array.from(document.querySelectorAll('input[type="checkbox"]'));
  const termsChecks = allChecks.filter(cb => {
    if (cb.disabled || cb.checked) return false;
    const haystack = [
      cb.id || '', cb.name || '',
      cb.getAttribute('formcontrolname') || '',
      cb.getAttribute('aria-label') || '',
      (cb.closest('label, mat-checkbox, .form-check, .checkbox')?.textContent || ''),
    ].join(' ').toLowerCase();
    return /terms|agree|accept|consent|declar|acknowledge|privacy|condition/.test(haystack);
  });
  if (termsChecks.length === 0 && allChecks.length > 0) {
    // No terms-classified checkboxes — fall back to checking all unchecked
    // ones, since some VFS variants render terms without distinct labels.
    console.log('[VFS] No terms-classified checkbox; checking all unchecked boxes');
    for (const cb of allChecks.filter(c => !c.disabled && !c.checked)) vfsSetCheckbox(cb, true);
  } else {
    for (const cb of termsChecks) vfsSetCheckbox(cb, true);
  }
  await vfsSleep(500);

  const confirmBtn = vfsFindClickableByText('Confirm') ||
                     vfsFindClickableByText('Book Appointment') ||
                     vfsFindClickableByText('Book appointment') ||
                     vfsFindClickableByText('Submit') ||
                     vfsFindClickableByText('Pay') ||
                     vfsFindClickableByText('Proceed') ||
                     document.querySelector('form button[type="submit"]') ||
                     document.querySelector('button[type="submit"]');
  if (!confirmBtn) {
    console.log('[VFS] Confirm button not on page yet');
    return 'retry';
  }

  // Safety: don't double-confirm
  if (_vfsFlags.bookingConfirmed) {
    console.log('[VFS] Already confirmed once this session — skipping');
    return true;
  }
  console.log('[VFS] Force-clicking Confirm');
  vfsForceClick(confirmBtn);
  _vfsFlags.bookingConfirmed = true;
  await vfsSleep(2500);
  return true;
}

// ─── Booked handler ──────────────────────────────────────────────────────────

function vfsExtractBookingDetails() {
  const text = document.body?.textContent || '';
  const refMatch   = text.match(/Booking\s*Ref(?:erence)?\s*(?:No\.?|Number|#)?\s*[:\-]\s*([A-Z0-9\-]{4,})/i);
  const dateMatch  = text.match(/Appointment\s*Date\s*[:\-]\s*([\w ,\-\/]{6,})/i);
  const timeMatch  = text.match(/Appointment\s*Time\s*[:\-]\s*(\d{1,2}:\d{2}(?:\s?[AP]M)?)/i);
  return {
    reference: refMatch ? refMatch[1].trim() : '',
    date:      dateMatch ? dateMatch[1].trim() : '',
    time:      timeMatch ? timeMatch[1].trim() : '',
  };
}

async function vfsHandleBooked(country) {
  const details = vfsExtractBookingDetails();
  console.log('[VFS] BOOKED!', details);
  vfsSendBookedAlert(country, details);
  return true;
}

// ─── Main poll cycle ─────────────────────────────────────────────────────────

let _vfsPollTimer = null;
let _vfsRunning = false;
// Loop guards — kill runaway recursion when the same state keeps repeating
// because the page never advanced after a click.
let _vfsLastState = null;
let _vfsLastStateRepeats = 0;
const VFS_MAX_STATE_REPEATS = 6;

function _vfsRunNext(delayMs) {
  // Re-enter the poll loop after a sleep WITHOUT awaiting (otherwise the
  // outer `finally` resets `_vfsRunning` after the recursive call already ran,
  // creating overlapping cycles). Use setTimeout instead.
  if (_vfsPollTimer) clearTimeout(_vfsPollTimer);
  _vfsPollTimer = setTimeout(vfsPollCycle, Math.max(500, delayMs | 0));
}

async function vfsPollCycle() {
  if (_vfsRunning) return;
  _vfsRunning = true;

  try {
    if (!isExtensionAlive()) {
      console.log('[VFS] Extension context invalidated — stopping poll');
      return;
    }

    const country = vfsCurrentCountry();
    if (!country) return;

    const cfg = await chrome.storage.local.get([
      `vfs_enabled_${country.code}`, 'polling_enabled', 'vfs_hands_free',
    ]);

    if (cfg.polling_enabled === false) return;
    if (!cfg[`vfs_enabled_${country.code}`]) {
      console.log(`[VFS] Not enabled for ${country.label}`);
      return;
    }

    if (vfsIsBlackout()) {
      console.log('[VFS] Blackout (02:00–06:00 Yerevan) — skipping');
      _scheduleVfsPoll();
      return;
    }

    const handsFree = !!cfg.vfs_hands_free;
    const state = vfsDetectState();

    // Track state repetition — bail out if we see the same state too many times
    if (state === _vfsLastState) {
      _vfsLastStateRepeats++;
    } else {
      _vfsLastState = state;
      _vfsLastStateRepeats = 0;
    }
    console.log(`[VFS] State: ${state} | ${country.label} | handsFree=${handsFree} | repeat=${_vfsLastStateRepeats}`);

    if (_vfsLastStateRepeats > VFS_MAX_STATE_REPEATS) {
      console.log(`[VFS] State "${state}" stuck for ${_vfsLastStateRepeats} cycles — back off to slow poll`);
      _vfsLastStateRepeats = 0;
      _scheduleVfsPoll();
      return;
    }

    if (state === 'vfs_login') {
      const ok = await vfsAutoLogin();
      // Even on success, re-poll soon so we catch the post-login dashboard
      _vfsRunning = false;
      _vfsRunNext(ok ? 4000 : VFS_POLL_MIN_MS);
      return;
    }

    if (state === 'vfs_home') {
      console.log('[VFS] Home/landing page — waiting 1-2s then navigating to login');
      _vfsRunning = false;
      const navDelay = 1000 + Math.floor(Math.random() * 1000);
      setTimeout(() => { window.location.href = country.loginUrl; }, navDelay);
      return;
    }

    if (state === 'vfs_rate_limited') {
      // 429201 = user-level cooldown. Proxy won't help — VFS tracks by account.
      // Wait 2 hours before retrying.
      const COOLDOWN_MS = 2 * 60 * 60 * 1000;
      console.log('[VFS] 429201 user rate-limit — pausing 2 hours before retry');
      chrome.runtime.sendMessage({
        type: 'VFS_SLOT_ALERT',
        text: `VFS 429201 cooldown — paused for 2 hours. Will auto-resume.`,
      }).catch(() => {});
      _vfsRunning = false;
      setTimeout(() => { window.location.href = country.loginUrl; }, COOLDOWN_MS);
      return;
    }

    if (state === 'vfs_error_page') {
      console.log('[VFS] Error/permission page — waiting 5s then navigating to login');
      _vfsRunning = false;
      _vfsRunNext(5000);
      // Navigate after the 5s delay so the page has time to settle
      setTimeout(() => { window.location.href = country.loginUrl; }, 5000);
      return;
    }

    if (state === 'vfs_loading') {
      console.log('[VFS] Page still loading — waiting 2s');
      _vfsRunning = false;
      _vfsRunNext(2000);
      return;
    }

    if (state === 'vfs_dashboard') {
      const ok = await vfsClickStartNewBooking();
      _vfsRunning = false;
      _vfsRunNext(ok ? 3000 : VFS_POLL_MIN_MS);
      return;
    }

    if (state === 'vfs_step1') {
      let foundSlot = false;
      let advanced = false;
      // Use subcategory from extension settings (Options page)
      const cfg2 = await chrome.storage.local.get(['vfs_subcategory']);
      const subcat = cfg2.vfs_subcategory || 'Tourism';
      console.log('[VFS] Checking subcategory (from settings):', subcat);
      if (subcat) {
        const result = await vfsCheckSubcategory(subcat, { advanceOnFound: handsFree });
        if (result.available) {
          foundSlot = true;
          vfsSendSlotAlert(country, subcat, result.earliestDate);
          if (result.continueClicked) {
            advanced = true;
          } else {
            // No hands-free: alert sent, stay on page
          }
        }
      }
      if (!foundSlot) {
        // Stay on Step 1 — don't navigate away. Navigating to baseUrl causes a
        // full re-login on the next cycle (CAPTCHA required). Instead, just wait
        // 60-80s and recheck all subcategories in place.
        const waitMs = vfsPollIntervalMs();
        console.log(`[VFS] No slots in any sub-category — rechecking in ${Math.round(waitMs/1000)}s`);
      }
      _vfsRunning = false;
      // After advancing into Step 2 — fast re-poll. After "no slots" — slow poll.
      _vfsRunNext(advanced ? 3000 : vfsPollIntervalMs());
      return;
    }

    // ─── Hands-free states ────────────────────────────────────────────────
    if (!handsFree) {
      // Safety: if somehow we're on step 2/OTP/step3 but hands-free is off,
      // we simply do nothing and reschedule slow polling.
      console.log('[VFS] Past Step 1 but hands-free is off — pausing');
      _scheduleVfsPoll();
      return;
    }

    if (state === 'vfs_step2_details' || state === 'vfs_step2_upload') {
      await vfsHandleStep2(country);
      _vfsRunning = false;
      _vfsRunNext(VFS_FAST_POLL_MS);
      return;
    }

    if (state === 'vfs_otp') {
      const result = await vfsHandleOtp(country);
      _vfsRunning = false;
      if (result === 'retry') {
        _vfsRunNext(VFS_OTP_POLL_INTERVAL_MS);
      } else if (result === true) {
        _vfsRunNext(VFS_FAST_POLL_MS);
      } else {
        // hard failure — already alerted; pause
        _scheduleVfsPoll();
      }
      return;
    }

    if (state === 'vfs_step3_calendar') {
      const r = await vfsHandleStep3Calendar(country);
      _vfsRunning = false;
      _vfsRunNext(r === 'retry' ? VFS_FAST_POLL_MS : 2500);
      return;
    }

    if (state === 'vfs_step3_timeslot') {
      const r = await vfsHandleStep3Timeslot(country);
      _vfsRunning = false;
      _vfsRunNext(r === 'retry' ? VFS_FAST_POLL_MS : 2500);
      return;
    }

    if (state === 'vfs_review') {
      const r = await vfsHandleReview(country);
      _vfsRunning = false;
      _vfsRunNext(r === 'retry' ? VFS_FAST_POLL_MS : 3500);
      return;
    }

    if (state === 'vfs_booked') {
      await vfsHandleBooked(country);
      // Stop polling — we're done
      if (_vfsPollTimer) { clearTimeout(_vfsPollTimer); _vfsPollTimer = null; }
      return;
    }

    if (state === 'vfs_loading') {
      _vfsRunning = false;
      _vfsRunNext(3000);
      return;
    }

    // Unknown — wait one slow cycle then re-check before navigating away
    console.log('[VFS] Unknown state — slow re-poll before navigating');
    _scheduleVfsPoll();

  } catch (e) {
    console.error('[VFS] Poll cycle error:', e.message);
    _scheduleVfsPoll();
  } finally {
    _vfsRunning = false;
  }
}

function _scheduleVfsPoll() {
  if (_vfsPollTimer) clearTimeout(_vfsPollTimer);
  const ms = vfsPollIntervalMs();
  console.log(`[VFS] Next poll in ${Math.round(ms / 1000)}s`);
  _vfsPollTimer = setTimeout(vfsPollCycle, ms);
}

// ─── Message listener ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'VFS_CONFIG_UPDATED') {
    console.log('[VFS] Config updated — restarting poll');
    if (_vfsPollTimer) clearTimeout(_vfsPollTimer);
    _vfsRunning = false;
    _vfsFlags.alertedManualNeeded = false;
    _vfsLastState = null;
    _vfsLastStateRepeats = 0;
    setTimeout(vfsPollCycle, 1000);
  }
  if (msg.type === 'STOP_POLLING') {
    if (_vfsPollTimer) { clearTimeout(_vfsPollTimer); _vfsPollTimer = null; }
    _vfsRunning = false;
    console.log('[VFS] Polling stopped');
  }
});

// ─── Startup ─────────────────────────────────────────────────────────────────

(async function vfsStartup() {
  const country = vfsCurrentCountry();
  if (!country) return;

  const cfg = await chrome.storage.local.get([
    `vfs_enabled_${country.code}`, 'polling_enabled'
  ]);

  if (cfg.polling_enabled === false) {
    console.log('[VFS] Global polling disabled — not starting VFS poll');
    return;
  }
  if (!cfg[`vfs_enabled_${country.code}`]) {
    console.log(`[VFS] Monitoring not enabled for ${country.label} in Options`);
    return;
  }

  console.log(`[VFS] Content script active for ${country.label}`);
  setTimeout(vfsPollCycle, 2000);
})();

} // end VFS injection guard
} // end visa.vfsglobal.com guard

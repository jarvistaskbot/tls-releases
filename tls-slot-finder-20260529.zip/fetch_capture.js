// v1.5.383 — MAIN-world fetch wrapper for booking POST response capture.
// Loaded via manifest content_scripts with "world": "MAIN" on all TLS domains
// so the wrapper is in place before any SPA navigation to the booking route.
//
// Intercepts window.fetch, and for POST calls to appointment-booking URLs:
//   1. Clones the response (original passes through unmodified)
//   2. Reads status + body (truncated to 10 KB)
//   3. Posts to isolated-world content script via window.postMessage
//
// Idempotency guard: window.__tlsFetchWrapped — safe across SPA navigations
// that don't reload the document (the IIFE won't re-wrap an already-wrapped fetch).
(function () {
  if (window.__tlsFetchWrapped) return;
  window.__tlsFetchWrapped = true;

  var _orig = window.fetch;

  window.fetch = function (input, init) {
    var url = (typeof input === 'string') ? input
            : (input && typeof input.url === 'string') ? input.url : '';
    var method = ((init && init.method) ||
                  (input && typeof input.method === 'string' && input.method) ||
                  'GET').toUpperCase();
    var capture = method === 'POST' && url.indexOf('appointment-booking') !== -1;

    var promise = _orig.apply(this, arguments);

    if (!capture) return promise;

    var ts = Date.now();
    return promise.then(function (resp) {
      var status = resp.status;
      var cloned = resp.clone();
      cloned.text().then(function (body) {
        try {
          window.postMessage({
            type: '__tls_booking_response__',
            url: url,
            responseStatus: status,
            responseBody: body.length > 10240 ? body.slice(0, 10240) + '...[truncated]' : body,
            captureTs: ts
          }, '*');
        } catch (_) {}
      }).catch(function () {
        try {
          window.postMessage({
            type: '__tls_booking_response__',
            url: url,
            responseStatus: status,
            responseBody: '[body_read_failed]',
            captureTs: ts
          }, '*');
        } catch (_) {}
      });
      return resp;
    });
  };
})();

// v1.5.363: BLS Spain options section
(function () {
  const $$ = (id) => document.getElementById(id);
  const KEYS = ['bls_enabled', 'bls_email', 'bls_password', 'bls_applicant_index', 'bls_book_count', 'bls_selfie_b64', 'bls_selfie_name'];

  function describeImage(name, b64) {
    if (!b64) return 'No selfie saved';
    const sizeKb = Math.round((b64.length * 3) / 4 / 1024);
    return `Stored: ${name || 'selfie'} (~${sizeKb} KB)`;
  }

  function fileToDataUri(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  chrome.storage.local.get(KEYS, (stored) => {
    const enabledEl = $$('blsEnabled');
    const emailEl   = $$('blsEmail');
    const passEl    = $$('blsPassword');
    const idxEl     = $$('blsApplicantIndex');
    const statusEl  = $$('blsSelfieStatus');

    const cntEl     = $$('blsBookCount');
    if (enabledEl) enabledEl.checked = stored.bls_enabled === true;
    if (emailEl)   emailEl.value     = stored.bls_email    || '';
    if (passEl)    passEl.value      = stored.bls_password  || '';
    if (idxEl)     idxEl.value       = stored.bls_applicant_index != null ? stored.bls_applicant_index : 0;
    if (cntEl)     cntEl.value       = stored.bls_book_count != null ? stored.bls_book_count : 1;
    if (statusEl)  statusEl.textContent = describeImage(stored.bls_selfie_name, stored.bls_selfie_b64);
  });

  // Save BLS fields on main Save button
  const saveBtn = $$('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({
          bls_enabled:          !!($$('blsEnabled') && $$('blsEnabled').checked),
          bls_email:            ($$('blsEmail')    || {}).value || '',
          bls_password:         ($$('blsPassword') || {}).value || '',
          bls_applicant_index:  parseInt(($$('blsApplicantIndex') || {}).value || '0', 10),
          bls_book_count:       parseInt(($$('blsBookCount')       || {}).value || '1', 10),
          bls_login_attempts:   0,
          bls_login_blocked:    false,
        });
      } catch (_) {}
    });
  }

  // Save selfie
  const saveSelfieBtn = $$('btnSaveBLSSelfie');
  if (saveSelfieBtn) {
    saveSelfieBtn.addEventListener('click', async () => {
      const fileEl  = $$('blsSelfie');
      const statusEl = $$('blsSelfieStatus');
      if (!fileEl || !fileEl.files || !fileEl.files[0]) {
        if (statusEl) statusEl.textContent = 'Pick a file first.';
        return;
      }
      const file = fileEl.files[0];
      const b64  = await fileToDataUri(file);
      await chrome.storage.local.set({ bls_selfie_b64: b64, bls_selfie_name: file.name });
      if (statusEl) statusEl.textContent = describeImage(file.name, b64);
    });
  }

  // Clear selfie
  const clearSelfieBtn = $$('btnClearBLSSelfie');
  if (clearSelfieBtn) {
    clearSelfieBtn.addEventListener('click', async () => {
      await chrome.storage.local.remove(['bls_selfie_b64', 'bls_selfie_name']);
      const statusEl = $$('blsSelfieStatus');
      if (statusEl) statusEl.textContent = 'No selfie saved';
    });
  }
})();

// v1.5.343: externalized inline scripts from options.html.
//
// Why this file exists: Chrome MV3's default Content Security Policy for
// extension pages is `script-src 'self'` which BLOCKS inline <script> blocks.
// All four `(function(){...})()` IIFEs that previously lived at the bottom of
// options.html were silently dropped — that's why slot_preference, vfs_subcat,
// vfs_test_mode, vfs_phone_code, vfs_phone_number never persisted to storage.
//
// options.js is pre-obfuscated externally, so we can't extend it directly.
// This file is the canonical place for any "wire field <-> storage" logic
// that doesn't fit into the obfuscated bundle.

(function () {
  // v1.5.332: slot_preference dropdown
  const sel = document.getElementById('slot_preference');
  if (!sel) return;
  try {
    chrome.storage.local.get(['slot_preference'], (res) => {
      const v = (res && res.slot_preference) || 'no_prime';
      if (['any', 'no_prime', 'standard_only', 'premium_only'].includes(v)) sel.value = v;
      else sel.value = 'no_prime'; // migrate old 'any' users to no_prime
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ slot_preference: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.336: VFS subcategory single-select dropdown.
  // Storage key `vfs_subcat` — one of "Business/Cultural/Sports",
  // "Family/Friends visit", "Tourism". Default: Business/Cultural/Sports.
  const sel = document.getElementById('vfsSubcat');
  if (!sel) return;
  const ALLOWED = ['Business/Cultural/Sports', 'Family/Friends visit', 'Tourism'];
  try {
    chrome.storage.local.get(['vfs_subcat'], (res) => {
      const v = res && res.vfs_subcat;
      sel.value = ALLOWED.includes(v) ? v : 'Business/Cultural/Sports';
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_subcat: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.338: VFS test mode toggle. Bypasses Friday 15-19 Yerevan window
  // when on. Storage key `vfs_test_mode` (boolean). Default off.
  const tm = document.getElementById('vfsTestMode');
  if (!tm) return;
  try {
    chrome.storage.local.get(['vfs_test_mode'], (res) => {
      tm.checked = !!(res && res.vfs_test_mode);
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_test_mode: !!tm.checked });
      } catch (_) {}
    });
  }
})();

// v1.5.414 Phase D: Unified multi-applicant booking UI.
// Manages: vfs_num_applicants, vfs_applicants[], vfs_phone_code, vfs_phone_number.
// Phone is shared across all applicants (Q1). Passport per applicant.
(function () {
  const $$ = id => document.getElementById(id);
  const MAX_APPLICANTS = 6;

  let _applicants = [];   // mirrors vfs_applicants[] in storage
  let _numApplicants = 1;

  function describeFile(b64, name) {
    if (!b64) return 'No passport saved';
    const sizeKb = Math.round((b64.length * 3) / 4 / 1024);
    return `Saved: ${name || 'file'} (~${sizeKb} KB)`;
  }

  function fileToDataUri(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  function renderApplicantCard(idx) {
    const ap = _applicants[idx] || {};
    const visibleNum = idx + 1;
    const card = document.createElement('div');
    card.className = 'vfs-ap-card';
    card.dataset.idx = idx;
    card.style.cssText = 'border:1px solid #334155;border-radius:8px;padding:12px;margin-bottom:12px;';
    card.innerHTML = `
      <div style="font-size:13px;font-weight:600;color:#e2e8f0;margin-bottom:10px;">Applicant ${visibleNum}</div>
      <div class="field">
        <label style="display:block;font-size:12px;color:#94a3b8;margin-bottom:6px;">Passport — Front Page (bio)</label>
        <input type="file" class="ap-passport-front" accept="image/*,.pdf"
          style="padding:6px 0;background:transparent;border:none;color:#94a3b8;">
        <div class="ap-front-status" style="font-size:11px;margin-top:4px;color:#64748b;">${describeFile(ap.passportFrontB64, ap.passportFrontName)}</div>
      </div>
      <div class="field">
        <label style="display:block;font-size:12px;color:#94a3b8;margin-bottom:6px;">Passport — Back Page <span style="color:#475569;font-size:11px;">(optional)</span></label>
        <input type="file" class="ap-passport-back" accept="image/*,.pdf"
          style="padding:6px 0;background:transparent;border:none;color:#94a3b8;">
        <div class="ap-back-status" style="font-size:11px;margin-top:4px;color:#64748b;">${describeFile(ap.passportBackB64, ap.passportBackName)}</div>
      </div>
      <button class="btn btn-test btn-save-ap" style="font-size:12px;padding:7px 14px;margin-top:4px;">Save Applicant ${visibleNum}</button>
    `;

    card.querySelector('.btn-save-ap').addEventListener('click', async () => {
      const frontFile = card.querySelector('.ap-passport-front').files[0];
      const backFile  = card.querySelector('.ap-passport-back').files[0];
      if (!_applicants[idx]) _applicants[idx] = { passportFrontB64: null, passportFrontName: null, passportBackB64: null, passportBackName: null };
      if (frontFile) {
        const b64 = await fileToDataUri(frontFile);
        _applicants[idx].passportFrontB64  = b64;
        _applicants[idx].passportFrontName = frontFile.name;
        card.querySelector('.ap-front-status').textContent = describeFile(b64, frontFile.name);
      }
      if (backFile) {
        const b64 = await fileToDataUri(backFile);
        _applicants[idx].passportBackB64  = b64;
        _applicants[idx].passportBackName = backFile.name;
        card.querySelector('.ap-back-status').textContent = describeFile(b64, backFile.name);
      }
      await chrome.storage.local.set({ vfs_applicants: _applicants });
    });

    return card;
  }

  function renderAllCards(count) {
    const container = $$('vfsApplicantsContainer');
    if (!container) return;
    container.innerHTML = '';
    for (let i = 0; i < count; i++) {
      container.appendChild(renderApplicantCard(i));
    }
  }

  // Load saved state on open
  chrome.storage.local.get(['vfs_num_applicants', 'vfs_applicants', 'vfs_phone_code', 'vfs_phone_number'], (stored) => {
    _numApplicants = Math.max(1, Math.min(MAX_APPLICANTS, stored.vfs_num_applicants || 1));
    _applicants = Array.isArray(stored.vfs_applicants)
      ? JSON.parse(JSON.stringify(stored.vfs_applicants))
      : [];

    const numEl = $$('vfsNumApplicants');
    if (numEl) numEl.value = String(_numApplicants);

    const codeEl = $$('vfsPhoneCode');
    const numPhEl = $$('vfsPhoneNumber');
    if (codeEl && stored.vfs_phone_code) codeEl.value = stored.vfs_phone_code;
    if (numPhEl && stored.vfs_phone_number) numPhEl.value = stored.vfs_phone_number;

    renderAllCards(_numApplicants);
  });

  // Number-of-applicants dropdown: grow or shrink cards, preserve existing data
  const numEl = $$('vfsNumApplicants');
  if (numEl) {
    numEl.addEventListener('change', () => {
      const newCount = Math.max(1, Math.min(MAX_APPLICANTS, parseInt(numEl.value, 10) || 1));
      _numApplicants = newCount;
      // Grow: pad _applicants with empty entries
      while (_applicants.length < newCount) {
        _applicants.push({ passportFrontB64: null, passportFrontName: null, passportBackB64: null, passportBackName: null });
      }
      renderAllCards(newCount);
    });
  }

  // Main Save button — persist all VFS multi-applicant fields
  const saveBtn = $$('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const numEl2  = $$('vfsNumApplicants');
      const codeEl  = $$('vfsPhoneCode');
      const numPhEl = $$('vfsPhoneNumber');
      const count = numEl2 ? Math.max(1, Math.min(MAX_APPLICANTS, parseInt(numEl2.value, 10) || 1)) : _numApplicants;
      const code  = codeEl  ? codeEl.value.replace(/\D/g, '')  : '';
      const num   = numPhEl ? numPhEl.value.replace(/\D/g, '') : '';
      try {
        chrome.storage.local.set({
          vfs_num_applicants: count,
          vfs_phone_code:     code,
          vfs_phone_number:   num,
          vfs_applicants:     _applicants.slice(0, count),
        });
      } catch (_) {}
    });
  }
})();

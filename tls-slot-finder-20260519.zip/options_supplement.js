// v1.5.363: BLS Spain options section
(function () {
  const $$ = (id) => document.getElementById(id);
  const KEYS = ['bls_enabled', 'bls_email', 'bls_password', 'bls_applicant_index', 'bls_book_count', 'bls_selfie_b64', 'bls_selfie_name'];

  function describeImage(name, b64) {
    if (!b64) return 'No selfie saved';
    const sizeKb = Math.round((b64.length * 3) / 4 / 1024);
    return `Stored: ${name || 'selfie'} (~${sizeKb} KB)`;
  }

  function fileToDataUri(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  chrome.storage.local.get(KEYS, (stored) => {
    const enabledEl = $$('blsEnabled');
    const emailEl   = $$('blsEmail');
    const passEl    = $$('blsPassword');
    const idxEl     = $$('blsApplicantIndex');
    const statusEl  = $$('blsSelfieStatus');

    const cntEl     = $$('blsBookCount');
    if (enabledEl) enabledEl.checked = stored.bls_enabled === true;
    if (emailEl)   emailEl.value     = stored.bls_email    || '';
    if (passEl)    passEl.value      = stored.bls_password  || '';
    if (idxEl)     idxEl.value       = stored.bls_applicant_index != null ? stored.bls_applicant_index : 0;
    if (cntEl)     cntEl.value       = stored.bls_book_count != null ? stored.bls_book_count : 1;
    if (statusEl)  statusEl.textContent = describeImage(stored.bls_selfie_name, stored.bls_selfie_b64);
  });

  // Save BLS fields on main Save button
  const saveBtn = $$('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({
          bls_enabled:          !!($$('blsEnabled') && $$('blsEnabled').checked),
          bls_email:            ($$('blsEmail')    || {}).value || '',
          bls_password:         ($$('blsPassword') || {}).value || '',
          bls_applicant_index:  parseInt(($$('blsApplicantIndex') || {}).value || '0', 10),
          bls_book_count:       parseInt(($$('blsBookCount')       || {}).value || '1', 10),
          bls_login_attempts:   0,
          bls_login_blocked:    false,
        });
      } catch (_) {}
    });
  }

  // Save selfie
  const saveSelfieBtn = $$('btnSaveBLSSelfie');
  if (saveSelfieBtn) {
    saveSelfieBtn.addEventListener('click', async () => {
      const fileEl  = $$('blsSelfie');
      const statusEl = $$('blsSelfieStatus');
      if (!fileEl || !fileEl.files || !fileEl.files[0]) {
        if (statusEl) statusEl.textContent = 'Pick a file first.';
        return;
      }
      const file = fileEl.files[0];
      const b64  = await fileToDataUri(file);
      await chrome.storage.local.set({ bls_selfie_b64: b64, bls_selfie_name: file.name });
      if (statusEl) statusEl.textContent = describeImage(file.name, b64);
    });
  }

  // Clear selfie
  const clearSelfieBtn = $$('btnClearBLSSelfie');
  if (clearSelfieBtn) {
    clearSelfieBtn.addEventListener('click', async () => {
      await chrome.storage.local.remove(['bls_selfie_b64', 'bls_selfie_name']);
      const statusEl = $$('blsSelfieStatus');
      if (statusEl) statusEl.textContent = 'No selfie saved';
    });
  }
})();

// v1.5.343: externalized inline scripts from options.html.
//
// Why this file exists: Chrome MV3's default Content Security Policy for
// extension pages is `script-src 'self'` which BLOCKS inline <script> blocks.
// All four `(function(){...})()` IIFEs that previously lived at the bottom of
// options.html were silently dropped — that's why slot_preference, vfs_subcat,
// vfs_test_mode, vfs_phone_code, vfs_phone_number never persisted to storage.
//
// options.js is pre-obfuscated externally, so we can't extend it directly.
// This file is the canonical place for any "wire field <-> storage" logic
// that doesn't fit into the obfuscated bundle.

(function () {
  // v1.5.332: slot_preference dropdown
  const sel = document.getElementById('slot_preference');
  if (!sel) return;
  try {
    chrome.storage.local.get(['slot_preference'], (res) => {
      const v = (res && res.slot_preference) || 'no_prime';
      if (['any', 'no_prime', 'standard_only', 'premium_only'].includes(v)) sel.value = v;
      else sel.value = 'no_prime'; // migrate old 'any' users to no_prime
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ slot_preference: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.336: VFS subcategory single-select dropdown.
  // Storage key `vfs_subcat` — one of "Business/Cultural/Sports",
  // "Family/Friends visit", "Tourism". Default: Business/Cultural/Sports.
  const sel = document.getElementById('vfsSubcat');
  if (!sel) return;
  const ALLOWED = ['Business/Cultural/Sports', 'Family/Friends visit', 'Tourism'];
  try {
    chrome.storage.local.get(['vfs_subcat'], (res) => {
      const v = res && res.vfs_subcat;
      sel.value = ALLOWED.includes(v) ? v : 'Business/Cultural/Sports';
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_subcat: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.338: VFS test mode toggle. Bypasses Friday 15-19 Yerevan window
  // when on. Storage key `vfs_test_mode` (boolean). Default off.
  const tm = document.getElementById('vfsTestMode');
  if (!tm) return;
  try {
    chrome.storage.local.get(['vfs_test_mode'], (res) => {
      tm.checked = !!(res && res.vfs_test_mode);
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_test_mode: !!tm.checked });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.342: VFS phone code + phone number for the contact-details sub-step.
  // Stored as vfs_phone_code and vfs_phone_number (digits only).
  const codeEl = document.getElementById('vfsPhoneCode');
  const numEl  = document.getElementById('vfsPhoneNumber');
  if (!codeEl && !numEl) return;
  try {
    chrome.storage.local.get(['vfs_phone_code', 'vfs_phone_number'], (res) => {
      if (codeEl && res && res.vfs_phone_code) codeEl.value = res.vfs_phone_code;
      if (numEl  && res && res.vfs_phone_number) numEl.value  = res.vfs_phone_number;
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        const code = codeEl ? codeEl.value.replace(/\D/g, '') : '';
        const num  = numEl  ? numEl.value.replace(/\D/g, '')  : '';
        chrome.storage.local.set({
          vfs_phone_code: code,
          vfs_phone_number: num,
        });
      } catch (_) {}
    });
  }
})();

function a0_0x33d2(){const _0x13aa01=['WOKyjq','cc/cPSoQda','lW/cMSoXiW','d8oFWQqV','W47cStj6WOy','W74kW7ShAa','W788eSouDq','qNu1W4G','W68xuCo0ua','WPaclwjN','rMVcLSkTwa','W4usWRbz','ltJdQNldKq','aSoMva94','CCoCWPSXW4tdKZXn','xGTmWQldLq','W47cPInJ','sbDiWPFdLW','W6GRW5xcJZS','WPDBsNGE','nSovhCo4W6e','WPNcVuVcGqG','wCoKqrWh','W7ZcPCodW6NcMG','e8kEW4FcIa','zIRcNmorWOC','v2JdV8oWW6q','WQhcRc3cR8oA','4P6tA2qtsa','fSkmFmk8W4e','v1tdKq3cGa','p8ohW6RcHCod','A8oYWRmgkq','CSk0vmkPWRnfW6BdMGyXW6dcRCk2Fq','WQZcPe3dVh4','rCo0yIhcHG','AKFdSHBcGq','W6hdMxiqWQS','uCoUWOqNja','W7C+qXL+','A8ouW4RdSYO','gCoclmoumq','lCorpCoibq','B8ouWP7dKc8','BmouWPK','sSkKW5JcJIa','tWX0WPhdHa','W4FdNM4xW64','nmo9gCo9W6W','bmkFWOlcPWu','D8o2WPFdNxVcLetdLmkfW61bWOCJ','WRmftmoOgG','W4/cK8o4W7NdQq','gCoZc8ozpG','hSoaWRLIda','W4NcOc9GWQa','W4FdSM3cNCoP','fSkkW6pcQay','WQqVWPlcKtm','lJtdUwxdLG','eJFdNmk9hsfwWR5UgwFcI8kEAW','j3ddQSkLW5m','ymkoWOWZWQ0','WOPekh8O','q1hdICoOW7C','W7SDyaX5','fCotoCoalG','Cc3cRmo3WPtdVbNdR0FdSbeN','W7OnuqDE','dSojW7bPbG','WRpdNxWkWQi','qCo3yH4','EtjOWPhdOq','W54wyXFdJa','re04','rmkUuJlcVq','DSovlmo5pq','qSkNzYVcLq','DvOmW4ZcPa','W63dUM/cR8os','W6Khv8oQ','jCkKW5VcJsa','waTcWOBdNq','WQBcH0O','rcBcNmoaWOa','WOFdUWNcRIK','AmkSFqLU','j8kRW4VdHaW','W4ifWRHgW7C','dmkfWOaIW6m','kCoPcCogW6S','rs7cH8kfWOO','ASoQWPSHia','W4y/W5/cTZy','gSojWQq','DmoGdmoMlW','odldUuxdKW','vmo7WQW','W6zWW51glG','W4yqhW','WOCicNe','xaPbWPW','t8k1W5JcKJe','W5JcUZ5rWRe','B2BcMSoVW7K','qMVcKa','W7BcTg/cPCkC','AJVcKCoXWOS','WOZcQSonW7VdUW','W64qumoJEa','sSoyW5xcVNC','FKBdL8onW5u','W6aQwWnz','h8kjm8oLW7e','xmkrwsnW','W5FdHK/cOCop','W5ldShG','WOaQWRdcSCoy','hXFcI8k4WQGbWOboW6NdLfTK','rCoXzq','vL04WQPN','W6ddJ3irWQ8','4OgkFCoVzCot','W6ddUHtcQIK','W5KCcmoBvW','WOVdN3a','WRtcUeVdQZe','fmkSW7FcHCo1','qmopn8oUlG','r8ojW5lcML0','W4WBW5ZcMJa','DSoMutGH','xmo2WQnGWRG','W5CfWRneW5C','B0pdGqJcGq','W54UWROQwq','zqLXcvy','hmojWRrMaG','xmkPEWX/','WOajevzj','uKFcMSoOW74','WRVIGQOFW79W','WRVcQuJdSxS','W5HKWQ8YcW','jCoIW5/cO8ki','WP7cRuRdVhy','t8kJErnZ','W5RcK8oUW6RcPq','W6hdJNmxWQC','4PYQnb3dGmkS','W5xdRLZdI1O','jWLGdXu','v8olwYyz','hSogWP1Zda','ruKHWPPt','yKJdKmoGW6G','W4CIdmolFq','hmkHW5hcJsW','DvKHWO9j','W48QWQi','yCozW4FcNhu','ru7dM8o6W6m','tcxcLComWPy','WPNcQghcNZG','bG1TiYC','CIpcLConWR4','W7CRW63cLJ8','W50jWRPrW7O','zh4lW6/cSG','E8k8W5pcSmkVjxum','WPCTWP/cUSoP','mNNdS8kLW4C','W6FdP0tcQ8oi','W60+WPuQFG','W5ddK3WxWOC','Ce/dVqBcIG','WQqVW5ZcMxO','B2VdK2BdTuyEWPu','WOKfbNOO','sMVcJCoJ','FKNdQJFcIW','amoNCHSC','W74/W7hcLbC','W7K5amo6wa','WOhdK3i','aYTRfX4','WO7cUx3cHJq','zIRcImkfWO8','W7TTWQCLhG','zSocWO8','w3eWW4hcPG','W7TYWQaKgq','W6tdVxFcVSoz','W64br8oRua','W5SQWOKSsa','qIL+cGi','AepdL8oS','sarWmua','vmoUW7/cOL0','phRdI8ktW5T8W6C3W7eAW4GYWOq','rM3cImo5sq','WRxcJwRcSIS','W64qsG','q3dcJCo7tq','nSksFSkGW5W','WQGdfM8U','E8ouW4RdVc0','sW9gWOS','m8kzWPm3W6i','WRVdSLBdRNa','xmozWOncWOK','W5ifW7LsW70','xgaUW43cRW','omkdWQ7cH8ov','gmkpC8krW5C','oCkHWRajW5q','kCkYW4xcTWq','h8kCB8kKW58','W40RW6X/','tCkQCIr3','W6uSW57cMd4','ACoejW','AmoNWOqrka','WRxcMhtdLv4','W4BcICo+W6m','uLddK8oK','W67dVxJcR8os','W7f0WQOUga','j8kgW6lcHCou','WPeinM5s','BCofWPpIG7O0','WOJdGNldJWO','WRBcOs/dVmkjW77cGL4bWOjvt38','tCkYCG','W6y6W5ZcQt8','pSkiW6u','WOFcUMxdKwS','W7DUWQeNhW','mh3dS8k1W4u','W7mZrX9o','WOVcOh7cIZ8','W44MWQqSsa','W6NcGaTCWPe','uG1cWRRdKG','mSkSW4hcGZW','kCoKW47cPCkn','W7S4ua','DSkmW43cKqK','sSoaW57cIW','jmk1WOSxW50','ntZdRCkLW4e','wfaFW6lcUq','W74hrmomxq','g8kFECkaW4q','vCkRW5hcPcW','gXdcL8oLpG','u8kUW5hcLq','ksLzrbO','zcBcNmoaWOa','WOpcRgpcJsK','W6ddIgOmWRW','W4KOxXDi','fJ47gHK','bmkh4OgzWPa+','F3ldU8oAW4m','lCoMha','dSogWOfZeq','W7xcK8ocW7hcVq','j8k2W5ZcKYa','zhWnWPDX','W5WMWRKXeG','WOSfyNSO','r10/WQ0','rCorg8owfY5T','W7tcHmooW5hcRG','dd90fIe','vmoXFGa','WPeVtsVcPW','WOCtc0Xb','EGmYdui','W4tcKmoyW6FcJa','W5pcHmo5W7NcQa','sSoSFGm','FWPwWQFdVG','z8o6WQ9qWRq','WQlcJsrtW79EWQpdH8ovBGFdOt4','hmkjCSkO','WOezma','WPDlmgKM','W78wydJdQG','BbrGb0G','s8kfrsBcVG','tKpdJSkPW5K','W70SFdhdRG','qIH6dri','WOyldhLl','WOdcKCowW5VdGG','W4q/lSohtq','W5BdVdZdM2v3tuvQEgv+','W5NcKWTyWR0','WO/dUNxdUG4','u00/','s2xcS8oVFa','CConmmouoq','c8oGoCosW5e','WPeccx9h','uNFcKmkJ','WORcU38','W68uuW','mKJdNmkVW5i','AepdSGBcGW','W7TYWRaKga','W6hdVhRcVSkC','FmodWOpdUa','DeaqW7FcNa','imkTW4VcLCoe','FSo/WPKhja','W5pcUJ5RWRC','ySkICGTS','W7eUqYrD','W6SuuSoYua','EYNcISojWOi','EGnM','gCkZW4pcOa','q1OLWQG','A8ozWOVdOqO','w3S3W4hcRW','CbflWPxdHG','FJ7dO2hdHG','WOyFlfGI','DCoOWPi6nG','WQiFWRNcICoi','WONdNN3dRtq','WQz2WPqTid9/','wZqQW43cSG','kg/dUSoGW5y','W7m4rbDB','umohWPWqja','zctcHCo/sq','taHMduG','W4GcW5NcUtS','yCkFWP7dSc8','df/dJSkVW7i','4P6EWP5PW6X5','fdP3dHi','W7CkW6lcKtq','W5pcJSoVW6tcUG','WOddU2vVWRu','oConj8ozjq','qCk1Cea','W6DwW59o','h8oUcmoQ','W50YWPfZW5a','WQq+W57cNdq','ACoOWPqXnG','W5tcS+kbRa','q8kTCG4','W5pcJSo/','W4/dPgBdTfS','W5qxb8oBxq','bYHOgHa','W7xdM0VcRxy','gXdcN8o1jG','m8oZa8oRW6m','wKK8','W545WQPnW7K','WRNcPfFdH3O','eSojoCovmW','WOSPWRu+cq','yCotW4hcGwy','WOddJCk+WRZdVCk9d0xdPwfNeG','EKNdRcBcHq','W5NdG3ihWQ8','4PYDW4FdJ8kaW5W','WR/cVaO','W7GSAbns','CSoSWQGXkW','zSooW4FcSwa','4PIA77UBAG','CmonW4dcSwq','gCkxFmk2W4e','tcTRWQ7dMG','W5OHrG','zwVdJs3cVq','lXFdJNNdHG','WOhcOCopW5NdQW','W4xIGBnf','W6OEWPKRAW','WQ7cTCoRWQ7dUq','nxNdGmkRW4u','q8o3FHSu','zCoKW6pcUN4','thW5W4FcQG','WOCdi3Go','etlcVmoRA1CgW6G','W6aRW5pcMty','W5/cKSoQ','W68aumoZxa','W6pdOh7dQSoW','va1jWOddLq','prRdILBdIG','4P60zbqWWRK','q8oNeCoFeq','W6JdM1hdQvG','WPudcSosua','vL04WQP6','bYnVcry','F8kxW7ZcGW','oYVdOMpdLW','W5ufWRHqW7G','xCk7CYxcIW','W7ldKfG','k8kKW4BcIa','eCodWRnGcW','WQKpmxLj','z8ofqc8B','erxcUColdW','cWJcKCo0na','BSoDWR8Tfa','hSoeWRvLrW','W5KfWRPFWRq','cmkACmkAW4q','W53dUxRcQCou','wxuWW5hcPa','W6/dRLxcSSop','W7SyWRzqW7u','mSoiimoYW5e','W7tdTxFcV8oz','W6pdSh/cJ8ok','BmoeW5dcHtq','zCocWO0','y8kSW5dcIa','B8oslmoL','WP/dL8kKWQddOa','zSkJW47cJsm','sCoTnWyq','vLWP','W5/cPJHHWRC','x07dVXFcRq','W5NcUcT9WRy','W4RdUe8NWOK','W4NcSwPNWQS','sIGYwWq','mCk5wmkWW7S','W7SszIxdKG','fmoRamoMhG','W6FdPMK','W4VdSwZdMq','W7ldKfZdOwa','uKFdGSo9W5m','Aw/dUSkUW4q','CYjWWPhdOq','W4eXwZO','W7pcUJXVWQK','uK3dQCo9W6i','WPqEmwq','W4ZcTszNWQe','kokcPCokW4eM','FvpdQGZcUW','nCoOjCo0W4a','WOqKWR/cQCkr','dJj/gGm','q8kHFJdcJG','W5rrvIiux8k7D8kKaIX0WPm','s8onlSo9WOznWONdJghdUmoObN8','kokbM8oF','umkWDahcKq','WQhcOuddUwS','u8kJDqGq','EdRcJmon','jSoLW4JcO8ki','r07dK8oTW7e','rWD/dq','veCIWRzr','pCoeW6FcJCkk','r23cGSo0','ASoXW7VcIv8','W4ddU2/dQSoi','kSkGW4hcGZS','x8k2EWLI','W60GW5u','zGHMdvq','pX/cQGldLW','ACoXWQa8aW','WR8WWR/cRSoe','W79PWQ4','hmo2bmosca','hq/cJCoNmG','W5ZdPL7dOgq','WOtdSSkVW5pdIq','W5dcKcngWPm','WRGuWPJcKmo1','cCkEqSkUW5C','W5VcJ8oQWQS','W64uzX7dIW','W5pcSmoKW6JcRa','xqPlWPhdKW','umkQW5FcMIK','jgJdSCkuW4u','quKGWRba','w8oDWOxdOwm','bJ56hXS','C8oal8o+oq','emkGW6NcSrS','DCkLWOe9nG'];a0_0x33d2=function(){return _0x13aa01;};return a0_0x33d2();}function a0_0x5c28(_0x14f121,_0x1b20df){_0x14f121=_0x14f121-0x153;const _0x19c9d1=a0_0x33d2();let _0x486f8a=_0x19c9d1[_0x14f121];if(a0_0x5c28['cjBtOC']===undefined){var _0x2beec6=function(_0x144c9a){const _0x21aa83='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x40a2e4='',_0x12ac3f='',_0x396664=_0x40a2e4+_0x2beec6;for(let _0x136cb1=0x0,_0xee1bac,_0x7a9295,_0x31db0d=0x0;_0x7a9295=_0x144c9a['charAt'](_0x31db0d++);~_0x7a9295&&(_0xee1bac=_0x136cb1%0x4?_0xee1bac*0x40+_0x7a9295:_0x7a9295,_0x136cb1++%0x4)?_0x40a2e4+=_0x396664['charCodeAt'](_0x31db0d+0xa)-0xa!==0x0?String['fromCharCode'](0xff&_0xee1bac>>(-0x2*_0x136cb1&0x6)):_0x136cb1:0x0){_0x7a9295=_0x21aa83['indexOf'](_0x7a9295);}for(let _0x52d1f9=0x0,_0x147231=_0x40a2e4['length'];_0x52d1f9<_0x147231;_0x52d1f9++){_0x12ac3f+='%'+('00'+_0x40a2e4['charCodeAt'](_0x52d1f9)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x12ac3f);};const _0x15a688=function(_0x2e1270,_0x51fa43){let _0x41d7b4=[],_0x5e3425=0x0,_0x49d4c0,_0x198941='';_0x2e1270=_0x2beec6(_0x2e1270);let _0x7695bb;for(_0x7695bb=0x0;_0x7695bb<0x100;_0x7695bb++){_0x41d7b4[_0x7695bb]=_0x7695bb;}for(_0x7695bb=0x0;_0x7695bb<0x100;_0x7695bb++){_0x5e3425=(_0x5e3425+_0x41d7b4[_0x7695bb]+_0x51fa43['charCodeAt'](_0x7695bb%_0x51fa43['length']))%0x100,_0x49d4c0=_0x41d7b4[_0x7695bb],_0x41d7b4[_0x7695bb]=_0x41d7b4[_0x5e3425],_0x41d7b4[_0x5e3425]=_0x49d4c0;}_0x7695bb=0x0,_0x5e3425=0x0;for(let _0x31450c=0x0;_0x31450c<_0x2e1270['length'];_0x31450c++){_0x7695bb=(_0x7695bb+0x1)%0x100,_0x5e3425=(_0x5e3425+_0x41d7b4[_0x7695bb])%0x100,_0x49d4c0=_0x41d7b4[_0x7695bb],_0x41d7b4[_0x7695bb]=_0x41d7b4[_0x5e3425],_0x41d7b4[_0x5e3425]=_0x49d4c0,_0x198941+=String['fromCharCode'](_0x2e1270['charCodeAt'](_0x31450c)^_0x41d7b4[(_0x41d7b4[_0x7695bb]+_0x41d7b4[_0x5e3425])%0x100]);}return _0x198941;};a0_0x5c28['DqhEFZ']=_0x15a688,a0_0x5c28['kZitLR']={},a0_0x5c28['cjBtOC']=!![];}const _0x33d252=_0x19c9d1[0x0],_0x5c2840=_0x14f121+_0x33d252,_0x328f60=a0_0x5c28['kZitLR'][_0x5c2840];if(!_0x328f60){if(a0_0x5c28['btoLbi']===undefined){const _0x1ebd94=function(_0x112dfa){this['oioxQq']=_0x112dfa,this['jXYnRu']=[0x1,0x0,0x0],this['EpHnyY']=function(){return'newState';},this['MVHIjk']='\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*',this['WOHnvM']='[\x27|\x22].+[\x27|\x22];?\x20*}';};_0x1ebd94['prototype']['WHCHrJ']=function(){const _0x4803a2=new RegExp(this['MVHIjk']+this['WOHnvM']),_0xf54cbe=_0x4803a2['test'](this['EpHnyY']['toString']())?--this['jXYnRu'][0x1]:--this['jXYnRu'][0x0];return this['vgEkGD'](_0xf54cbe);},_0x1ebd94['prototype']['vgEkGD']=function(_0x533629){if(!Boolean(~_0x533629))return _0x533629;return this['ZFEniQ'](this['oioxQq']);},_0x1ebd94['prototype']['ZFEniQ']=function(_0x47f0cd){for(let _0x4f71b9=0x0,_0x4815e0=this['jXYnRu']['length'];_0x4f71b9<_0x4815e0;_0x4f71b9++){this['jXYnRu']['push'](Math['round'](Math['random']())),_0x4815e0=this['jXYnRu']['length'];}return _0x47f0cd(this['jXYnRu'][0x0]);},new _0x1ebd94(a0_0x5c28)['WHCHrJ'](),a0_0x5c28['btoLbi']=!![];}_0x486f8a=a0_0x5c28['DqhEFZ'](_0x486f8a,_0x1b20df),a0_0x5c28['kZitLR'][_0x5c2840]=_0x486f8a;}else _0x486f8a=_0x328f60;return _0x486f8a;}const a0_0x5e70b8=a0_0x5c28;(function(_0x46e5f2,_0x4bfa34){const _0x3f4e39=a0_0x5c28,_0x343a21=_0x46e5f2();while(!![]){try{const _0x5fd22=parseInt(_0x3f4e39(0x2ad,'k^4g'))/0x1+parseInt(_0x3f4e39(0x29c,'[M63'))/0x2+parseInt(_0x3f4e39(0x240,'*1JE'))/0x3*(parseInt(_0x3f4e39(0x182,'e1oq'))/0x4)+-parseInt(_0x3f4e39(0x278,'TAj^'))/0x5*(parseInt(_0x3f4e39(0x18e,'qe0v'))/0x6)+parseInt(_0x3f4e39(0x159,'%$XQ'))/0x7*(parseInt(_0x3f4e39(0x31b,'hO]1'))/0x8)+-parseInt(_0x3f4e39(0x19b,'T7)m'))/0x9+-parseInt(_0x3f4e39(0x28b,'YQYG'))/0xa;if(_0x5fd22===_0x4bfa34)break;else _0x343a21['push'](_0x343a21['shift']());}catch(_0x55b7ed){_0x343a21['push'](_0x343a21['shift']());}}}(a0_0x33d2,0x9ed65));const $=_0x4d1ea2=>document[a0_0x5e70b8(0x295,'8gAi')+a0_0x5e70b8(0x326,'qO]O')+a0_0x5e70b8(0x282,'f^9x')](_0x4d1ea2),LICENSE_API=a0_0x5e70b8(0x2ac,'e1oq')+a0_0x5e70b8(0x1cc,'Bx@w')+a0_0x5e70b8(0x269,'3ZGb')+'aedge'+a0_0x5e70b8(0x29d,'Nt[s')+a0_0x5e70b8(0x1f5,'LYfp')+a0_0x5e70b8(0x28c,'BcF&')+'te',OWNER_KEY='VE-OW'+'NER-B'+a0_0x5e70b8(0x179,'(ftV')+a0_0x5e70b8(0x2e5,'BcF&');async function load(){const _0x2ee987=a0_0x5e70b8,_0x183a70={'kaWbP':function(_0x5502c7,_0x5dc0c5){return _0x5502c7!==_0x5dc0c5;},'HQDMD':_0x2ee987(0x1a6,'k^4g'),'URTks':_0x2ee987(0x16c,'p]x3'),'JCQoR':'STOP_'+_0x2ee987(0x330,'^hKH')+'NG','yMSNY':_0x2ee987(0x2cc,'y9NW'),'ghCgX':'(((.+'+_0x2ee987(0x222,'38h(')+'+$','iLMVC':function(_0x377d35,_0x4683f0,_0x3415c4){return _0x377d35(_0x4683f0,_0x3415c4);},'GzfLv':function(_0x44cd73){return _0x44cd73();},'iiGMZ':_0x2ee987(0x1ea,'^hKH')+_0x2ee987(0x1d5,'%wlL'),'aQVFZ':'chat_'+'id','gjWIL':_0x2ee987(0x30a,'^hKH')+_0x2ee987(0x176,'^xVo')+_0x2ee987(0x1d0,'YQYG'),'rlUlE':_0x2ee987(0x173,'8)9r')+'se_ke'+'y','EYjyv':_0x2ee987(0x315,'k^4g')+_0x2ee987(0x304,'5d6]')+_0x2ee987(0x329,'qO]O')+'e','wHLKl':function(_0x46e107,_0x56123a){return _0x46e107(_0x56123a);},'soOrE':'botTo'+_0x2ee987(0x2cb,'NUFr'),'FFRTM':_0x2ee987(0x1b6,'8gAi')+'d','KBEuI':_0x2ee987(0x207,'*m0D')+_0x2ee987(0x318,'qe0v')+'ds','lRHGD':_0x2ee987(0x2e2,'5d6]')+'ook','YCRDG':function(_0x3abdd6,_0x384299){return _0x3abdd6!==_0x384299;},'PvpxX':function(_0x5663ef,_0x3885d3){return _0x5663ef(_0x3885d3);},'oRKEK':function(_0x1add53,_0x5aab5d){return _0x1add53===_0x5aab5d;},'dYhPP':_0x2ee987(0x1fc,'$#*i')+'ine_d'+_0x2ee987(0x225,'5d6]'),'dTFic':function(_0x2dcb70,_0x3b569d){return _0x2dcb70(_0x3b569d);},'zQUbY':_0x2ee987(0x348,'3ZGb')+_0x2ee987(0x256,'qO]O'),'KjWKs':function(_0x55ffbf,_0x3d3a55){return _0x55ffbf(_0x3d3a55);}},_0x4068e1=(function(){const _0x33bad3=_0x2ee987,_0x3c3eef={'ehkGc':function(_0x64d90a,_0x2af675){const _0x52ad2d=a0_0x5c28;return _0x183a70[_0x52ad2d(0x19f,'M5Rt')](_0x64d90a,_0x2af675);},'ZDgXv':_0x183a70[_0x33bad3(0x25c,'[JLP')],'EqCuB':_0x183a70[_0x33bad3(0x2dd,'%$XQ')]};let _0x337e76=!![];return function(_0x59e515,_0x336874){const _0x436e59=_0x337e76?function(){const _0x378742=a0_0x5c28;if(_0x336874){if(_0x3c3eef[_0x378742(0x279,'[iqq')](_0x3c3eef[_0x378742(0x333,'T7)m')],_0x3c3eef[_0x378742(0x317,')b!&')])){const _0x1b0a2a=_0x336874['apply'](_0x59e515,arguments);return _0x336874=null,_0x1b0a2a;}else _0x42dbe8[_0x378742(0x250,'%wlL')](',')['map'](_0x26ac99=>_0x26ac99[_0x378742(0x2ba,'Nt[s')]())[_0x378742(0x261,'[iqq')+'r'](_0x1c04c6)[_0x378742(0x1e4,'IGZ3')+'ch'](_0x2e7d17=>{const _0x5bde51=_0x378742;if(!_0x59154d[_0x5bde51(0x231,'AKUD')+'des'](_0x2e7d17))_0x458655[_0x5bde51(0x34a,'38h(')](_0x2e7d17);});}}:function(){};return _0x337e76=![],_0x436e59;};}()),_0x415c4d=_0x183a70[_0x2ee987(0x22e,'e1oq')](_0x4068e1,this,function(){const _0x39787b=_0x2ee987,_0x391700={'dVvXP':_0x183a70[_0x39787b(0x1c7,'k^4g')]};if(_0x183a70[_0x39787b(0x1f0,'IGZ3')]!==_0x183a70[_0x39787b(0x341,'TAj^')])_0x3bf636[_0x39787b(0x1fe,'Nt[s')+'me'][_0x39787b(0x204,'AKUD')+_0x39787b(0x1d9,'*m0D')+'e']({'type':_0x391700[_0x39787b(0x30e,'*m0D')]},()=>{const _0x323fb7=_0x39787b;_0x2c310e['runti'+'me']['sendM'+_0x323fb7(0x1c1,'^xVo')+'e']({'type':_0x323fb7(0x17e,'5d6]')+_0x323fb7(0x25f,'z1jU')+_0x323fb7(0x2bd,'T7)m')});});else return _0x415c4d[_0x39787b(0x298,'[iqq')+_0x39787b(0x20c,'AKUD')]()[_0x39787b(0x276,'hO]1')+'h'](_0x183a70[_0x39787b(0x314,'[JLP')])[_0x39787b(0x237,'(ftV')+_0x39787b(0x251,'$#*i')]()[_0x39787b(0x24a,'5d6]')+'ructo'+'r'](_0x415c4d)[_0x39787b(0x2c2,'tv@4')+'h'](_0x183a70['ghCgX']);});_0x183a70['GzfLv'](_0x415c4d);const _0xfbed1b=await chrome[_0x2ee987(0x212,'V042')+'ge'][_0x2ee987(0x20e,'gK2[')][_0x2ee987(0x2c8,'gK2[')]([_0x183a70[_0x2ee987(0x211,'V042')],_0x183a70['aQVFZ'],_0x183a70['gjWIL'],_0x2ee987(0x206,'5d6]')+'book',_0x2ee987(0x20a,'tv@4')+'ine_d'+_0x2ee987(0x15a,'%wlL'),_0x2ee987(0x1df,'BcF&')+_0x2ee987(0x271,'p]x3'),_0x2ee987(0x1ec,'^hKH')+'asswo'+'rd',_0x183a70[_0x2ee987(0x189,'38h(')],_0x183a70['EYjyv']]);_0x183a70[_0x2ee987(0x24b,'vzOU')]($,_0x183a70['soOrE'])[_0x2ee987(0x1c9,'*m0D')]=_0xfbed1b[_0x2ee987(0x2d1,'Bx@w')+_0x2ee987(0x171,'5BFO')]||'',_0x183a70[_0x2ee987(0x302,'(4U4')]($,_0x183a70[_0x2ee987(0x203,'9RnT')])[_0x2ee987(0x21c,'%$XQ')]=_0xfbed1b[_0x2ee987(0x1bd,'4U4P')+'id']||'',$(_0x183a70[_0x2ee987(0x22c,'4axs')])[_0x2ee987(0x28e,'IGZ3')]=_0xfbed1b['extra'+'_chat'+_0x2ee987(0x220,'5BFO')]||'',_0x183a70[_0x2ee987(0x1ee,'[iqq')]($,_0x183a70[_0x2ee987(0x1d1,'tv@4')])['check'+'ed']=_0x183a70[_0x2ee987(0x229,'qe0v')](_0xfbed1b[_0x2ee987(0x23b,'IGZ3')+_0x2ee987(0x2ce,'*1JE')],![]),_0x183a70[_0x2ee987(0x294,'e1oq')]($,_0x2ee987(0x1a7,'IGZ3')+'ramVe'+_0x2ee987(0x28f,'qe0v'))[_0x2ee987(0x166,'vzOU')+'ed']=_0x183a70[_0x2ee987(0x2b3,'z1jU')](_0xfbed1b[_0x2ee987(0x328,'p]x3')+_0x2ee987(0x216,'4axs')+_0x2ee987(0x1cb,'38h(')+'e'],!![]),$(_0x183a70[_0x2ee987(0x16a,'TAj^')])['value']=_0xfbed1b[_0x2ee987(0x266,'*m0D')+_0x2ee987(0x164,'[iqq')+'ate']||'',_0x183a70[_0x2ee987(0x29f,'e1oq')]($,_0x183a70[_0x2ee987(0x194,'f#]t')])[_0x2ee987(0x264,'5d6]')]=_0xfbed1b[_0x2ee987(0x1a0,'9RnT')+_0x2ee987(0x20d,'[M63')]||'',_0x183a70[_0x2ee987(0x312,'p]x3')]($,'tlsPa'+_0x2ee987(0x2b7,'f#]t')+'d')[_0x2ee987(0x218,'p]x3')]=_0xfbed1b['tls_p'+_0x2ee987(0x17d,'[M63')+'rd']||'',$(_0x2ee987(0x311,'tv@4')+_0x2ee987(0x2f0,'IGZ3')+'y')[_0x2ee987(0x2c6,'3ZGb')]=_0xfbed1b['licen'+_0x2ee987(0x25d,'4axs')+'y']||'',_0xfbed1b[_0x2ee987(0x247,'vzOU')+_0x2ee987(0x310,'$#*i')+'y']&&updateLicenseStatus('','');}function updateLicenseStatus(_0x2a705f,_0x5da25d){const _0x54d3a0=a0_0x5e70b8,_0x1ffdd7={'crzKh':_0x54d3a0(0x2e6,'I4BD')+_0x54d3a0(0x32c,')b!&')+_0x54d3a0(0x2b1,'(4U4'),'uzBvZ':function(_0x3450ee,_0x4834ee){return _0x3450ee===_0x4834ee;},'RZeTy':_0x54d3a0(0x285,'%$XQ')+'ac','bprqs':function(_0x39d6b6,_0xf1585){return _0x39d6b6===_0xf1585;},'zljhP':_0x54d3a0(0x1e1,')b!&')+'a5'},_0x308658=$(_0x1ffdd7[_0x54d3a0(0x16d,'Nt[s')]);if(!_0x308658)return;_0x308658['textC'+_0x54d3a0(0x2b9,'%$XQ')+'t']=_0x2a705f,_0x308658[_0x54d3a0(0x32b,'Nt[s')]['color']=_0x1ffdd7[_0x54d3a0(0x2b5,'f#]t')](_0x5da25d,'ok')?_0x1ffdd7[_0x54d3a0(0x1bc,'[JLP')]:_0x1ffdd7['bprqs'](_0x5da25d,_0x54d3a0(0x1a4,'T7)m'))?_0x1ffdd7[_0x54d3a0(0x30f,'8)9r')]:_0x54d3a0(0x253,'IGZ3')+'b8';}function showMsg(_0x241b7d,_0x53ba45){const _0x3a3b54=a0_0x5e70b8,_0x258027={'tzudn':function(_0x1b656a,_0x1ee84f){return _0x1b656a+_0x1ee84f;},'TZYyN':_0x3a3b54(0x1ce,'%wlL')},_0x270a7e=$(_0x3a3b54(0x167,'^xVo'));_0x270a7e[_0x3a3b54(0x232,'(ftV')+'onten'+'t']=_0x241b7d,_0x270a7e[_0x3a3b54(0x1db,'V042')+_0x3a3b54(0x249,'!(h#')]=_0x258027[_0x3a3b54(0x29a,'YQYG')](_0x258027[_0x3a3b54(0x1d7,'AKUD')],_0x53ba45),setTimeout(()=>{const _0x34b4c0=_0x3a3b54;_0x270a7e[_0x34b4c0(0x228,'Bx@w')+'Name']=_0x34b4c0(0x26a,'gzfg');},0xfa0);}$(a0_0x5e70b8(0x1ad,'3ZGb')+'ve')[a0_0x5e70b8(0x16e,'4axs')+'entLi'+'stene'+'r'](a0_0x5e70b8(0x198,'*1JE'),async()=>{const _0x2558a6=a0_0x5e70b8,_0x1c94ca={'NyfPc':_0x2558a6(0x163,'Bx@w')+'_POLL'+_0x2558a6(0x2de,'AKUD'),'qJEyt':function(_0x15c6c2,_0x18d548){return _0x15c6c2(_0x18d548);},'eMyOT':_0x2558a6(0x2ee,'NUFr')+'d','uoImB':_0x2558a6(0x24e,'%$XQ')+'oken\x20'+_0x2558a6(0x2c1,'[M63')+_0x2558a6(0x195,'(ftV')+_0x2558a6(0x1c3,'M5Rt')+_0x2558a6(0x32d,'*m0D')+'ired.','NPcFO':'err','sjQrv':_0x2558a6(0x18a,'38h(')+_0x2558a6(0x2eb,'^hKH')+'ds','RTDQO':_0x2558a6(0x1a2,'*1JE')+'ramVe'+_0x2558a6(0x272,'Nt[s'),'Fdmya':'tlsPa'+_0x2558a6(0x175,'qe0v')+'d','EKyiE':function(_0x3d37cf,_0x1ae5ee){return _0x3d37cf(_0x1ae5ee);},'BxCZg':_0x2558a6(0x319,'IGZ3')+_0x2558a6(0x1f6,'k^4g')+'y','KrOnd':'STOP_'+_0x2558a6(0x2a3,'[M63')+'NG','uzWhF':function(_0x462b43,_0x85f36c,_0x1c383a){return _0x462b43(_0x85f36c,_0x1c383a);}},_0x329c39=_0x1c94ca[_0x2558a6(0x1ac,'f^9x')]($,'botTo'+_0x2558a6(0x322,'4U4P'))[_0x2558a6(0x1b1,'Nt[s')][_0x2558a6(0x1aa,'8gAi')](),_0x199dad=_0x1c94ca[_0x2558a6(0x19a,'I4BD')]($,_0x1c94ca['eMyOT'])['value']['trim']();if(!_0x329c39||!_0x199dad){showMsg(_0x1c94ca[_0x2558a6(0x23c,'YQYG')],_0x1c94ca[_0x2558a6(0x300,'AKUD')]);return;}const _0x150e16=$(_0x1c94ca[_0x2558a6(0x17b,'gK2[')])[_0x2558a6(0x2f1,')b!&')][_0x2558a6(0x1cf,'y9NW')]();await chrome['stora'+'ge']['local'][_0x2558a6(0x1b3,'!(h#')]({'bot_token':_0x329c39,'chat_id':_0x199dad,'extra_chat_ids':_0x150e16,'auto_book':_0x1c94ca[_0x2558a6(0x1f1,'hO]1')]($,_0x2558a6(0x291,'^xVo')+_0x2558a6(0x15c,'f^9x'))[_0x2558a6(0x1f9,'p]x3')+'ed'],'telegram_verbose':_0x1c94ca['qJEyt']($,_0x1c94ca['RTDQO'])[_0x2558a6(0x2bc,'[iqq')+'ed'],'deadline_date':_0x1c94ca[_0x2558a6(0x284,'(ftV')]($,_0x2558a6(0x293,'e1oq')+'ine_d'+'ate')[_0x2558a6(0x15f,'k^4g')]||'','tls_email':$('tlsEm'+_0x2558a6(0x2e7,'4U4P'))[_0x2558a6(0x267,'9RnT')][_0x2558a6(0x34b,'(ftV')](),'tls_password':$(_0x1c94ca[_0x2558a6(0x2f9,'qO]O')])[_0x2558a6(0x297,'5BFO')],'license_key':_0x1c94ca[_0x2558a6(0x2e9,'f^9x')]($,_0x1c94ca[_0x2558a6(0x183,'38h(')])[_0x2558a6(0x264,'5d6]')][_0x2558a6(0x275,'tv@4')]()});const _0x14e562=await chrome[_0x2558a6(0x27b,'[iqq')+'ge'][_0x2558a6(0x262,'5BFO')][_0x2558a6(0x309,')b!&')]([_0x2558a6(0x2df,'[JLP')+_0x2558a6(0x1e9,'3ZGb')+_0x2558a6(0x346,'$#*i')]);_0x14e562[_0x2558a6(0x2f4,'%wlL')+_0x2558a6(0x1e8,'^xVo')+_0x2558a6(0x1d8,'I4BD')]&&chrome[_0x2558a6(0x23f,'f#]t')+'me'][_0x2558a6(0x2d7,'Nt[s')+_0x2558a6(0x258,'V042')+'e']({'type':_0x1c94ca[_0x2558a6(0x288,'IGZ3')]},()=>{const _0x1aff21=_0x2558a6;chrome[_0x1aff21(0x2fe,'qe0v')+'me']['sendM'+_0x1aff21(0x2aa,'(ftV')+'e']({'type':_0x1c94ca[_0x1aff21(0x2d8,'^hKH')]});}),_0x1c94ca[_0x2558a6(0x254,'3ZGb')](showMsg,_0x2558a6(0x286,'^xVo')+_0x2558a6(0x165,'[M63')+_0x2558a6(0x197,'*m0D')+'d!','ok');}),$(a0_0x5e70b8(0x1ba,'gzfg')+'st')[a0_0x5e70b8(0x21d,'%$XQ')+'entLi'+a0_0x5e70b8(0x2a1,'Bx@w')+'r'](a0_0x5e70b8(0x2a0,'gK2['),async()=>{const _0x16c0ff=a0_0x5e70b8,_0x36c9f7={'cjMrk':function(_0xfdc876,_0x27450a){return _0xfdc876(_0x27450a);},'VeFUT':_0x16c0ff(0x21f,'8gAi'),'Oucsu':function(_0xbe063d,_0x28aa0f){return _0xbe063d+_0x28aa0f;},'TNFdb':_0x16c0ff(0x25e,'38h('),'OaVss':function(_0x576136,_0x2b14fa,_0x1f0e44){return _0x576136(_0x2b14fa,_0x1f0e44);},'LhTci':function(_0x4fa2d7,_0x5c9f55){return _0x4fa2d7(_0x5c9f55);},'XdmDE':'extra'+_0x16c0ff(0x227,'IGZ3')+'ds','zqCiM':function(_0x47eaa6,_0x250106){return _0x47eaa6||_0x250106;},'rVHyQ':function(_0x48e1af,_0x3bcf5e,_0x2415e0){return _0x48e1af(_0x3bcf5e,_0x2415e0);},'OmfGu':_0x16c0ff(0x1c4,'!(h#')+_0x16c0ff(0x2a8,'TAj^')+_0x16c0ff(0x1b7,'p]x3')+_0x16c0ff(0x31a,'$#*i')+_0x16c0ff(0x1a9,'%$XQ')+_0x16c0ff(0x2d2,'(ftV')+_0x16c0ff(0x26d,'gK2['),'LLkDa':'err','HAWtW':_0x16c0ff(0x2fb,'BcF&')+_0x16c0ff(0x1d4,'Bx@w'),'CoOzt':function(_0x1e40d3,_0x442552,_0x438153){return _0x1e40d3(_0x442552,_0x438153);},'fejpC':'POST','HUngj':_0x16c0ff(0x323,'*m0D')+_0x16c0ff(0x2bb,'[M63')+'n/jso'+'n','JYNbS':_0x16c0ff(0x202,'z1jU')+'Visa\x20'+_0x16c0ff(0x265,'8gAi')+'Finde'+_0x16c0ff(0x27d,'*1JE')+_0x16c0ff(0x23a,'8gAi')+_0x16c0ff(0x27c,'$#*i')+'m\x20con'+_0x16c0ff(0x283,'8)9r')+_0x16c0ff(0x180,'gzfg')+'rking'+'!','mVWzE':function(_0x12980c,_0x3c3dc9){return _0x12980c===_0x3c3dc9;},'aQIbU':_0x16c0ff(0x1af,'%wlL'),'jDiHV':function(_0x3fecea,_0x5cc4ed){return _0x3fecea!==_0x5cc4ed;},'JIyjL':_0x16c0ff(0x15d,'BcF&'),'ZNPhe':function(_0x4b0492,_0x1002d4,_0x1b543c){return _0x4b0492(_0x1002d4,_0x1b543c);},'AbbYz':function(_0x59370c,_0x254965){return _0x59370c>_0x254965;},'aEPTj':function(_0x2d9c74,_0x5793a6){return _0x2d9c74===_0x5793a6;},'KgUKS':_0x16c0ff(0x31c,'gzfg'),'gfyIu':function(_0x1e84c8,_0x2302b2,_0x587750){return _0x1e84c8(_0x2302b2,_0x587750);},'rOLkS':function(_0x80fd7e,_0x444421){return _0x80fd7e+_0x444421;},'ygVqr':_0x16c0ff(0x1e6,'f^9x')+_0x16c0ff(0x2b0,'qe0v')+_0x16c0ff(0x344,')b!&'),'GXamq':function(_0x4520c1,_0x4f29de){return _0x4520c1(_0x4f29de);},'iKdrf':_0x16c0ff(0x263,'k^4g')+'st','NRHjm':_0x16c0ff(0x299,'qe0v')+'Teleg'+_0x16c0ff(0x1a5,'Nt[s'),'nPHgK':function(_0x2355e7,_0x5e1e01){return _0x2355e7(_0x5e1e01);}},_0x28ca43=_0x36c9f7['cjMrk']($,_0x16c0ff(0x31e,'IGZ3')+_0x16c0ff(0x1ef,'z1jU'))[_0x16c0ff(0x30d,'T7)m')][_0x16c0ff(0x185,'(4U4')](),_0x542f38=$(_0x16c0ff(0x1fa,'gzfg')+'d')[_0x16c0ff(0x30d,'T7)m')][_0x16c0ff(0x185,'(4U4')](),_0x12430f=_0x36c9f7[_0x16c0ff(0x337,'gzfg')]($,_0x36c9f7[_0x16c0ff(0x2d9,'(ftV')])?_0x36c9f7[_0x16c0ff(0x20f,'*1JE')]($,_0x36c9f7[_0x16c0ff(0x18d,'NUFr')])[_0x16c0ff(0x1c9,'*m0D')][_0x16c0ff(0x27a,'Bx@w')]():'';if(_0x36c9f7[_0x16c0ff(0x320,'$#*i')](!_0x28ca43,!_0x542f38)){_0x36c9f7[_0x16c0ff(0x213,'3ZGb')](showMsg,_0x36c9f7['OmfGu'],_0x36c9f7[_0x16c0ff(0x1c2,'3ZGb')]);return;}const _0xedf6c9=[_0x542f38];_0x12430f&&_0x12430f[_0x16c0ff(0x2d0,'5BFO')](',')['map'](_0x43b1e6=>_0x43b1e6['trim']())[_0x16c0ff(0x32a,'%$XQ')+'r'](Boolean)[_0x16c0ff(0x2ca,'hO]1')+'ch'](_0x1ea52b=>{const _0xe9c9ad=_0x16c0ff;if(!_0xedf6c9[_0xe9c9ad(0x231,'AKUD')+_0xe9c9ad(0x296,'8gAi')](_0x1ea52b))_0xedf6c9[_0xe9c9ad(0x246,'8)9r')](_0x1ea52b);});$(_0x16c0ff(0x15b,'$#*i')+'st')['textC'+'onten'+'t']=_0x36c9f7[_0x16c0ff(0x234,'[iqq')],_0x36c9f7[_0x16c0ff(0x196,'z1jU')]($,_0x16c0ff(0x340,'4axs')+'st')['disab'+_0x16c0ff(0x347,'9RnT')]=!![];const _0xd5f9a=[];for(const _0x1c8eb0 of _0xedf6c9){try{const _0x3bf009=await _0x36c9f7[_0x16c0ff(0x2d6,'LYfp')](fetch,'https'+'://ap'+_0x16c0ff(0x1c6,'8gAi')+_0x16c0ff(0x343,'4axs')+_0x16c0ff(0x301,'!(h#')+_0x16c0ff(0x2d3,'M5Rt')+_0x28ca43+(_0x16c0ff(0x233,'k^4g')+_0x16c0ff(0x290,'3ZGb')+'ge'),{'method':_0x36c9f7[_0x16c0ff(0x2ef,'tv@4')],'headers':{'Content-Type':_0x36c9f7[_0x16c0ff(0x2ec,'$#*i')]},'body':JSON['strin'+_0x16c0ff(0x24c,'M5Rt')]({'chat_id':_0x1c8eb0,'text':_0x36c9f7[_0x16c0ff(0x281,'38h(')],'parse_mode':_0x16c0ff(0x1b4,'f^9x')})});if(_0x3bf009['ok'])_0xd5f9a[_0x16c0ff(0x238,'gzfg')]({'id':_0x1c8eb0,'ok':!![]});else{if(_0x36c9f7[_0x16c0ff(0x2ab,'^xVo')](_0x36c9f7[_0x16c0ff(0x257,'e1oq')],_0x36c9f7['aQIbU'])){const _0x3ff9c7=await _0x3bf009[_0x16c0ff(0x221,'9RnT')]();_0xd5f9a[_0x16c0ff(0x235,'z1jU')]({'id':_0x1c8eb0,'ok':![],'err':_0x3ff9c7['descr'+'iptio'+'n']});}else{const _0xef6197=aRwlWC[_0x16c0ff(0x303,'gK2[')](_0x533629,aRwlWC[_0x16c0ff(0x268,'[M63')]);_0xef6197['textC'+_0x16c0ff(0x252,'!(h#')+'t']=_0x47f0cd,_0xef6197[_0x16c0ff(0x1ed,'4axs')+_0x16c0ff(0x32e,'(ftV')]=aRwlWC[_0x16c0ff(0x255,'[JLP')](aRwlWC['TNFdb'],_0x4f71b9),aRwlWC['OaVss'](_0x4815e0,()=>{const _0x2b802e=_0x16c0ff;_0xef6197[_0x2b802e(0x30b,'(ftV')+_0x2b802e(0x169,'^hKH')]='msg';},0xfa0);}}}catch(_0x4d7f0d){_0xd5f9a[_0x16c0ff(0x181,'5d6]')]({'id':_0x1c8eb0,'ok':![],'err':_0x4d7f0d['messa'+'ge']});}}const _0x143bcf=_0xd5f9a['filte'+'r'](_0x43848b=>_0x43848b['ok']),_0x101347=_0xd5f9a[_0x16c0ff(0x332,'M5Rt')+'r'](_0x5b58a4=>!_0x5b58a4['ok']);if(_0x101347['lengt'+'h']===0x0)_0x36c9f7[_0x16c0ff(0x25b,'Bx@w')](_0x36c9f7[_0x16c0ff(0x168,'5BFO')],_0x36c9f7[_0x16c0ff(0x270,'I4BD')])?_0x4f7f50['class'+_0x16c0ff(0x169,'^hKH')]=aRwlWC[_0x16c0ff(0x2ed,'(4U4')]:_0x36c9f7[_0x16c0ff(0x2b8,'p]x3')](showMsg,'✅\x20Sen'+_0x16c0ff(0x2d4,'%$XQ')+_0x143bcf['lengt'+'h']+(_0x16c0ff(0x1b9,'hO]1')+_0x16c0ff(0x22b,'*m0D')+_0x16c0ff(0x1d3,'3ZGb')+_0x16c0ff(0x1b2,'8)9r')+'y!'),'ok');else{if(_0x36c9f7[_0x16c0ff(0x32f,'!(h#')](_0x143bcf[_0x16c0ff(0x174,'T7)m')+'h'],0x0)){if(_0x36c9f7[_0x16c0ff(0x1f8,'^hKH')](_0x16c0ff(0x22d,'z1jU'),_0x36c9f7[_0x16c0ff(0x1a1,'YQYG')])){if(!_0x2668b3[_0x16c0ff(0x15e,'qO]O')+_0x16c0ff(0x19e,'5d6]')](_0xa83012))_0x1cda53['push'](_0x49d0f8);}else _0x36c9f7['gfyIu'](showMsg,_0x16c0ff(0x1eb,'Bx@w')+_0x143bcf[_0x16c0ff(0x24f,'[M63')+'h']+_0x16c0ff(0x172,'!(h#')+_0x101347['lengt'+'h']+(_0x16c0ff(0x223,'[M63')+'ed:\x20')+_0x101347[_0x16c0ff(0x17a,'YQYG')](_0x38ea10=>_0x38ea10['id']+_0x16c0ff(0x1f3,'*1JE')+_0x38ea10[_0x16c0ff(0x1d6,'38h(')])[_0x16c0ff(0x31d,'M5Rt')](';\x20'),_0x36c9f7[_0x16c0ff(0x1c5,'$#*i')]);}else _0x36c9f7[_0x16c0ff(0x17c,'38h(')](showMsg,_0x36c9f7[_0x16c0ff(0x21b,'YQYG')](_0x36c9f7[_0x16c0ff(0x280,'(4U4')],_0x101347[_0x16c0ff(0x1dd,'5d6]')](_0xa9218d=>_0xa9218d['id']+_0x16c0ff(0x242,'8)9r')+_0xa9218d[_0x16c0ff(0x2e1,'(4U4')])['join'](';\x20')),_0x36c9f7[_0x16c0ff(0x321,'I4BD')]);}_0x36c9f7[_0x16c0ff(0x259,'AKUD')]($,_0x36c9f7['iKdrf'])['textC'+_0x16c0ff(0x252,'!(h#')+'t']=_0x36c9f7[_0x16c0ff(0x192,'z1jU')],_0x36c9f7[_0x16c0ff(0x24d,'^hKH')]($,_0x16c0ff(0x2d5,'8)9r')+'st')['disab'+'led']=![];}),$(a0_0x5e70b8(0x158,'4U4P')+a0_0x5e70b8(0x23e,'*m0D')+a0_0x5e70b8(0x19d,'4U4P')+'nse')[a0_0x5e70b8(0x243,'f#]t')+a0_0x5e70b8(0x2f5,'*1JE')+'stene'+'r'](a0_0x5e70b8(0x170,'V042'),async()=>{const _0x2c4c60=a0_0x5e70b8,_0x42279a={'EfvWU':_0x2c4c60(0x236,'Bx@w')+_0x2c4c60(0x33f,'f^9x')+_0x2c4c60(0x178,'e1oq')+_0x2c4c60(0x215,'tv@4')+_0x2c4c60(0x274,'M5Rt')+_0x2c4c60(0x2e8,'BcF&'),'Jxoda':_0x2c4c60(0x336,'4axs')+_0x2c4c60(0x188,'!(h#')+_0x2c4c60(0x2a5,'hO]1')+_0x2c4c60(0x2f7,'AKUD')+_0x2c4c60(0x325,'8)9r')+_0x2c4c60(0x1bf,'p]x3')+_0x2c4c60(0x2f3,'gK2[')+_0x2c4c60(0x208,'f^9x'),'BqmJl':_0x2c4c60(0x2be,'8)9r')+_0x2c4c60(0x2af,'gK2[')+_0x2c4c60(0x245,'(4U4')+_0x2c4c60(0x289,'f^9x')+'abled'+_0x2c4c60(0x277,'%wlL')+_0x2c4c60(0x23d,'[JLP')+_0x2c4c60(0x33a,'TAj^')+_0x2c4c60(0x1e7,'BcF&'),'BQOtW':function(_0x46e4a9,_0x348c13,_0x451217){return _0x46e4a9(_0x348c13,_0x451217);},'xPPMA':function(_0x5e82e6,_0x1845d5){return _0x5e82e6+_0x1845d5;},'cGAVx':_0x2c4c60(0x190,'gzfg'),'lFfqb':function(_0x2d59aa,_0x49719e){return _0x2d59aa(_0x49719e);},'vRqac':_0x2c4c60(0x153,'%$XQ')+_0x2c4c60(0x310,'$#*i')+'y','Krlpp':_0x2c4c60(0x2ea,'9RnT')+_0x2c4c60(0x2a4,'$#*i')+_0x2c4c60(0x2fc,'%wlL')+_0x2c4c60(0x186,'z1jU')+_0x2c4c60(0x162,')b!&')+'.','LAMkg':_0x2c4c60(0x26f,')b!&')+_0x2c4c60(0x29b,'[M63')+_0x2c4c60(0x2bf,'BcF&')+_0x2c4c60(0x25a,'LYfp')+'SP','owjSK':function(_0x4f8200,_0x3c6b40){return _0x4f8200===_0x3c6b40;},'poxak':function(_0x2c6d86,_0x16bb88){return _0x2c6d86===_0x16bb88;},'NdMXd':_0x2c4c60(0x2ff,'p]x3')+_0x2c4c60(0x224,'(4U4')+'y\x20—\x20a'+_0x2c4c60(0x287,'4axs')+_0x2c4c60(0x205,'I4BD')+'d.','Djjix':_0x2c4c60(0x187,'*1JE')+_0x2c4c60(0x244,'BcF&')+_0x2c4c60(0x260,'38h(')+_0x2c4c60(0x327,'8gAi'),'qAOms':'Valid'+'ating'+'…','GFWBn':function(_0x65f59c,_0x42e20c,_0x46efe4){return _0x65f59c(_0x42e20c,_0x46efe4);},'efedm':'Check'+'ing…','DiqBH':_0x2c4c60(0x217,'%$XQ')+_0x2c4c60(0x2c4,'YQYG')+'d','Wsdwv':_0x2c4c60(0x230,'AKUD'),'kJENe':_0x2c4c60(0x324,'T7)m')+'catio'+_0x2c4c60(0x2a9,'gzfg')+'n','oYsym':'unkno'+'wn','RLRbF':function(_0x2edcab,_0x3dacf9,_0x43c231){return _0x2edcab(_0x3dacf9,_0x43c231);},'pSXlY':function(_0x492da1,_0x983600,_0x518ffe){return _0x492da1(_0x983600,_0x518ffe);},'mzNxs':function(_0x30b452,_0x447937){return _0x30b452!==_0x447937;},'sDPln':_0x2c4c60(0x199,'LYfp'),'wyDRl':_0x2c4c60(0x1ab,'p]x3')+_0x2c4c60(0x33b,'AKUD')+_0x2c4c60(0x1c0,'k^4g')+_0x2c4c60(0x248,'(ftV')+_0x2c4c60(0x273,'gzfg')+_0x2c4c60(0x1e2,'^hKH')+':','rWguD':function(_0x47dcd8,_0x5c910f){return _0x47dcd8(_0x5c910f);},'pWNCf':'Valid'+_0x2c4c60(0x1ff,'%$XQ')+_0x2c4c60(0x1bb,'3ZGb')+'e'},_0x32d01f=_0x42279a[_0x2c4c60(0x2ae,'^xVo')]($,_0x42279a[_0x2c4c60(0x27e,'YQYG')])[_0x2c4c60(0x2da,'^xVo')][_0x2c4c60(0x1b5,'5d6]')]();if(!_0x32d01f){_0x42279a[_0x2c4c60(0x1f4,')b!&')](updateLicenseStatus,_0x42279a[_0x2c4c60(0x1b8,'[iqq')],_0x2c4c60(0x22f,'%$XQ'));return;}const _0x495b2b=_0x42279a['LAMkg'];if(_0x42279a[_0x2c4c60(0x342,'[M63')](_0x32d01f,OWNER_KEY)||_0x42279a['poxak'](_0x32d01f,_0x495b2b)){await chrome[_0x2c4c60(0x1dc,'YQYG')+'ge'][_0x2c4c60(0x2f2,'!(h#')][_0x2c4c60(0x2b4,'5d6]')]({'license_key':_0x32d01f}),_0x42279a['BQOtW'](updateLicenseStatus,_0x42279a[_0x2c4c60(0x1f2,'LYfp')],'ok');return;}$(_0x42279a[_0x2c4c60(0x305,'(ftV')])[_0x2c4c60(0x26e,'Bx@w')+_0x2c4c60(0x1e0,'e1oq')+'t']=_0x42279a[_0x2c4c60(0x2c9,'9RnT')],_0x42279a['lFfqb']($,_0x42279a[_0x2c4c60(0x1cd,'e1oq')])['disab'+'led']=!![],_0x42279a['GFWBn'](updateLicenseStatus,_0x42279a['efedm'],'');try{const _0x2ad92a=await chrome['stora'+'ge']['local'][_0x2c4c60(0x309,')b!&')]([_0x42279a[_0x2c4c60(0x18c,'[iqq')]]);let _0x37bce5=_0x2ad92a['_mach'+_0x2c4c60(0x16f,'5BFO')+'d'];if(!_0x37bce5){const _0x5b15dd=new Uint8Array(0x20);crypto[_0x2c4c60(0x1b0,'^xVo')+_0x2c4c60(0x184,'*m0D')+_0x2c4c60(0x2a7,'k^4g')](_0x5b15dd),_0x37bce5=Array[_0x2c4c60(0x18f,'4axs')](_0x5b15dd)[_0x2c4c60(0x1dd,'5d6]')](_0x115cef=>_0x115cef[_0x2c4c60(0x156,'*1JE')+_0x2c4c60(0x1fd,'38h(')](0x10)['padSt'+'art'](0x2,'0'))[_0x2c4c60(0x18b,'(4U4')](''),await chrome[_0x2c4c60(0x2e3,'qe0v')+'ge'][_0x2c4c60(0x2fd,'38h(')][_0x2c4c60(0x334,'Nt[s')]({'_machine_id':_0x37bce5});}const _0x25a526=await fetch(LICENSE_API,{'method':_0x42279a[_0x2c4c60(0x26c,'V042')],'headers':{'Content-Type':_0x42279a['kJENe']},'body':JSON[_0x2c4c60(0x33e,'p]x3')+_0x2c4c60(0x2cf,'[iqq')]({'key':_0x32d01f,'machine_id':_0x37bce5})}),_0x241c80=await _0x25a526['json']();if(_0x241c80[_0x2c4c60(0x239,'Bx@w')]){await chrome[_0x2c4c60(0x2b6,'9RnT')+'ge'][_0x2c4c60(0x20b,'f#]t')][_0x2c4c60(0x2cd,'I4BD')]({'license_key':_0x32d01f});const _0x4e438a=_0x241c80['expir'+_0x2c4c60(0x316,'%$XQ')]?new Date(_0x241c80[_0x2c4c60(0x160,'^xVo')+'es_at'])['toLoc'+_0x2c4c60(0x345,'%wlL')+'teStr'+'ing']():_0x42279a[_0x2c4c60(0x1de,'tv@4')];_0x42279a['RLRbF'](updateLicenseStatus,_0x2c4c60(0x1c8,'AKUD')+_0x2c4c60(0x157,'^hKH')+_0x241c80[_0x2c4c60(0x339,'[iqq')]+(_0x2c4c60(0x1d2,'$#*i')+',\x20exp'+'ires\x20')+_0x4e438a,'ok');}else{const _0x3e7ac3={'invalid_key':_0x42279a['EfvWU'],'license_expired':_0x42279a[_0x2c4c60(0x1e5,'qe0v')],'max_devices_reached':'Max\x20d'+_0x2c4c60(0x209,'hO]1')+_0x2c4c60(0x191,'gzfg')+'ched\x20'+_0x2c4c60(0x2e4,'hO]1')+_0x2c4c60(0x335,'M5Rt')+_0x2c4c60(0x177,'*m0D')+_0x2c4c60(0x154,'qO]O')+_0x2c4c60(0x31f,'(4U4')+_0x2c4c60(0x292,'8gAi')+_0x2c4c60(0x1a3,'M5Rt'),'license_disabled':_0x42279a[_0x2c4c60(0x308,'5d6]')]};_0x42279a[_0x2c4c60(0x26b,'V042')](updateLicenseStatus,_0x42279a['xPPMA']('❌\x20',_0x3e7ac3[_0x241c80[_0x2c4c60(0x1a8,'qO]O')]]||_0x241c80[_0x2c4c60(0x226,'Bx@w')]||_0x2c4c60(0x2c3,'TAj^')+_0x2c4c60(0x338,'8gAi')+_0x2c4c60(0x155,'f^9x')+'.'),_0x42279a[_0x2c4c60(0x19c,'Bx@w')]);}}catch(_0x3cf601){if(_0x42279a[_0x2c4c60(0x219,'%$XQ')](_0x42279a[_0x2c4c60(0x1ca,'$#*i')],_0x2c4c60(0x27f,'T7)m')))_0x42279a[_0x2c4c60(0x210,'(4U4')](updateLicenseStatus,'⚠️\x20Cou'+'ld\x20no'+_0x2c4c60(0x28d,'f#]t')+'ch\x20li'+'cense'+'\x20serv'+_0x2c4c60(0x2db,'4axs')+_0x2c4c60(0x21e,'^hKH')+_0x2c4c60(0x29e,'38h(')+_0x2c4c60(0x1ae,'Bx@w')+_0x2c4c60(0x1da,'AKUD')+_0x2c4c60(0x200,'[iqq')+_0x2c4c60(0x17f,')b!&'),_0x42279a[_0x2c4c60(0x201,'hO]1')]),console['error'](_0x42279a[_0x2c4c60(0x28a,'3ZGb')],_0x3cf601);else{const _0x2906ac={'invalid_key':_0x42279a[_0x2c4c60(0x2a2,'%$XQ')],'license_expired':_0x42279a[_0x2c4c60(0x21a,'tv@4')],'max_devices_reached':_0x2c4c60(0x2c5,'8)9r')+'evice'+_0x2c4c60(0x16b,'k^4g')+_0x2c4c60(0x214,'gK2[')+'—\x20dea'+_0x2c4c60(0x1f7,'(4U4')+_0x2c4c60(0x2f6,'(ftV')+'other'+_0x2c4c60(0x307,'5BFO')+_0x2c4c60(0x33d,'tv@4')+'rst.','license_disabled':_0x42279a[_0x2c4c60(0x2c7,'$#*i')]};_0x42279a[_0x2c4c60(0x2b2,'[iqq')](_0x50c8a5,_0x42279a[_0x2c4c60(0x349,'BcF&')]('❌\x20',_0x2906ac[_0x9f0000['error']]||_0x4851a9[_0x2c4c60(0x193,'!(h#')]||'Licen'+_0x2c4c60(0x22a,'Bx@w')+_0x2c4c60(0x2f8,'BcF&')+'.'),_0x42279a[_0x2c4c60(0x33c,'NUFr')]);}}finally{_0x42279a['rWguD']($,_0x42279a[_0x2c4c60(0x30c,'8)9r')])['textC'+_0x2c4c60(0x2fa,'vzOU')+'t']=_0x42279a[_0x2c4c60(0x2dc,'%wlL')],_0x42279a[_0x2c4c60(0x306,'I4BD')]($,_0x42279a[_0x2c4c60(0x2c0,'%wlL')])[_0x2c4c60(0x161,'T7)m')+'led']=![];}}),load();
// ─── VFS Global options — load & save (appended; works alongside obfuscated core) ───

(async function vfsOptionsInit() {
  const KEYS = [
    'vfs_enabled_ltu', 'vfs_enabled_hun', 'vfs_email', 'vfs_password',
    'vfs_hands_free',
    'vfs_applicant_first_name', 'vfs_applicant_last_name',
    'vfs_applicant_passport_no', 'vfs_applicant_dob',
    'vfs_applicant_phone', 'vfs_applicant_nationality',
    'vfs_passport_front_b64', 'vfs_passport_back_b64',
    'vfs_passport_front_name', 'vfs_passport_back_name',
  ];
  const stored = await chrome.storage.local.get(KEYS);

  const $$ = (id) => document.getElementById(id);

  const ltuEl         = $$('vfsEnabledLtu');
  const hunEl         = $$('vfsEnabledHun');
  const emailEl       = $$('vfsEmail');
  const passEl        = $$('vfsPassword');
  const handsFreeEl   = $$('vfsHandsFree');
  const firstNameEl   = $$('vfsFirstName');
  const lastNameEl    = $$('vfsLastName');
  const passportNoEl  = $$('vfsPassportNo');
  const dobEl         = $$('vfsDob');
  const phoneEl       = $$('vfsPhone');
  const nationalityEl = $$('vfsNationality');
  const frontFileEl   = $$('vfsPassportFront');
  const backFileEl    = $$('vfsPassportBack');
  const frontStatusEl = $$('vfsPassportFrontStatus');
  const backStatusEl  = $$('vfsPassportBackStatus');

  if (ltuEl)         ltuEl.checked         = stored.vfs_enabled_ltu === true;
  if (hunEl)         hunEl.checked         = stored.vfs_enabled_hun === true;
  if (emailEl)       emailEl.value         = stored.vfs_email || '';
  if (passEl)        passEl.value          = stored.vfs_password || '';
  if (handsFreeEl)   handsFreeEl.checked   = stored.vfs_hands_free === true;
  if (firstNameEl)   firstNameEl.value     = stored.vfs_applicant_first_name || '';
  if (lastNameEl)    lastNameEl.value      = stored.vfs_applicant_last_name  || '';
  if (passportNoEl)  passportNoEl.value    = stored.vfs_applicant_passport_no|| '';
  if (dobEl)         dobEl.value           = stored.vfs_applicant_dob        || '';
  if (phoneEl)       phoneEl.value         = stored.vfs_applicant_phone      || '';
  if (nationalityEl) nationalityEl.value   = stored.vfs_applicant_nationality|| '';

  const describeImage = (name, b64) => {
    if (!b64) return 'No image saved';
    const sizeKb = Math.round((b64.length * 3) / 4 / 1024);
    return `Stored: ${name || 'image'} (~${sizeKb} KB)`;
  };
  if (frontStatusEl) frontStatusEl.textContent = describeImage(stored.vfs_passport_front_name, stored.vfs_passport_front_b64);
  if (backStatusEl)  backStatusEl.textContent  = describeImage(stored.vfs_passport_back_name,  stored.vfs_passport_back_b64);

  function fileToDataUri(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  // Save passport images
  const saveImgBtn  = $$('btnSavePassportImages');
  const clearImgBtn = $$('btnClearPassportImages');
  if (saveImgBtn) {
    saveImgBtn.addEventListener('click', async () => {
      const update = {};
      try {
        if (frontFileEl && frontFileEl.files && frontFileEl.files[0]) {
          update.vfs_passport_front_b64  = await fileToDataUri(frontFileEl.files[0]);
          update.vfs_passport_front_name = frontFileEl.files[0].name;
        }
        if (backFileEl && backFileEl.files && backFileEl.files[0]) {
          update.vfs_passport_back_b64   = await fileToDataUri(backFileEl.files[0]);
          update.vfs_passport_back_name  = backFileEl.files[0].name;
        }
        if (Object.keys(update).length === 0) {
          alert('Pick a file first.');
          return;
        }
        await chrome.storage.local.set(update);
        const fresh = await chrome.storage.local.get([
          'vfs_passport_front_b64','vfs_passport_front_name',
          'vfs_passport_back_b64','vfs_passport_back_name',
        ]);
        if (frontStatusEl) frontStatusEl.textContent = describeImage(fresh.vfs_passport_front_name, fresh.vfs_passport_front_b64);
        if (backStatusEl)  backStatusEl.textContent  = describeImage(fresh.vfs_passport_back_name,  fresh.vfs_passport_back_b64);
        alert('Saved.');
      } catch (e) {
        alert('Error saving: ' + (e && e.message ? e.message : e));
      }
    });
  }
  if (clearImgBtn) {
    clearImgBtn.addEventListener('click', async () => {
      await chrome.storage.local.remove([
        'vfs_passport_front_b64','vfs_passport_front_name',
        'vfs_passport_back_b64','vfs_passport_back_name',
      ]);
      if (frontStatusEl) frontStatusEl.textContent = 'No image saved';
      if (backStatusEl)  backStatusEl.textContent  = 'No image saved';
      if (frontFileEl) frontFileEl.value = '';
      if (backFileEl)  backFileEl.value  = '';
    });
  }

  // Hook into the existing Save button — patch its handler to also save VFS fields
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      await chrome.storage.local.set({
        vfs_enabled_ltu:              ltuEl         ? ltuEl.checked         : false,
        vfs_enabled_hun:              hunEl         ? hunEl.checked         : false,
        vfs_email:                    emailEl       ? emailEl.value.trim()  : '',
        vfs_password:                 passEl        ? passEl.value          : '',
        vfs_hands_free:               handsFreeEl   ? handsFreeEl.checked   : false,
        vfs_applicant_first_name:     firstNameEl   ? firstNameEl.value.trim()   : '',
        vfs_applicant_last_name:      lastNameEl    ? lastNameEl.value.trim()    : '',
        vfs_applicant_passport_no:    passportNoEl  ? passportNoEl.value.trim()  : '',
        vfs_applicant_dob:            dobEl         ? dobEl.value                : '',
        vfs_applicant_phone:          phoneEl       ? phoneEl.value.trim()       : '',
        vfs_applicant_nationality:    nationalityEl ? nationalityEl.value.trim() : '',
      });
      // Notify background to reconfigure VFS polling
      chrome.runtime.sendMessage({ type: 'VFS_CONFIG_UPDATED' }).catch(() => {});
    });
  }
})();

// ─── v1.5.318 Feature Flags — load & save ──────────────────────────────────
(async function _v318Options() {
  const V318_KEYS = [
    'useKeycloakRefresh', 'usePrewarmBooking',
    'useBurstPollReleaseWindow', 'releaseWindowStartHour', 'releaseWindowEndHour',
    'useDirectBookingApi', 'useApiBookingReplay'
  ];
  const $$ = id => document.getElementById(id);

  // Load saved values and populate UI
  const stored = await chrome.storage.local.get(V318_KEYS);

  const kcEl     = $$('useKeycloakRefresh');
  const prewarmEl = $$('usePrewarmBooking');
  const burstEl  = $$('useBurstPollReleaseWindow');
  const startEl  = $$('releaseWindowStartHour');
  const endEl    = $$('releaseWindowEndHour');
  const captureEl = $$('useDirectBookingApi');
  const apiReplayEl = $$('useApiBookingReplay');

  // Defaults: useKeycloakRefresh=true, others=false
  if (kcEl)      kcEl.checked     = stored.useKeycloakRefresh !== false;
  if (prewarmEl) prewarmEl.checked = stored.usePrewarmBooking === true;
  if (burstEl)   burstEl.checked   = stored.useBurstPollReleaseWindow === true;
  if (startEl)   startEl.value     = typeof stored.releaseWindowStartHour === 'number' ? stored.releaseWindowStartHour : 11;
  if (endEl)     endEl.value       = typeof stored.releaseWindowEndHour   === 'number' ? stored.releaseWindowEndHour   : 13;
  if (captureEl) captureEl.checked = stored.useDirectBookingApi === true;
  if (apiReplayEl) apiReplayEl.checked = stored.useApiBookingReplay === true;

  // Hook into the existing Save button
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      await chrome.storage.local.set({
        useKeycloakRefresh:           kcEl      ? kcEl.checked               : true,
        usePrewarmBooking:            prewarmEl ? prewarmEl.checked           : false,
        useBurstPollReleaseWindow:    burstEl   ? burstEl.checked             : false,
        releaseWindowStartHour:       startEl   ? parseInt(startEl.value, 10) : 11,
        releaseWindowEndHour:         endEl     ? parseInt(endEl.value, 10)   : 13,
        useDirectBookingApi:          captureEl ? captureEl.checked           : false,
        useApiBookingReplay:          apiReplayEl ? apiReplayEl.checked       : false,
      });
    });
  }

  // v1.5.325: Test API Replay button — fires one direct-API booking against
  // the currently-open TLS booking tab without going through DOM.
  const testBtn = $$('btnTestApiReplay');
  const testStatus = $$('apiReplayTestStatus');
  const dateInput = $$('apiReplayTestDate');
  const timeInput = $$('apiReplayTestTime');
  if (testBtn) {
    testBtn.addEventListener('click', async () => {
      const date = dateInput && dateInput.value;
      const time = (timeInput && timeInput.value && timeInput.value.trim()) || '09:00';
      if (!date) {
        if (testStatus) { testStatus.textContent = 'Pick a date first.'; testStatus.style.color = '#fca5a5'; }
        return;
      }
      if (testStatus) { testStatus.textContent = 'Sending…'; testStatus.style.color = '#94a3b8'; }
      try {
        const resp = await chrome.runtime.sendMessage({
          type: 'TEST_API_REPLAY_FROM_OPTIONS', date, time
        });
        if (!resp) {
          if (testStatus) { testStatus.textContent = 'no response'; testStatus.style.color = '#fca5a5'; }
          return;
        }
        if (testStatus) {
          if (resp.booked) {
            testStatus.textContent = `OK ${resp.status} (${resp.ms}ms)`;
            testStatus.style.color = '#86efac';
          } else {
            testStatus.textContent = `${resp.error || 'fail'}${resp.status ? ' ' + resp.status : ''}${resp.ms ? ' ' + resp.ms + 'ms' : ''}`;
            testStatus.style.color = '#fcd34d';
          }
        }
      } catch (e) {
        if (testStatus) { testStatus.textContent = 'err: ' + (e.message || e); testStatus.style.color = '#fca5a5'; }
      }
    });
  }

  // Download Captured Bookings button
  const dlBtn = $$('btnDownloadCapturedBookings');
  if (dlBtn) {
    dlBtn.addEventListener('click', async () => {
      const data = await chrome.storage.local.get(['captured_booking_posts']);
      const captures = data.captured_booking_posts || [];
      const json = JSON.stringify(captures, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'captured_booking_posts_' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
    });
  }

  // v1.5.390: Download API Booking Responses (ISOLATED-world capture from _attemptDirectApiBooking)
  const dlApiBtn = $$('btnDownloadApiBookingResponses');
  if (dlApiBtn) {
    dlApiBtn.addEventListener('click', async () => {
      const data = await chrome.storage.local.get(['api_booking_responses']);
      const captures = data.api_booking_responses || [];
      const json = JSON.stringify(captures, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'api_booking_responses_' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
    });
  }
})();

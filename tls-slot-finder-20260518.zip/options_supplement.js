// v1.5.343: externalized inline scripts from options.html.
//
// Why this file exists: Chrome MV3's default Content Security Policy for
// extension pages is `script-src 'self'` which BLOCKS inline <script> blocks.
// All four `(function(){...})()` IIFEs that previously lived at the bottom of
// options.html were silently dropped — that's why slot_preference, vfs_subcat,
// vfs_test_mode, vfs_phone_code, vfs_phone_number never persisted to storage.
//
// options.js is pre-obfuscated externally, so we can't extend it directly.
// This file is the canonical place for any "wire field <-> storage" logic
// that doesn't fit into the obfuscated bundle.

(function () {
  // v1.5.332: slot_preference dropdown
  const sel = document.getElementById('slot_preference');
  if (!sel) return;
  try {
    chrome.storage.local.get(['slot_preference'], (res) => {
      const v = (res && res.slot_preference) || 'no_prime';
      if (['any', 'no_prime', 'standard_only', 'premium_only'].includes(v)) sel.value = v;
      else sel.value = 'no_prime'; // migrate old 'any' users to no_prime
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ slot_preference: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.336: VFS subcategory single-select dropdown.
  // Storage key `vfs_subcat` — one of "Business/Cultural/Sports",
  // "Family/Friends visit", "Tourism". Default: Business/Cultural/Sports.
  const sel = document.getElementById('vfsSubcat');
  if (!sel) return;
  const ALLOWED = ['Business/Cultural/Sports', 'Family/Friends visit', 'Tourism'];
  try {
    chrome.storage.local.get(['vfs_subcat'], (res) => {
      const v = res && res.vfs_subcat;
      sel.value = ALLOWED.includes(v) ? v : 'Business/Cultural/Sports';
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_subcat: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.338: VFS test mode toggle. Bypasses Friday 15-19 Yerevan window
  // when on. Storage key `vfs_test_mode` (boolean). Default off.
  const tm = document.getElementById('vfsTestMode');
  if (!tm) return;
  try {
    chrome.storage.local.get(['vfs_test_mode'], (res) => {
      tm.checked = !!(res && res.vfs_test_mode);
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_test_mode: !!tm.checked });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.342: VFS phone code + phone number for the contact-details sub-step.
  // Stored as vfs_phone_code and vfs_phone_number (digits only).
  const codeEl = document.getElementById('vfsPhoneCode');
  const numEl  = document.getElementById('vfsPhoneNumber');
  if (!codeEl && !numEl) return;
  try {
    chrome.storage.local.get(['vfs_phone_code', 'vfs_phone_number'], (res) => {
      if (codeEl && res && res.vfs_phone_code) codeEl.value = res.vfs_phone_code;
      if (numEl  && res && res.vfs_phone_number) numEl.value  = res.vfs_phone_number;
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        const code = codeEl ? codeEl.value.replace(/\D/g, '') : '';
        const num  = numEl  ? numEl.value.replace(/\D/g, '')  : '';
        chrome.storage.local.set({
          vfs_phone_code: code,
          vfs_phone_number: num,
        });
      } catch (_) {}
    });
  }
})();

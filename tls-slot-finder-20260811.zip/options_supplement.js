// v1.5.439: Profile name label — shown in Telegram alerts to identify which
// Chrome profile fired. Chrome exposes no API for the OS profile name, so this
// is a manual per-profile label persisted to storage key `profile_name`.
(function () {
  const el = document.getElementById('profileName');
  if (!el) return;
  try {
    chrome.storage.local.get(['profile_name'], (res) => {
      el.value = (res && res.profile_name) || '';
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ profile_name: (el.value || '').trim() });
      } catch (_) {}
    });
  }
})();

// v1.5.363: BLS Spain options section
(function () {
  const $$ = (id) => document.getElementById(id);
  const KEYS = ['bls_enabled', 'bls_email', 'bls_password', 'bls_applicant_index', 'bls_book_count', 'bls_selfie_b64', 'bls_selfie_name'];

  function describeImage(name, b64) {
    if (!b64) return 'No selfie saved';
    const sizeKb = Math.round((b64.length * 3) / 4 / 1024);
    return `Stored: ${name || 'selfie'} (~${sizeKb} KB)`;
  }

  function fileToDataUri(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  chrome.storage.local.get(KEYS, (stored) => {
    const enabledEl = $$('blsEnabled');
    const emailEl   = $$('blsEmail');
    const passEl    = $$('blsPassword');
    const idxEl     = $$('blsApplicantIndex');
    const statusEl  = $$('blsSelfieStatus');

    const cntEl     = $$('blsBookCount');
    if (enabledEl) enabledEl.checked = stored.bls_enabled === true;
    if (emailEl)   emailEl.value     = stored.bls_email    || '';
    if (passEl)    passEl.value      = stored.bls_password  || '';
    if (idxEl)     idxEl.value       = stored.bls_applicant_index != null ? stored.bls_applicant_index : 0;
    if (cntEl)     cntEl.value       = stored.bls_book_count != null ? stored.bls_book_count : 1;
    if (statusEl)  statusEl.textContent = describeImage(stored.bls_selfie_name, stored.bls_selfie_b64);
  });

  // Save BLS fields on main Save button
  const saveBtn = $$('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({
          bls_enabled:          !!($$('blsEnabled') && $$('blsEnabled').checked),
          bls_email:            ($$('blsEmail')    || {}).value || '',
          bls_password:         ($$('blsPassword') || {}).value || '',
          bls_applicant_index:  parseInt(($$('blsApplicantIndex') || {}).value || '0', 10),
          bls_book_count:       parseInt(($$('blsBookCount')       || {}).value || '1', 10),
          bls_login_attempts:   0,
          bls_login_blocked:    false,
        });
      } catch (_) {}
    });
  }

  // Save selfie
  const saveSelfieBtn = $$('btnSaveBLSSelfie');
  if (saveSelfieBtn) {
    saveSelfieBtn.addEventListener('click', async () => {
      const fileEl  = $$('blsSelfie');
      const statusEl = $$('blsSelfieStatus');
      if (!fileEl || !fileEl.files || !fileEl.files[0]) {
        if (statusEl) statusEl.textContent = 'Pick a file first.';
        return;
      }
      const file = fileEl.files[0];
      const b64  = await fileToDataUri(file);
      await chrome.storage.local.set({ bls_selfie_b64: b64, bls_selfie_name: file.name });
      if (statusEl) statusEl.textContent = describeImage(file.name, b64);
    });
  }

  // Clear selfie
  const clearSelfieBtn = $$('btnClearBLSSelfie');
  if (clearSelfieBtn) {
    clearSelfieBtn.addEventListener('click', async () => {
      await chrome.storage.local.remove(['bls_selfie_b64', 'bls_selfie_name']);
      const statusEl = $$('blsSelfieStatus');
      if (statusEl) statusEl.textContent = 'No selfie saved';
    });
  }
})();

// v1.5.506: "Find slots no earlier than" (start_date) — lower bound complementing
// deadline_date's upper bound. Wired here because options.js is pre-obfuscated and can't
// be extended. Storage key `start_date` (ISO YYYY-MM-DD or ''). The parser enforces it:
// slots before this date are dropped before any alert or booking.
(function () {
  const el = document.getElementById('start_date');
  if (!el) return;
  try {
    chrome.storage.local.get(['start_date'], (res) => {
      el.value = (res && res.start_date) || '';
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ start_date: (el.value || '').trim() });
      } catch (_) {}
    });
  }
})();

// v1.5.343: externalized inline scripts from options.html.
//
// Why this file exists: Chrome MV3's default Content Security Policy for
// extension pages is `script-src 'self'` which BLOCKS inline <script> blocks.
// All four `(function(){...})()` IIFEs that previously lived at the bottom of
// options.html were silently dropped — that's why slot_preference, vfs_subcat,
// vfs_test_mode, vfs_phone_code, vfs_phone_number never persisted to storage.
//
// options.js is pre-obfuscated externally, so we can't extend it directly.
// This file is the canonical place for any "wire field <-> storage" logic
// that doesn't fit into the obfuscated bundle.

(function () {
  // v1.5.332: slot_preference dropdown
  const sel = document.getElementById('slot_preference');
  if (!sel) return;
  try {
    chrome.storage.local.get(['slot_preference'], (res) => {
      let v = (res && res.slot_preference) || 'no_premium';
      // v1.5.433: migrate legacy values to the new option set.
      // no_prime (std+premium) → no_premium (std+prime): both skip the costly tier
      // by intent; premium_only had no equivalent, fall back to safe default.
      if (v === 'no_prime') v = 'no_premium';
      if (v === 'premium_only') v = 'no_premium';
      if (['any', 'no_premium', 'standard_only', 'prime_only'].includes(v)) sel.value = v;
      else sel.value = 'no_premium';
      if (res && res.slot_preference && res.slot_preference !== sel.value) {
        try { chrome.storage.local.set({ slot_preference: sel.value }); } catch (_) {}
      }
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ slot_preference: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.336: VFS subcategory single-select dropdown.
  // Storage key `vfs_subcat` — one of "Business/Cultural/Sports",
  // "Family/Friends visit", "Tourism". Default: Business/Cultural/Sports.
  const sel = document.getElementById('vfsSubcat');
  if (!sel) return;
  const ALLOWED = ['Business/Cultural/Sports', 'Family/Friends visit', 'Tourism'];
  try {
    chrome.storage.local.get(['vfs_subcat'], (res) => {
      const v = res && res.vfs_subcat;
      sel.value = ALLOWED.includes(v) ? v : 'Business/Cultural/Sports';
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_subcat: sel.value });
      } catch (_) {}
    });
  }
})();

(function () {
  // v1.5.338: VFS test mode toggle. Bypasses Friday 15-19 Yerevan window
  // when on. Storage key `vfs_test_mode` (boolean). Default off.
  const tm = document.getElementById('vfsTestMode');
  if (!tm) return;
  try {
    chrome.storage.local.get(['vfs_test_mode'], (res) => {
      tm.checked = !!(res && res.vfs_test_mode);
    });
  } catch (_) {}
  const saveBtn = document.getElementById('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      try {
        chrome.storage.local.set({ vfs_test_mode: !!tm.checked });
      } catch (_) {}
    });
  }
})();

// v1.5.414 Phase D: Unified multi-applicant booking UI.
// Manages: vfs_num_applicants, vfs_applicants[], vfs_phone_code, vfs_phone_number.
// Phone is shared across all applicants (Q1). Passport per applicant.
(function () {
  const $$ = id => document.getElementById(id);
  const MAX_APPLICANTS = 6;

  let _applicants = [];   // mirrors vfs_applicants[] in storage
  let _numApplicants = 1;

  function describeFile(b64, name) {
    if (!b64) return 'No passport saved';
    const sizeKb = Math.round((b64.length * 3) / 4 / 1024);
    return `Saved: ${name || 'file'} (~${sizeKb} KB)`;
  }

  function fileToDataUri(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  function renderApplicantCard(idx) {
    const ap = _applicants[idx] || {};
    const visibleNum = idx + 1;
    const card = document.createElement('div');
    card.className = 'vfs-ap-card';
    card.dataset.idx = idx;
    card.style.cssText = 'border:1px solid #334155;border-radius:8px;padding:12px;margin-bottom:12px;';
    card.innerHTML = `
      <div style="font-size:13px;font-weight:600;color:#e2e8f0;margin-bottom:10px;">Applicant ${visibleNum}</div>
      <div class="field">
        <label style="display:block;font-size:12px;color:#94a3b8;margin-bottom:6px;">Passport — Front Page (bio)</label>
        <input type="file" class="ap-passport-front" accept="image/*,.pdf"
          style="padding:6px 0;background:transparent;border:none;color:#94a3b8;">
        <div class="ap-front-status" style="font-size:11px;margin-top:4px;color:#64748b;">${describeFile(ap.passportFrontB64, ap.passportFrontName)}</div>
      </div>
      <div class="field">
        <label style="display:block;font-size:12px;color:#94a3b8;margin-bottom:6px;">Passport — Back Page <span style="color:#475569;font-size:11px;">(optional)</span></label>
        <input type="file" class="ap-passport-back" accept="image/*,.pdf"
          style="padding:6px 0;background:transparent;border:none;color:#94a3b8;">
        <div class="ap-back-status" style="font-size:11px;margin-top:4px;color:#64748b;">${describeFile(ap.passportBackB64, ap.passportBackName)}</div>
      </div>
      <button class="btn btn-test btn-save-ap" style="font-size:12px;padding:7px 14px;margin-top:4px;">Save Applicant ${visibleNum}</button>
    `;

    card.querySelector('.btn-save-ap').addEventListener('click', async () => {
      const frontFile = card.querySelector('.ap-passport-front').files[0];
      const backFile  = card.querySelector('.ap-passport-back').files[0];
      if (!_applicants[idx]) _applicants[idx] = { passportFrontB64: null, passportFrontName: null, passportBackB64: null, passportBackName: null };
      if (frontFile) {
        const b64 = await fileToDataUri(frontFile);
        _applicants[idx].passportFrontB64  = b64;
        _applicants[idx].passportFrontName = frontFile.name;
        card.querySelector('.ap-front-status').textContent = describeFile(b64, frontFile.name);
      }
      if (backFile) {
        const b64 = await fileToDataUri(backFile);
        _applicants[idx].passportBackB64  = b64;
        _applicants[idx].passportBackName = backFile.name;
        card.querySelector('.ap-back-status').textContent = describeFile(b64, backFile.name);
      }
      await chrome.storage.local.set({ vfs_applicants: _applicants });
    });

    return card;
  }

  function renderAllCards(count) {
    const container = $$('vfsApplicantsContainer');
    if (!container) return;
    container.innerHTML = '';
    for (let i = 0; i < count; i++) {
      container.appendChild(renderApplicantCard(i));
    }
  }

  // Load saved state on open
  chrome.storage.local.get(['vfs_num_applicants', 'vfs_applicants', 'vfs_phone_code', 'vfs_phone_number'], (stored) => {
    _numApplicants = Math.max(1, Math.min(MAX_APPLICANTS, stored.vfs_num_applicants || 1));
    _applicants = Array.isArray(stored.vfs_applicants)
      ? JSON.parse(JSON.stringify(stored.vfs_applicants))
      : [];

    const numEl = $$('vfsNumApplicants');
    if (numEl) numEl.value = String(_numApplicants);

    const codeEl = $$('vfsPhoneCode');
    const numPhEl = $$('vfsPhoneNumber');
    if (codeEl && stored.vfs_phone_code) codeEl.value = stored.vfs_phone_code;
    if (numPhEl && stored.vfs_phone_number) numPhEl.value = stored.vfs_phone_number;

    renderAllCards(_numApplicants);
  });

  // Number-of-applicants dropdown: grow or shrink cards, preserve existing data
  const numEl = $$('vfsNumApplicants');
  if (numEl) {
    numEl.addEventListener('change', () => {
      const newCount = Math.max(1, Math.min(MAX_APPLICANTS, parseInt(numEl.value, 10) || 1));
      _numApplicants = newCount;
      // Grow: pad _applicants with empty entries
      while (_applicants.length < newCount) {
        _applicants.push({ passportFrontB64: null, passportFrontName: null, passportBackB64: null, passportBackName: null });
      }
      renderAllCards(newCount);
    });
  }

  // Main Save button — persist all VFS multi-applicant fields
  const saveBtn = $$('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const numEl2  = $$('vfsNumApplicants');
      const codeEl  = $$('vfsPhoneCode');
      const numPhEl = $$('vfsPhoneNumber');
      const count = numEl2 ? Math.max(1, Math.min(MAX_APPLICANTS, parseInt(numEl2.value, 10) || 1)) : _numApplicants;
      const code  = codeEl  ? codeEl.value.replace(/\D/g, '')  : '';
      const num   = numPhEl ? numPhEl.value.replace(/\D/g, '') : '';
      try {
        chrome.storage.local.set({
          vfs_num_applicants: count,
          vfs_phone_code:     code,
          vfs_phone_number:   num,
          vfs_applicants:     _applicants.slice(0, count),
        });
      } catch (_) {}
    });
  }
})();

// Greece GVCWorld monitoring settings.
// Storage keys: gr_enabled, gr_recon_enabled, gr_hands_free, gr_search_date, gr_accounts.
// gr_accounts: [{label, deadline (DD/MM/YYYY), priority (int), preferredTime (string)}]
(function () {
  const $$ = id => document.getElementById(id);
  const GR_KEYS = ['gr_enabled', 'gr_recon_enabled', 'gr_hands_free', 'gr_search_date', 'gr_accounts'];

  function _escAttr(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function makeAccountRow(acct, onRemove) {
    const row = document.createElement('div');
    row.dataset.grAccRow = '1';
    row.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;' +
      'border:1px solid #334155;border-radius:6px;padding:8px;';
    row.innerHTML =
      '<input type="text" class="gr-acc-label" placeholder="Label" maxlength="30" value="' + _escAttr(acct.label) + '"' +
        ' style="width:100px;padding:5px 8px;background:#1e293b;border:1px solid #334155;border-radius:4px;color:#e2e8f0;font-size:12px;">' +
      '<input type="text" class="gr-acc-deadline" placeholder="Deadline DD/MM/YYYY" maxlength="10" value="' + _escAttr(acct.deadline) + '"' +
        ' style="width:148px;padding:5px 8px;background:#1e293b;border:1px solid #334155;border-radius:4px;color:#e2e8f0;font-size:12px;font-family:monospace;">' +
      '<input type="number" class="gr-acc-priority" placeholder="Priority" min="1" max="99" value="' + _escAttr(acct.priority != null ? acct.priority : 1) + '"' +
        ' style="width:70px;padding:5px 8px;background:#1e293b;border:1px solid #334155;border-radius:4px;color:#e2e8f0;font-size:12px;">' +
      '<input type="text" class="gr-acc-ptime" placeholder="Pref. time (opt)" maxlength="20" value="' + _escAttr(acct.preferredTime) + '"' +
        ' style="width:140px;padding:5px 8px;background:#1e293b;border:1px solid #334155;border-radius:4px;color:#e2e8f0;font-size:12px;font-family:monospace;">' +
      '<input type="text" class="gr-acc-appref" placeholder="Applicant (name/passport)" maxlength="60"' +
        ' title="Multi-application picker: name or passport substring to select the right applicant"' +
        ' value="' + _escAttr(acct.applicationRef) + '"' +
        ' style="width:170px;padding:5px 8px;background:#1e293b;border:1px solid #334155;border-radius:4px;color:#e2e8f0;font-size:12px;">' +
      '<input type="number" class="gr-acc-family-size" placeholder="Family" min="1" max="20"' +
        ' title="Family size — number of consecutive slots to target (1 = individual)"' +
        ' value="' + _escAttr(acct.familySize != null ? acct.familySize : 1) + '"' +
        ' style="width:60px;padding:5px 8px;background:#1e293b;border:1px solid #334155;border-radius:4px;color:#e2e8f0;font-size:12px;">' +
      '<input type="number" class="gr-acc-gap-min" placeholder="Gap" min="5" max="120"' +
        ' title="Gap between family slots in minutes (default 15)"' +
        ' value="' + _escAttr(acct.gapMinutes != null ? acct.gapMinutes : 15) + '"' +
        ' style="width:55px;padding:5px 8px;background:#1e293b;border:1px solid #334155;border-radius:4px;color:#e2e8f0;font-size:12px;">' +
      '<button class="btn btn-test gr-acc-rm" style="font-size:11px;padding:5px 10px;color:#fca5a5;border-color:#7f1d1d;">Remove</button>';
    row.querySelector('.gr-acc-rm').addEventListener('click', function () { onRemove(row); });
    return row;
  }

  function readAccountRows(container) {
    return Array.from(container.querySelectorAll('[data-gr-acc-row]')).map(function (row) {
      return {
        label:         ((row.querySelector('.gr-acc-label')       || {}).value || '').trim(),
        deadline:      ((row.querySelector('.gr-acc-deadline')    || {}).value || '').trim(),
        priority:      parseInt(((row.querySelector('.gr-acc-priority')   || {}).value || '1'),  10) || 1,
        preferredTime: ((row.querySelector('.gr-acc-ptime')       || {}).value || '').trim(),
        familySize:    parseInt(((row.querySelector('.gr-acc-family-size') || {}).value || '1'),  10) || 1,
        gapMinutes:    parseInt(((row.querySelector('.gr-acc-gap-min')    || {}).value || '15'), 10) || 15,
      };
    });
  }

  function renderAccounts(accounts) {
    var container = $$('grAccountsContainer');
    if (!container) return;
    container.innerHTML = '';
    (accounts || []).forEach(function (acct) {
      container.appendChild(makeAccountRow(acct, function (row) { row.remove(); }));
    });
  }

  // Load saved values on open
  try {
    chrome.storage.local.get(GR_KEYS, function (stored) {
      var enabledEl = $$('grEnabled');
      var reconEl   = $$('grReconEnabled');
      var hfEl      = $$('grHandsFree');
      var dateEl    = $$('grSearchDate');
      if (enabledEl) enabledEl.checked = stored.gr_enabled === true;
      if (reconEl)   reconEl.checked   = stored.gr_recon_enabled === true;
      if (hfEl)      hfEl.checked      = stored.gr_hands_free === true;
      if (dateEl)    dateEl.value      = stored.gr_search_date || '';
      renderAccounts(Array.isArray(stored.gr_accounts) ? stored.gr_accounts : []);
    });
  } catch (_) {}

  // "Add Account" button
  var addBtn = $$('btnAddGrAccount');
  if (addBtn) {
    addBtn.addEventListener('click', function () {
      var container = $$('grAccountsContainer');
      if (!container) return;
      container.appendChild(makeAccountRow(
        { label: '', deadline: '', priority: 1, preferredTime: '', familySize: 1, gapMinutes: 15 },
        function (row) { row.remove(); }
      ));
    });
  }

  // Persist to storage when the main Save button is clicked
  var saveBtn = $$('btnSave');
  if (saveBtn) {
    saveBtn.addEventListener('click', function () {
      var enabledEl  = $$('grEnabled');
      var reconEl    = $$('grReconEnabled');
      var hfEl       = $$('grHandsFree');
      var dateEl     = $$('grSearchDate');
      var container  = $$('grAccountsContainer');
      try {
        chrome.storage.local.set({
          gr_enabled:       !!(enabledEl && enabledEl.checked),
          gr_recon_enabled: !!(reconEl && reconEl.checked),
          gr_hands_free:    !!(hfEl && hfEl.checked),
          gr_search_date:   (dateEl ? dateEl.value : '').trim(),
          gr_accounts:      container ? readAccountRows(container) : [],
        });
        // Notify open GVCWorld tabs to reload their config
        try { chrome.runtime.sendMessage({ type: 'GR_CONFIG_UPDATED' }); } catch (_) {}
      } catch (_) {}
    });
  }
})();
